/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useCallback } from 'react';
import { Product, TrendItem, OpportunityItem, MonitoringItem, AppSettings } from './types';
import { localDb, DEFAULT_SETTINGS } from './services/db';
import { geminiService, HealthStatus } from './services/gemini';
import { Sidebar, ViewType } from './components/Sidebar';
import { TopHeader } from './components/TopHeader';
import { ZeroCostGuardModal } from './components/ZeroCostGuardModal';
import { AddProductModal } from './components/AddProductModal';
import { ProductDetailModal } from './components/ProductDetailModal';

// Module Views
import { DashboardView } from './views/DashboardView';
import { AIProductSearchView } from './views/AIProductSearchView';
import { CompetitorSearchView } from './views/CompetitorSearchView';
import { ProductComparisonView } from './views/ProductComparisonView';
import { PriceIntelligenceView } from './views/PriceIntelligenceView';
import { FurnitureTrendsView } from './views/FurnitureTrendsView';
import { SocialMediaIntelligenceView } from './views/SocialMediaIntelligenceView';
import { ProductOpportunitiesView } from './views/ProductOpportunitiesView';
import { SpreadsheetHubView } from './views/SpreadsheetHubView';
import { MonitoringView } from './views/MonitoringView';
import { ReportsView } from './views/ReportsView';
import { SettingsView } from './views/SettingsView';

export default function App() {
  const [currentView, setCurrentView] = useState<ViewType>('dashboard');
  const [products, setProducts] = useState<Product[]>([]);
  const [trends, setTrends] = useState<TrendItem[]>([]);
  const [opportunities, setOpportunities] = useState<OpportunityItem[]>([]);
  const [monitoring, setMonitoring] = useState<MonitoringItem[]>([]);
  const [settings, setSettings] = useState<AppSettings>(DEFAULT_SETTINGS);
  const [healthStatus, setHealthStatus] = useState<HealthStatus | null>(null);

  // Modals
  const [isGuardModalOpen, setIsGuardModalOpen] = useState(false);
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [editingProduct, setEditingProduct] = useState<Product | null>(null);
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  // Load all data from IndexedDB
  const loadData = useCallback(async () => {
    try {
      const [prods, trnds, opps, mons, sttngs] = await Promise.all([
        localDb.getProducts(),
        localDb.getTrends(),
        localDb.getOpportunities(),
        localDb.getMonitoringItems(),
        localDb.getSettings(),
      ]);

      setProducts(prods);
      setTrends(trnds);
      setOpportunities(opps);
      setMonitoring(mons);
      setSettings(sttngs);
    } catch (err) {
      console.error('Failed to load local DB data:', err);
    }
  }, []);

  useEffect(() => {
    loadData();

    // Fetch initial health from server
    geminiService.getHealth().then(setHealthStatus).catch(() => {});
  }, [loadData]);

  // Apply Theme and Direction to Document
  useEffect(() => {
    const root = document.documentElement;

    // Theme: toggle 'dark' class
    if (settings.theme === 'dark') {
      root.classList.add('dark');
    } else {
      root.classList.remove('dark');
    }

    // Direction & Language
    if (settings.language === 'ar') {
      root.setAttribute('dir', 'rtl');
      root.setAttribute('lang', 'ar');
    } else {
      root.setAttribute('dir', 'ltr');
      root.setAttribute('lang', 'en');
    }
  }, [settings.theme, settings.language]);

  // Handlers for Products
  const handleSaveProduct = async (product: Product) => {
    await localDb.saveProduct(product);
    // Also if it's a competitor product with URL, ensure it has a monitoring item
    if (product.brand === 'Competitor' && product.url) {
      const existingMon = monitoring.find((m) => m.productId === product.id);
      if (!existingMon) {
        const newMon: MonitoringItem = {
          id: `mon-${Date.now()}`,
          productId: product.id,
          productName: product.name,
          retailer: product.retailer,
          url: product.url,
          lastKnownPriceEGP: product.priceEGP,
          currentPriceEGP: product.priceEGP,
          lastCheckedDate: product.lastChecked,
          status: product.inStock ? 'In Stock' : 'Out of Stock',
          changePercent: 0,
          auditNotes: [`Added to monitoring on ${product.lastChecked}`],
        };
        await localDb.saveMonitoringItem(newMon);
      }
    }
    await loadData();
  };

  const handleImportProducts = async (imported: Product[]) => {
    for (const p of imported) {
      await localDb.saveProduct(p);
    }
    await loadData();
  };

  const handleSaveTrend = async (trend: TrendItem) => {
    await localDb.saveTrend(trend);
    await loadData();
  };

  const handleSaveOpportunity = async (opp: OpportunityItem) => {
    await localDb.saveOpportunity(opp);
    await loadData();
  };

  const handleUpdateMonitoring = async (item: MonitoringItem) => {
    await localDb.saveMonitoringItem(item);
    // Also sync product price if changed
    const prod = products.find((p) => p.id === item.productId);
    if (prod && prod.priceEGP !== item.currentPriceEGP) {
      const updatedHist = [...(prod.priceHistory || []), {
        date: item.lastCheckedDate,
        priceEGP: item.currentPriceEGP,
        note: `Updated via URL monitoring: ${item.status}`
      }];
      await localDb.saveProduct({
        ...prod,
        priceEGP: item.currentPriceEGP,
        lastChecked: item.lastCheckedDate,
        priceHistory: updatedHist,
        inStock: item.status !== 'Out of Stock' && item.status !== 'Discontinued',
      });
    }
    await loadData();
  };

  const handleUpdateSettings = async (newSettings: AppSettings) => {
    setSettings(newSettings);
    await localDb.saveSettings(newSettings);
  };

  const handleToggleTheme = () => {
    const nextTheme = settings.theme === 'dark' ? 'light' : 'dark';
    handleUpdateSettings({ ...settings, theme: nextTheme });
  };

  const handleToggleLang = () => {
    const nextLang = settings.language === 'en' ? 'ar' : 'en';
    handleUpdateSettings({ ...settings, language: nextLang });
  };

  const kemittProducts = products.filter((p) => p.brand === 'Kemitt');

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100 flex transition-colors duration-150">
      {/* Sidebar Desktop */}
      <div className="hidden md:block">
        <Sidebar
          currentView={currentView}
          onSelectView={setCurrentView}
          lang={settings.language}
          onToggleLang={handleToggleLang}
          theme={settings.theme}
          onToggleTheme={handleToggleTheme}
          onOpenGuardModal={() => setIsGuardModalOpen(true)}
          apiCallCount={healthStatus?.apiCallsThisSession ?? 0}
        />
      </div>

      {/* Mobile Sidebar Overlay */}
      {mobileMenuOpen && (
        <div className="fixed inset-0 z-40 md:hidden flex">
          <div
            className="fixed inset-0 bg-black/60 backdrop-blur-xs"
            onClick={() => setMobileMenuOpen(false)}
          />
          <div className="relative z-50">
            <Sidebar
              currentView={currentView}
              onSelectView={(v) => {
                setCurrentView(v);
                setMobileMenuOpen(false);
              }}
              lang={settings.language}
              onToggleLang={handleToggleLang}
              theme={settings.theme}
              onToggleTheme={handleToggleTheme}
              onOpenGuardModal={() => {
                setIsGuardModalOpen(true);
                setMobileMenuOpen(false);
              }}
              apiCallCount={healthStatus?.apiCallsThisSession ?? 0}
            />
          </div>
        </div>
      )}

      {/* Main Content Workspace */}
      <div className="flex-1 flex flex-col min-w-0">
        <TopHeader
          currentView={currentView}
          lang={settings.language}
          onOpenAddProduct={() => {
            setEditingProduct(null);
            setIsAddModalOpen(true);
          }}
          onOpenGuardModal={() => setIsGuardModalOpen(true)}
          onToggleMobileMenu={() => setMobileMenuOpen(!mobileMenuOpen)}
          productCount={products.length}
        />

        <main className="flex-1 pb-16">
          {currentView === 'dashboard' && (
            <DashboardView
              products={products}
              opportunities={opportunities}
              trends={trends}
              monitoring={monitoring}
              onNavigate={setCurrentView}
              onSelectProduct={setSelectedProduct}
              lang={settings.language}
            />
          )}

          {currentView === 'aiProductSearch' && (
            <AIProductSearchView
              onSaveProduct={handleSaveProduct}
              lang={settings.language}
            />
          )}

          {currentView === 'competitorSearch' && (
            <CompetitorSearchView
              onSaveProduct={handleSaveProduct}
              kemittProducts={kemittProducts}
              lang={settings.language}
            />
          )}

          {currentView === 'productComparison' && (
            <ProductComparisonView
              products={products}
              lang={settings.language}
              onSelectProduct={setSelectedProduct}
            />
          )}

          {currentView === 'priceIntelligence' && (
            <PriceIntelligenceView
              products={products}
              onUpdateProduct={handleSaveProduct}
              lang={settings.language}
            />
          )}

          {currentView === 'furnitureTrends' && (
            <FurnitureTrendsView
              trends={trends}
              onSaveTrend={handleSaveTrend}
              lang={settings.language}
            />
          )}

          {currentView === 'socialIntelligence' && (
            <SocialMediaIntelligenceView
              lang={settings.language}
            />
          )}

          {currentView === 'opportunities' && (
            <ProductOpportunitiesView
              opportunities={opportunities}
              products={products}
              onSaveOpportunity={handleSaveOpportunity}
              lang={settings.language}
            />
          )}

          {currentView === 'spreadsheetHub' && (
            <SpreadsheetHubView
              products={products}
              onImportProducts={handleImportProducts}
              lang={settings.language}
            />
          )}

          {currentView === 'monitoring' && (
            <MonitoringView
              monitoringItems={monitoring}
              products={products}
              onUpdateMonitoringItem={handleUpdateMonitoring}
              lang={settings.language}
            />
          )}

          {currentView === 'reports' && (
            <ReportsView
              products={products}
              opportunities={opportunities}
              trends={trends}
              monitoring={monitoring}
              lang={settings.language}
            />
          )}

          {currentView === 'settings' && (
            <SettingsView
              settings={settings}
              onUpdateSettings={handleUpdateSettings}
              onReloadData={loadData}
              lang={settings.language}
            />
          )}
        </main>
      </div>

      {/* Modals */}
      <ZeroCostGuardModal
        isOpen={isGuardModalOpen}
        onClose={() => setIsGuardModalOpen(false)}
        lang={settings.language}
        health={healthStatus}
      />

      <AddProductModal
        isOpen={isAddModalOpen}
        onClose={() => setIsAddModalOpen(false)}
        onSave={handleSaveProduct}
        lang={settings.language}
        existingProduct={editingProduct}
        kemittProducts={kemittProducts}
      />

      <ProductDetailModal
        product={selectedProduct}
        onClose={() => setSelectedProduct(null)}
        onEdit={(p) => {
          setSelectedProduct(null);
          setEditingProduct(p);
          setIsAddModalOpen(true);
        }}
        lang={settings.language}
      />
    </div>
  );
}
