import React from 'react';
import {
  LayoutDashboard,
  Sparkles,
  Search,
  GitCompare,
  DollarSign,
  TrendingUp,
  Share2,
  Lightbulb,
  FileSpreadsheet,
  Eye,
  FileText,
  Settings,
  ShieldCheck,
  Moon,
  Sun,
  Languages,
  Layers,
  ChevronRight,
  ExternalLink
} from 'lucide-react';
import { translations } from '../locales/translations';

export type ViewType =
  | 'dashboard'
  | 'aiProductSearch'
  | 'competitorSearch'
  | 'productComparison'
  | 'priceIntelligence'
  | 'furnitureTrends'
  | 'socialIntelligence'
  | 'opportunities'
  | 'spreadsheetHub'
  | 'monitoring'
  | 'reports'
  | 'settings';

interface SidebarProps {
  currentView: ViewType;
  onSelectView: (view: ViewType) => void;
  lang: 'en' | 'ar';
  onToggleLang: () => void;
  theme: 'dark' | 'light';
  onToggleTheme: () => void;
  onOpenGuardModal: () => void;
  apiCallCount: number;
}

export const Sidebar: React.FC<SidebarProps> = ({
  currentView,
  onSelectView,
  lang,
  onToggleLang,
  theme,
  onToggleTheme,
  onOpenGuardModal,
  apiCallCount
}) => {
  const t = translations[lang];

  const navItems: Array<{ id: ViewType; label: string; icon: React.ComponentType<{ className?: string }> }> = [
    { id: 'dashboard', label: t.nav.dashboard, icon: LayoutDashboard },
    { id: 'aiProductSearch', label: t.nav.aiProductSearch, icon: Sparkles },
    { id: 'competitorSearch', label: t.nav.competitorSearch, icon: Search },
    { id: 'productComparison', label: t.nav.productComparison, icon: GitCompare },
    { id: 'priceIntelligence', label: t.nav.priceIntelligence, icon: DollarSign },
    { id: 'furnitureTrends', label: t.nav.furnitureTrends, icon: TrendingUp },
    { id: 'socialIntelligence', label: t.nav.socialIntelligence, icon: Share2 },
    { id: 'opportunities', label: t.nav.opportunities, icon: Lightbulb },
    { id: 'spreadsheetHub', label: t.nav.spreadsheetHub, icon: FileSpreadsheet },
    { id: 'monitoring', label: t.nav.monitoring, icon: Eye },
    { id: 'reports', label: t.nav.reports, icon: FileText },
    { id: 'settings', label: t.nav.settings, icon: Settings },
  ];

  return (
    <aside className="w-64 md:w-72 bg-slate-900 border-r border-slate-800 flex flex-col shrink-0 h-screen sticky top-0 text-slate-200 select-none z-20">
      {/* Brand Header */}
      <div className="p-5 border-b border-slate-800/80 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-lg bg-emerald-500/10 border border-emerald-500/30 flex items-center justify-center text-emerald-400 font-bold text-lg shadow-sm">
            Z
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="font-bold text-base tracking-tight text-white">ZeroIntel</span>
              <span className="text-[10px] tracking-wider uppercase font-semibold text-emerald-400">Kemitt</span>
            </div>
            <p className="text-xs text-slate-400 truncate max-w-[160px]">{t.brandTagline}</p>
          </div>
        </div>
      </div>

      {/* Navigation List */}
      <nav className="flex-1 overflow-y-auto px-3 py-4 space-y-1">
        {navItems.map((item) => {
          const Icon = item.icon;
          const isActive = currentView === item.id;
          return (
            <button
              key={item.id}
              onClick={() => onSelectView(item.id)}
              className={`w-full flex items-center justify-between px-3.5 py-2.5 rounded-lg text-xs md:text-sm font-medium transition-colors text-left rtl:text-right ${
                isActive
                  ? 'bg-emerald-500/15 text-emerald-300 border border-emerald-500/30 shadow-sm'
                  : 'text-slate-400 hover:text-slate-100 hover:bg-slate-800/60'
              }`}
            >
              <div className="flex items-center gap-3 min-w-0">
                <Icon className={`w-4 h-4 shrink-0 ${isActive ? 'text-emerald-400' : 'text-slate-400'}`} />
                <span className="truncate">{item.label}</span>
              </div>
              {isActive && (
                <div className="w-1.5 h-1.5 rounded-full bg-emerald-400 shrink-0" />
              )}
            </button>
          );
        })}
      </nav>

      {/* Zero-Cost Guard Banner */}
      <div className="p-3 border-t border-slate-800/80">
        <button
          onClick={onOpenGuardModal}
          className="w-full text-left rtl:text-right p-3 rounded-lg bg-slate-800/50 hover:bg-slate-800 border border-slate-700/60 transition-colors group"
        >
          <div className="flex items-center justify-between mb-1.5">
            <div className="flex items-center gap-2">
              <ShieldCheck className="w-4 h-4 text-emerald-400" />
              <span className="text-xs font-semibold text-white tracking-wide">
                {t.zeroCostGuard.badge}
              </span>
            </div>
            <span className="text-[11px] font-mono tabular-nums text-emerald-400 font-medium">
              $0.00
            </span>
          </div>
          <div className="flex items-center justify-between text-[11px] text-slate-400">
            <span>Gemini Free Quota</span>
            <span className="font-mono tabular-nums">{apiCallCount} reqs</span>
          </div>
        </button>

        {/* Global Controls: Theme & Language */}
        <div className="mt-2.5 pt-2 border-t border-slate-800 flex items-center justify-between px-1">
          <div className="flex items-center gap-2">
            <button
              onClick={onToggleTheme}
              className="p-1.5 rounded-md hover:bg-slate-800 text-slate-400 hover:text-slate-200 transition-colors"
              title={theme === 'dark' ? t.settings.lightMode : t.settings.darkMode}
              aria-label="Toggle Theme"
            >
              {theme === 'dark' ? <Sun className="w-4 h-4" /> : <Moon className="w-4 h-4" />}
            </button>
            <button
              onClick={onToggleLang}
              className="flex items-center gap-1 px-2 py-1 rounded-md hover:bg-slate-800 text-slate-300 text-xs transition-colors"
              title="Change Language / تغيير اللغة"
              aria-label="Toggle Language"
            >
              <Languages className="w-3.5 h-3.5" />
              <span className="font-medium uppercase">{lang === 'en' ? 'العربية' : 'EN'}</span>
            </button>
          </div>
          <a
            href="https://kemitt.com"
            target="_blank"
            rel="noopener noreferrer"
            className="text-[11px] text-slate-400 hover:text-emerald-400 flex items-center gap-1 transition-colors"
          >
            <span>kemitt.com</span>
            <ExternalLink className="w-3 h-3" />
          </a>
        </div>
      </div>
    </aside>
  );
};
