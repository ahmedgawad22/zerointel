import React from 'react';
import { ViewType } from './Sidebar';
import { translations } from '../locales/translations';
import { Plus, ShieldCheck, Menu, Search, Database } from 'lucide-react';

interface TopHeaderProps {
  currentView: ViewType;
  lang: 'en' | 'ar';
  onOpenAddProduct: () => void;
  onOpenGuardModal: () => void;
  onToggleMobileMenu?: () => void;
  productCount: number;
}

export const TopHeader: React.FC<TopHeaderProps> = ({
  currentView,
  lang,
  onOpenAddProduct,
  onOpenGuardModal,
  onToggleMobileMenu,
  productCount
}) => {
  const t = translations[lang];

  const getBreadcrumbTitle = (view: ViewType): string => {
    switch (view) {
      case 'dashboard':
        return t.nav.dashboard;
      case 'aiProductSearch':
        return t.nav.aiProductSearch;
      case 'competitorSearch':
        return t.nav.competitorSearch;
      case 'productComparison':
        return t.nav.productComparison;
      case 'priceIntelligence':
        return t.nav.priceIntelligence;
      case 'furnitureTrends':
        return t.nav.furnitureTrends;
      case 'socialIntelligence':
        return t.nav.socialIntelligence;
      case 'opportunities':
        return t.nav.opportunities;
      case 'spreadsheetHub':
        return t.nav.spreadsheetHub;
      case 'monitoring':
        return t.nav.monitoring;
      case 'reports':
        return t.nav.reports;
      case 'settings':
        return t.nav.settings;
      default:
        return 'Intelligence';
    }
  };

  return (
    <header className="h-16 px-6 bg-white dark:bg-slate-900 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between gap-4 sticky top-0 z-10">
      {/* Left: Mobile Menu + Breadcrumbs */}
      <div className="flex items-center gap-3">
        {onToggleMobileMenu && (
          <button
            onClick={onToggleMobileMenu}
            className="md:hidden p-2 rounded-lg text-slate-500 hover:bg-slate-100 dark:hover:bg-slate-800"
            aria-label="Open menu"
          >
            <Menu className="w-5 h-5" />
          </button>
        )}
        <div className="flex items-center gap-2 text-xs md:text-sm text-slate-500 dark:text-slate-400">
          <span className="font-semibold text-slate-900 dark:text-slate-100">ZeroIntel</span>
          <span aria-hidden="true">/</span>
          <span className="text-slate-700 dark:text-slate-300 font-medium truncate max-w-[180px] md:max-w-none">
            {getBreadcrumbTitle(currentView)}
          </span>
        </div>
      </div>

      {/* Right: Actions */}
      <div className="flex items-center gap-3 shrink-0">
        {/* Local Storage Indicator */}
        <div className="hidden sm:flex items-center gap-1.5 text-xs text-slate-500 dark:text-slate-400 px-2.5 py-1 rounded-md bg-slate-100 dark:bg-slate-800/80">
          <Database className="w-3.5 h-3.5 text-emerald-500" />
          <span className="tabular-nums font-mono">{productCount}</span>
          <span>products in DB</span>
        </div>

        {/* Zero-Cost Guard Quick Button */}
        <button
          onClick={onOpenGuardModal}
          className="hidden md:flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium text-emerald-700 dark:text-emerald-400 bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-800/60 hover:bg-emerald-100 dark:hover:bg-emerald-900/40 transition-colors"
        >
          <ShieldCheck className="w-3.5 h-3.5" />
          <span>$0 Cost Verified</span>
        </button>

        {/* Primary Action Button */}
        <button
          onClick={onOpenAddProduct}
          className="flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold text-white bg-emerald-600 hover:bg-emerald-500 rounded-lg shadow-sm transition-colors whitespace-nowrap"
        >
          <Plus className="w-4 h-4" />
          <span>{t.common.add}</span>
        </button>
      </div>
    </header>
  );
};
