import React from 'react';
import { ShieldCheck, CheckCircle2, Lock, Cpu, Database, Globe, DollarSign, X } from 'lucide-react';
import { translations } from '../locales/translations';
import { HealthStatus } from '../services/gemini';

interface ZeroCostGuardModalProps {
  isOpen: boolean;
  onClose: () => void;
  lang: 'en' | 'ar';
  health: HealthStatus | null;
}

export const ZeroCostGuardModal: React.FC<ZeroCostGuardModalProps> = ({
  isOpen,
  onClose,
  lang,
  health
}) => {
  if (!isOpen) return null;
  const t = translations[lang];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs">
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl shadow-2xl max-w-xl w-full overflow-hidden animate-in fade-in zoom-in-95 duration-150">
        {/* Header */}
        <div className="p-5 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between bg-slate-50 dark:bg-slate-900/50">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-emerald-500/10 border border-emerald-500/30 flex items-center justify-center text-emerald-600 dark:text-emerald-400">
              <ShieldCheck className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base font-bold text-slate-900 dark:text-slate-100">
                {t.zeroCostGuard.title}
              </h2>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                Kemitt Strict $0 Operating Cost Architecture
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 rounded-lg transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 space-y-6">
          {/* Main Status Banner */}
          <div className="p-4 rounded-lg bg-emerald-50 dark:bg-emerald-950/30 border border-emerald-200 dark:border-emerald-800/60 flex items-start justify-between gap-4">
            <div>
              <div className="text-xs font-semibold text-emerald-800 dark:text-emerald-300 uppercase tracking-wider mb-1">
                Zero Financial Footprint
              </div>
              <p className="text-sm text-emerald-900 dark:text-emerald-200">
                Every query, image analysis, search link, and database operation executes with <strong>$0 cloud hosting, $0 subscription fees, and $0 scraping costs</strong>.
              </p>
            </div>
            <div className="text-right shrink-0">
              <div className="text-2xl font-bold font-mono tabular-nums text-emerald-600 dark:text-emerald-400">
                $0.00
              </div>
              <div className="text-[11px] text-emerald-700/80 dark:text-emerald-400/80">Lifetime Cost</div>
            </div>
          </div>

          {/* Architecture Pillars */}
          <div className="space-y-3">
            <h3 className="text-xs font-semibold uppercase tracking-wider text-slate-500 dark:text-slate-400">
              Enforced Free-Tier Infrastructure
            </h3>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              <div className="p-3 rounded-lg border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/40">
                <div className="flex items-center gap-2 mb-1">
                  <Cpu className="w-4 h-4 text-emerald-500" />
                  <span className="text-xs font-semibold text-slate-800 dark:text-slate-200">Gemini 3.8 Flash</span>
                </div>
                <p className="text-[11px] text-slate-500 dark:text-slate-400">
                  Google AI Studio Free Quota (15 requests/min, 1,500/day). Paid models are strictly blocked.
                </p>
                <div className="mt-2 text-[10px] text-slate-400 font-mono">
                  Current Session: {health?.apiCallsThisSession ?? 0} calls
                </div>
              </div>

              <div className="p-3 rounded-lg border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/40">
                <div className="flex items-center gap-2 mb-1">
                  <Database className="w-4 h-4 text-blue-500" />
                  <span className="text-xs font-semibold text-slate-800 dark:text-slate-200">IndexedDB Storage</span>
                </div>
                <p className="text-[11px] text-slate-500 dark:text-slate-400">
                  Local browser storage for products, prices, and trends. No paid cloud database instances or bills.
                </p>
                <div className="mt-2 text-[10px] text-slate-400 font-mono">
                  Status: 100% Client-Side Local
                </div>
              </div>

              <div className="p-3 rounded-lg border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/40">
                <div className="flex items-center gap-2 mb-1">
                  <Globe className="w-4 h-4 text-amber-500" />
                  <span className="text-xs font-semibold text-slate-800 dark:text-slate-200">Public Retailer Queries</span>
                </div>
                <p className="text-[11px] text-slate-500 dark:text-slate-400">
                  Precision search URLs & Google Shopping operators. Replaces brittle, costly residential proxies.
                </p>
                <div className="mt-2 text-[10px] text-slate-400 font-mono">
                  Cost: 0 EGP / 0 USD
                </div>
              </div>

              <div className="p-3 rounded-lg border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/40">
                <div className="flex items-center gap-2 mb-1">
                  <Lock className="w-4 h-4 text-purple-500" />
                  <span className="text-xs font-semibold text-slate-800 dark:text-slate-200">Paid Service Blocker</span>
                </div>
                <p className="text-[11px] text-slate-500 dark:text-slate-400">
                  ZeroIntel prohibits credit card prompts, paid scraping SDKs, and subscription-gated features.
                </p>
                <div className="mt-2 text-[10px] text-slate-400 font-mono">
                  Enforcement: Hardcoded Active
                </div>
              </div>
            </div>
          </div>

          {/* Active Retailers Verified */}
          <div className="p-3 rounded-lg bg-slate-100 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700/60 text-xs">
            <span className="font-semibold text-slate-700 dark:text-slate-300">Supported Egyptian Retailers: </span>
            <span className="text-slate-500 dark:text-slate-400">
              IKEA Egypt, Kemitt, Chic Homz, Hub Furniture, In Your Room, Blend, Efreshli, Kabbani, Amazon Egypt Home.
            </span>
          </div>
        </div>

        {/* Footer */}
        <div className="p-4 border-t border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-900/50 flex justify-end">
          <button
            onClick={onClose}
            className="px-4 py-2 text-xs font-medium text-slate-700 dark:text-slate-200 bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-700 transition-colors"
          >
            {t.common.close}
          </button>
        </div>
      </div>
    </div>
  );
};
