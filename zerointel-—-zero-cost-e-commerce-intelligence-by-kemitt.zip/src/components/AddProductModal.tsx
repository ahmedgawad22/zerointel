import React, { useState } from 'react';
import { Product, RetailerName, FurnitureCategory } from '../types';
import { translations } from '../locales/translations';
import { X, Plus, Trash2 } from 'lucide-react';

interface AddProductModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (product: Product) => void;
  lang: 'en' | 'ar';
  existingProduct?: Product | null;
  kemittProducts: Product[];
}

const RETAILERS: RetailerName[] = [
  'Kemitt',
  'IKEA Egypt',
  'Chic Homz',
  'Hub Furniture',
  'In Your Room',
  'Blend Furniture',
  'Efreshli',
  'Kabbani Furniture',
  'Marina Home',
  'Amazon Egypt',
  'Other'
];

const CATEGORIES: FurnitureCategory[] = [
  'Sofas & Sectionals',
  'Armchairs & Accent Chairs',
  'Coffee & Side Tables',
  'Dining Tables',
  'Dining Chairs',
  'Beds & Headboards',
  'Storage & Sideboards',
  'Home Office Desks',
  'Lighting & Décor',
  'Outdoor Furniture'
];

export const AddProductModal: React.FC<AddProductModalProps> = ({
  isOpen,
  onClose,
  onSave,
  lang,
  existingProduct,
  kemittProducts
}) => {
  if (!isOpen) return null;
  const t = translations[lang];

  const [name, setName] = useState(existingProduct?.name || '');
  const [sku, setSku] = useState(existingProduct?.sku || '');
  const [brand, setBrand] = useState<'Kemitt' | 'Competitor'>(existingProduct?.brand || 'Competitor');
  const [retailer, setRetailer] = useState<RetailerName>(existingProduct?.retailer || 'Chic Homz');
  const [category, setCategory] = useState<FurnitureCategory>(existingProduct?.category || 'Sofas & Sectionals');
  const [priceEGP, setPriceEGP] = useState(existingProduct?.priceEGP ? String(existingProduct.priceEGP) : '');
  const [originalPriceEGP, setOriginalPriceEGP] = useState(existingProduct?.originalPriceEGP ? String(existingProduct.originalPriceEGP) : '');
  const [url, setUrl] = useState(existingProduct?.url || '');
  const [imageUrl, setImageUrl] = useState(existingProduct?.imageUrl || '');
  const [materials, setMaterials] = useState<string>(existingProduct?.materials ? existingProduct.materials.join(', ') : '');
  const [dimensions, setDimensions] = useState(existingProduct?.dimensions || '');
  const [style, setStyle] = useState(existingProduct?.style || 'Contemporary');
  const [primaryColor, setPrimaryColor] = useState(existingProduct?.primaryColor || '');
  const [inStock, setInStock] = useState(existingProduct?.inStock ?? true);
  const [notes, setNotes] = useState(existingProduct?.notes || '');
  const [matchedKemittId, setMatchedKemittId] = useState(existingProduct?.matchedKemittId || '');
  const [similarityScore, setSimilarityScore] = useState(existingProduct?.similarityScore ? String(existingProduct.similarityScore) : '80');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim() || !priceEGP) return;

    const parsedPrice = parseFloat(priceEGP);
    const parsedOrig = originalPriceEGP ? parseFloat(originalPriceEGP) : parsedPrice;
    const materialList = materials.split(',').map((m) => m.trim()).filter(Boolean);

    const priceHist = existingProduct?.priceHistory ? [...existingProduct.priceHistory] : [];
    if (priceHist.length === 0 || priceHist[priceHist.length - 1].priceEGP !== parsedPrice) {
      priceHist.push({
        date: new Date().toISOString().split('T')[0],
        priceEGP: parsedPrice,
        note: existingProduct ? 'Manual price update' : 'Initial entry'
      });
    }

    const newProd: Product = {
      id: existingProduct?.id || `${brand === 'Kemitt' ? 'kmt' : 'comp'}-${Date.now()}`,
      sku: sku || `SKU-${Date.now().toString().slice(-6)}`,
      name: name.trim(),
      brand,
      retailer: brand === 'Kemitt' ? 'Kemitt' : retailer,
      category,
      priceEGP: parsedPrice,
      originalPriceEGP: parsedOrig,
      currency: 'EGP',
      url: url.trim() || undefined,
      imageUrl: imageUrl.trim() || undefined,
      materials: materialList,
      dimensions: dimensions.trim() || undefined,
      style: style.trim() || undefined,
      primaryColor: primaryColor.trim() || undefined,
      inStock,
      lastChecked: new Date().toISOString().split('T')[0],
      priceHistory: priceHist,
      notes: notes.trim() || undefined,
      matchedKemittId: brand === 'Competitor' ? matchedKemittId || undefined : undefined,
      similarityScore: brand === 'Competitor' && similarityScore ? parseInt(similarityScore) : undefined
    };

    onSave(newProd);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs overflow-y-auto">
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl shadow-2xl max-w-2xl w-full my-8 overflow-hidden animate-in fade-in zoom-in-95 duration-150">
        <div className="p-5 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between bg-slate-50 dark:bg-slate-900/50">
          <div>
            <h2 className="text-base font-bold text-slate-900 dark:text-slate-100">
              {existingProduct ? t.common.edit : t.common.add}
            </h2>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              Record item in local IndexedDB (zero cloud cost)
            </p>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 rounded-lg transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-6 space-y-4 max-h-[75vh] overflow-y-auto">
          {/* Brand Segment */}
          <div>
            <label className="block text-xs font-semibold uppercase tracking-wider text-slate-600 dark:text-slate-400 mb-1.5">
              Product Owner / Type
            </label>
            <div className="grid grid-cols-2 gap-2 p-1 bg-slate-100 dark:bg-slate-800 rounded-lg">
              <button
                type="button"
                onClick={() => { setBrand('Kemitt'); setRetailer('Kemitt'); }}
                className={`py-1.5 text-xs font-semibold rounded-md transition-colors ${
                  brand === 'Kemitt'
                    ? 'bg-emerald-600 text-white shadow-sm'
                    : 'text-slate-600 dark:text-slate-300 hover:text-slate-900'
                }`}
              >
                Kemitt (Our Product)
              </button>
              <button
                type="button"
                onClick={() => setBrand('Competitor')}
                className={`py-1.5 text-xs font-semibold rounded-md transition-colors ${
                  brand === 'Competitor'
                    ? 'bg-slate-900 dark:bg-slate-700 text-white shadow-sm'
                    : 'text-slate-600 dark:text-slate-300 hover:text-slate-900'
                }`}
              >
                Competitor Product
              </button>
            </div>
          </div>

          {/* Title & SKU */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
            <div className="md:col-span-2">
              <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                Product Name *
              </label>
              <input
                type="text"
                required
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="e.g. Luna Curved Bouclé Armchair"
                className="w-full px-3 py-2 text-xs md:text-sm bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-lg focus:outline-none focus:border-emerald-500 text-slate-900 dark:text-slate-100"
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                SKU / Reference
              </label>
              <input
                type="text"
                value={sku}
                onChange={(e) => setSku(e.target.value)}
                placeholder="e.g. KMT-LUNA-01"
                className="w-full px-3 py-2 text-xs md:text-sm bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-lg focus:outline-none focus:border-emerald-500 text-slate-900 dark:text-slate-100"
              />
            </div>
          </div>

          {/* Retailer & Category */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            {brand === 'Competitor' && (
              <div>
                <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                  Competitor Retailer
                </label>
                <select
                  value={retailer}
                  onChange={(e) => setRetailer(e.target.value as RetailerName)}
                  className="w-full px-3 py-2 text-xs md:text-sm bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-lg focus:outline-none focus:border-emerald-500 text-slate-900 dark:text-slate-100"
                >
                  {RETAILERS.filter((r) => r !== 'Kemitt').map((r) => (
                    <option key={r} value={r}>{r}</option>
                  ))}
                </select>
              </div>
            )}
            <div className={brand === 'Kemitt' ? 'md:col-span-2' : ''}>
              <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                Category
              </label>
              <select
                value={category}
                onChange={(e) => setCategory(e.target.value as FurnitureCategory)}
                className="w-full px-3 py-2 text-xs md:text-sm bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-lg focus:outline-none focus:border-emerald-500 text-slate-900 dark:text-slate-100"
              >
                {CATEGORIES.map((c) => (
                  <option key={c} value={c}>{c}</option>
                ))}
              </select>
            </div>
          </div>

          {/* Price & Original Price */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                Current Price (EGP) *
              </label>
              <input
                type="number"
                required
                min="0"
                step="50"
                value={priceEGP}
                onChange={(e) => setPriceEGP(e.target.value)}
                placeholder="e.g. 11400"
                className="w-full px-3 py-2 text-xs md:text-sm font-mono tabular-nums bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-lg focus:outline-none focus:border-emerald-500 text-slate-900 dark:text-slate-100"
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                Original / Before Discount (EGP)
              </label>
              <input
                type="number"
                min="0"
                step="50"
                value={originalPriceEGP}
                onChange={(e) => setOriginalPriceEGP(e.target.value)}
                placeholder="e.g. 12800"
                className="w-full px-3 py-2 text-xs md:text-sm font-mono tabular-nums bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-lg focus:outline-none focus:border-emerald-500 text-slate-900 dark:text-slate-100"
              />
            </div>
          </div>

          {/* Materials & Dimensions */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                Materials (comma-separated)
              </label>
              <input
                type="text"
                value={materials}
                onChange={(e) => setMaterials(e.target.value)}
                placeholder="e.g. Bouclé fabric, Beechwood, 33D Foam"
                className="w-full px-3 py-2 text-xs md:text-sm bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-lg focus:outline-none focus:border-emerald-500 text-slate-900 dark:text-slate-100"
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                Dimensions
              </label>
              <input
                type="text"
                value={dimensions}
                onChange={(e) => setDimensions(e.target.value)}
                placeholder="e.g. 82 x 80 x 74 cm"
                className="w-full px-3 py-2 text-xs md:text-sm bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-lg focus:outline-none focus:border-emerald-500 text-slate-900 dark:text-slate-100"
              />
            </div>
          </div>

          {/* Style & Primary Color */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                Design Style
              </label>
              <input
                type="text"
                value={style}
                onChange={(e) => setStyle(e.target.value)}
                placeholder="e.g. Japandi, Mid-Century, Organic"
                className="w-full px-3 py-2 text-xs md:text-sm bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-lg focus:outline-none focus:border-emerald-500 text-slate-900 dark:text-slate-100"
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                Primary Color / Finish
              </label>
              <input
                type="text"
                value={primaryColor}
                onChange={(e) => setPrimaryColor(e.target.value)}
                placeholder="e.g. Warm Ivory / Natural Oak"
                className="w-full px-3 py-2 text-xs md:text-sm bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-lg focus:outline-none focus:border-emerald-500 text-slate-900 dark:text-slate-100"
              />
            </div>
          </div>

          {/* URLs */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                Product URL
              </label>
              <input
                type="url"
                value={url}
                onChange={(e) => setUrl(e.target.value)}
                placeholder="https://..."
                className="w-full px-3 py-2 text-xs md:text-sm bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-lg focus:outline-none focus:border-emerald-500 text-slate-900 dark:text-slate-100"
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                Image URL (optional)
              </label>
              <input
                type="url"
                value={imageUrl}
                onChange={(e) => setImageUrl(e.target.value)}
                placeholder="https://..."
                className="w-full px-3 py-2 text-xs md:text-sm bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-lg focus:outline-none focus:border-emerald-500 text-slate-900 dark:text-slate-100"
              />
            </div>
          </div>

          {/* If Competitor: Matched Kemitt Item & Similarity Score */}
          {brand === 'Competitor' && (
            <div className="p-3 rounded-lg bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 space-y-3">
              <div className="text-xs font-semibold text-slate-800 dark:text-slate-200">
                Benchmark Pairing (for Product Comparison)
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                <div>
                  <label className="block text-[11px] text-slate-600 dark:text-slate-400 mb-1">
                    Matched Kemitt Counterpart
                  </label>
                  <select
                    value={matchedKemittId}
                    onChange={(e) => setMatchedKemittId(e.target.value)}
                    className="w-full px-3 py-2 text-xs bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-md text-slate-900 dark:text-slate-100"
                  >
                    <option value="">-- No Direct Match --</option>
                    {kemittProducts.map((k) => (
                      <option key={k.id} value={k.id}>
                        {k.name} ({k.priceEGP.toLocaleString()} EGP)
                      </option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="block text-[11px] text-slate-600 dark:text-slate-400 mb-1">
                    Similarity Score ({similarityScore}%)
                  </label>
                  <input
                    type="range"
                    min="10"
                    max="100"
                    value={similarityScore}
                    onChange={(e) => setSimilarityScore(e.target.value)}
                    className="w-full accent-emerald-500"
                  />
                </div>
              </div>
            </div>
          )}

          {/* Stock Toggle & Notes */}
          <div className="flex items-center gap-3">
            <label className="flex items-center gap-2 cursor-pointer">
              <input
                type="checkbox"
                checked={inStock}
                onChange={(e) => setInStock(e.target.checked)}
                className="w-4 h-4 text-emerald-600 rounded-sm accent-emerald-500 focus:ring-emerald-500"
              />
              <span className="text-xs font-medium text-slate-700 dark:text-slate-300">
                Product Currently In Stock
              </span>
            </label>
          </div>

          <div>
            <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
              Internal Notes / Egyptian Market Intel
            </label>
            <textarea
              rows={2}
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder="e.g. Lead time 14 days, Damietta workshop production, benchmarked against IKEA..."
              className="w-full px-3 py-2 text-xs md:text-sm bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-lg focus:outline-none focus:border-emerald-500 text-slate-900 dark:text-slate-100"
            />
          </div>

          {/* Buttons */}
          <div className="pt-3 border-t border-slate-200 dark:border-slate-800 flex items-center justify-end gap-2">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-xs font-medium text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-lg transition-colors"
            >
              {t.common.cancel}
            </button>
            <button
              type="submit"
              className="px-4 py-2 text-xs font-semibold text-white bg-emerald-600 hover:bg-emerald-500 rounded-lg transition-colors shadow-sm"
            >
              {t.common.save}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
