import React, { useState } from 'react';
import { Product } from '../types';
import { translations } from '../locales/translations';
import { X, ExternalLink, Calendar, CheckCircle2, AlertCircle, Edit, TrendingDown, TrendingUp, Layers } from 'lucide-react';

interface ProductDetailModalProps {
  product: Product | null;
  onClose: () => void;
  onEdit: (product: Product) => void;
  lang: 'en' | 'ar';
}

export const ProductDetailModal: React.FC<ProductDetailModalProps> = ({
  product,
  onClose,
  onEdit,
  lang
}) => {
  if (!product) return null;
  const t = translations[lang];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs">
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl shadow-2xl max-w-xl w-full overflow-hidden animate-in fade-in zoom-in-95 duration-150 max-h-[85vh] flex flex-col">
        {/* Modal Header */}
        <div className="p-5 border-b border-slate-200 dark:border-slate-800 flex items-start justify-between bg-slate-50 dark:bg-slate-900/50">
          <div>
            <div className="flex items-center gap-2 mb-1 text-xs">
              <span className={`font-semibold ${product.brand === 'Kemitt' ? 'text-emerald-600 dark:text-emerald-400' : 'text-slate-600 dark:text-slate-400'}`}>
                {product.retailer}
              </span>
              <span aria-hidden="true" className="text-slate-300 dark:text-slate-700">·</span>
              <span className="text-slate-500 dark:text-slate-400">{product.category}</span>
              <span aria-hidden="true" className="text-slate-300 dark:text-slate-700">·</span>
              <span className="font-mono text-slate-400">{product.sku}</span>
            </div>
            <h2 className="text-base md:text-lg font-bold text-slate-900 dark:text-slate-100">
              {product.name}
            </h2>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 rounded-lg transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-6 overflow-y-auto space-y-6">
          {/* Price & Stock Strip */}
          <div className="p-4 rounded-lg bg-slate-50 dark:bg-slate-800/40 border border-slate-200 dark:border-slate-800 flex items-center justify-between">
            <div>
              <div className="text-xs text-slate-500 dark:text-slate-400 mb-0.5">Current Retail Price</div>
              <div className="text-2xl font-bold font-mono tabular-nums text-slate-900 dark:text-slate-100">
                {product.priceEGP.toLocaleString()} <span className="text-sm font-sans font-medium text-slate-500">EGP</span>
              </div>
              {product.originalPriceEGP && product.originalPriceEGP > product.priceEGP && (
                <div className="text-xs text-slate-400 line-through font-mono tabular-nums">
                  {product.originalPriceEGP.toLocaleString()} EGP
                </div>
              )}
            </div>
            <div className="text-right">
              <div className="flex items-center gap-1.5 justify-end text-xs font-medium">
                {product.inStock ? (
                  <>
                    <CheckCircle2 className="w-4 h-4 text-emerald-500" />
                    <span className="text-emerald-700 dark:text-emerald-400">In Stock</span>
                  </>
                ) : (
                  <>
                    <AlertCircle className="w-4 h-4 text-rose-500" />
                    <span className="text-rose-600 dark:text-rose-400">Out of Stock</span>
                  </>
                )}
              </div>
              <div className="text-[11px] text-slate-400 mt-1">
                Last checked: {product.lastChecked}
              </div>
            </div>
          </div>

          {/* Specifications Grid */}
          <div className="grid grid-cols-2 gap-3 text-xs">
            <div className="p-3 rounded-lg border border-slate-200 dark:border-slate-800">
              <span className="text-slate-400 block mb-1">Design Style</span>
              <span className="font-medium text-slate-800 dark:text-slate-200">
                {product.style || 'Contemporary'}
              </span>
            </div>
            <div className="p-3 rounded-lg border border-slate-200 dark:border-slate-800">
              <span className="text-slate-400 block mb-1">Primary Color / Finish</span>
              <span className="font-medium text-slate-800 dark:text-slate-200">
                {product.primaryColor || 'Standard'}
              </span>
            </div>
            <div className="p-3 rounded-lg border border-slate-200 dark:border-slate-800">
              <span className="text-slate-400 block mb-1">Dimensions</span>
              <span className="font-mono font-medium text-slate-800 dark:text-slate-200">
                {product.dimensions || 'N/A'}
              </span>
            </div>
            <div className="p-3 rounded-lg border border-slate-200 dark:border-slate-800">
              <span className="text-slate-400 block mb-1">Similarity Rating</span>
              <span className="font-mono font-medium text-slate-800 dark:text-slate-200">
                {product.similarityScore ? `${product.similarityScore}%` : 'Benchmark Item'}
              </span>
            </div>
          </div>

          {/* Materials */}
          {product.materials && product.materials.length > 0 && (
            <div>
              <h4 className="text-xs font-semibold text-slate-500 dark:text-slate-400 uppercase tracking-wider mb-2">
                Materials & Composition
              </h4>
              <div className="flex flex-wrap gap-1.5 text-xs">
                {product.materials.map((mat, i) => (
                  <span
                    key={i}
                    className="px-2.5 py-1 rounded bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300"
                  >
                    {mat}
                  </span>
                ))}
              </div>
            </div>
          )}

          {/* Historical Price Timeline */}
          <div>
            <h4 className="text-xs font-semibold text-slate-500 dark:text-slate-400 uppercase tracking-wider mb-2">
              Price History Log
            </h4>
            {product.priceHistory && product.priceHistory.length > 0 ? (
              <div className="space-y-2 border border-slate-200 dark:border-slate-800 rounded-lg divide-y divide-slate-100 dark:divide-slate-800 overflow-hidden text-xs">
                {product.priceHistory.map((rec, i) => (
                  <div key={i} className="p-2.5 flex items-center justify-between bg-slate-50/50 dark:bg-slate-800/20">
                    <div className="flex items-center gap-2">
                      <Calendar className="w-3.5 h-3.5 text-slate-400" />
                      <span className="font-mono text-slate-600 dark:text-slate-400">{rec.date}</span>
                      {rec.note && (
                        <span className="text-slate-500 dark:text-slate-400 italic">· {rec.note}</span>
                      )}
                    </div>
                    <div className="font-mono font-semibold tabular-nums text-slate-900 dark:text-slate-100">
                      {rec.priceEGP.toLocaleString()} EGP
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <p className="text-xs text-slate-400 italic">No historical price entries recorded yet.</p>
            )}
          </div>

          {/* Notes */}
          {product.notes && (
            <div className="p-3 rounded-lg bg-amber-50 dark:bg-amber-950/20 border border-amber-200 dark:border-amber-900/40 text-xs">
              <span className="font-semibold text-amber-900 dark:text-amber-300 block mb-0.5">Intelligence Notes:</span>
              <p className="text-amber-800 dark:text-amber-200">{product.notes}</p>
            </div>
          )}
        </div>

        {/* Modal Footer */}
        <div className="p-4 border-t border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-900/50 flex items-center justify-between">
          <div>
            {product.url ? (
              <a
                href={product.url}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-1.5 text-xs font-medium text-emerald-600 dark:text-emerald-400 hover:underline"
              >
                <span>View on {product.retailer}</span>
                <ExternalLink className="w-3.5 h-3.5" />
              </a>
            ) : (
              <span className="text-xs text-slate-400">No public URL recorded</span>
            )}
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={() => {
                onClose();
                onEdit(product);
              }}
              className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-slate-700 dark:text-slate-300 bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-700 transition-colors"
            >
              <Edit className="w-3.5 h-3.5" />
              <span>{t.common.edit}</span>
            </button>
            <button
              onClick={onClose}
              className="px-4 py-1.5 text-xs font-semibold text-white bg-slate-900 dark:bg-slate-800 hover:bg-slate-800 dark:hover:bg-slate-700 rounded-lg transition-colors"
            >
              {t.common.close}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
