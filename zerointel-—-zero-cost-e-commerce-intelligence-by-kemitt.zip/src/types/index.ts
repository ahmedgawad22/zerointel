export type RetailerName =
  | 'Kemitt'
  | 'IKEA Egypt'
  | 'Chic Homz'
  | 'Hub Furniture'
  | 'In Your Room'
  | 'Blend Furniture'
  | 'Efreshli'
  | 'Kabbani Furniture'
  | 'Marina Home'
  | 'Amazon Egypt'
  | 'Other';

export type FurnitureCategory =
  | 'Sofas & Sectionals'
  | 'Armchairs & Accent Chairs'
  | 'Coffee & Side Tables'
  | 'Dining Tables'
  | 'Dining Chairs'
  | 'Beds & Headboards'
  | 'Storage & Sideboards'
  | 'Home Office Desks'
  | 'Lighting & Décor'
  | 'Outdoor Furniture';

export interface PriceRecord {
  date: string;
  priceEGP: number;
  note?: string;
  sourceUrl?: string;
}

export interface Product {
  id: string;
  sku: string;
  name: string;
  brand: 'Kemitt' | 'Competitor';
  retailer: RetailerName;
  category: FurnitureCategory;
  priceEGP: number;
  originalPriceEGP?: number;
  currency: 'EGP';
  url?: string;
  imageUrl?: string;
  materials: string[];
  dimensions?: string;
  style?: string;
  primaryColor?: string;
  colors?: string[];
  inStock: boolean;
  lastChecked: string;
  priceHistory: PriceRecord[];
  notes?: string;
  matchedKemittId?: string;
  similarityScore?: number; // 0 - 100
  egyptianMarketFit?: string;
}

export interface TrendItem {
  id: string;
  title: string;
  macroMovement: string;
  stage: 'Emerging' | 'Accelerating' | 'Peak Mainstream' | 'Declining';
  egyptianMarketFit: {
    viabilityScore: 'High' | 'Medium' | 'Niche';
    targetAudience: string;
    localProductionFeasibility: string;
    priceAcceptanceEGP: string;
  };
  keyDesignElements: string[];
  recommendedKemittAction: string;
  dateAdded: string;
  source?: string;
  tags: string[];
  imageUrl?: string;
}

export interface OpportunityItem {
  id: string;
  title: string;
  category: FurnitureCategory;
  targetPriceBandEGP: string;
  competitorBenchmark: string;
  opportunityType: 'Whitespace Gap' | 'Margin Optimization' | 'Trend Capitalization' | 'Defensive Alternative';
  rationale: string;
  recommendedMaterials: string;
  expectedImpact: 'High' | 'Medium' | 'Strategic';
  status: 'Identified' | 'Under Evaluation' | 'Prototype' | 'Archived';
  dateCreated: string;
}

export interface MonitoringItem {
  id: string;
  productId: string;
  productName: string;
  retailer: RetailerName;
  url: string;
  lastKnownPriceEGP: number;
  currentPriceEGP: number;
  lastCheckedDate: string;
  status: 'In Stock' | 'Out of Stock' | 'Price Changed' | 'Discontinued';
  changePercent: number;
  auditNotes: string[];
}

export interface AppSettings {
  theme: 'dark' | 'light';
  language: 'en' | 'ar';
  currency: 'EGP';
  zeroCostGuardActive: boolean;
}

export interface AIAnalysisResult {
  productName: string;
  category: string;
  designStyle: string;
  materials: string[];
  primaryColor: string;
  secondaryColors: string[];
  shape: string;
  estimatedDimensions: string;
  visualCharacteristics: string[];
  egyptianMarketSuitability: string;
  recommendedKemittPriceBandEGP: {
    min: number;
    max: number;
    rationale: string;
  };
  searchQueries: {
    english: string[];
    arabic: string[];
  };
}

export interface GeneratedQueriesResult {
  exactQueries: string[];
  arabicQueries: string[];
  retailerSearchUrls: Array<{
    retailer: string;
    searchUrl: string;
    directSiteSearchUrl: string;
    notes: string;
  }>;
}
