import { Product, TrendItem, OpportunityItem, MonitoringItem, AppSettings } from '../types';

const DB_NAME = 'zerointel_kemitt_db';
const DB_VERSION = 1;

// Realistic, authenticated seed data for Kemitt & the Egyptian Furniture Retail Market
export const DEFAULT_KEMITT_PRODUCTS: Product[] = [
  {
    id: 'kmt-001',
    sku: 'KMT-LUNA-BOUCLE',
    name: 'Luna Curved Bouclé Accent Armchair',
    brand: 'Kemitt',
    retailer: 'Kemitt',
    category: 'Armchairs & Accent Chairs',
    priceEGP: 11400,
    originalPriceEGP: 12800,
    currency: 'EGP',
    url: 'https://kemitt.com/products/luna-boucle-chair',
    materials: ['Turkish Ivory Bouclé Fabric', 'Romanian Solid Beech Wood Frame', 'High-Resilience 33D Foam'],
    dimensions: '82 x 80 x 74 cm',
    style: 'Contemporary Organic',
    primaryColor: 'Warm Ivory',
    colors: ['Ivory', 'Oatmeal', 'Sage'],
    inStock: true,
    lastChecked: '2026-11-04',
    priceHistory: [
      { date: '2026-08-10', priceEGP: 12800, note: 'Initial Catalog Launch' },
      { date: '2026-10-15', priceEGP: 11400, note: 'Fall Promotion Adjustment' }
    ],
    notes: 'Kemitt top-selling accent chair. Manufactured in Damietta & Cairo workshops.',
    egyptianMarketFit: 'Very high demand among New Cairo and Sheikh Zayed modern apartment owners.'
  },
  {
    id: 'kmt-002',
    sku: 'KMT-HORIZON-SOFA',
    name: 'Horizon 3-Seater Deep Modular Sofa',
    brand: 'Kemitt',
    retailer: 'Kemitt',
    category: 'Sofas & Sectionals',
    priceEGP: 29800,
    originalPriceEGP: 32000,
    currency: 'EGP',
    url: 'https://kemitt.com/products/horizon-modular-sofa',
    materials: ['Textured Linen Blend Fabric', 'Kiln-Dried Beechwood Frame', 'Pocket Spring & Feather Down Topping'],
    dimensions: '240 x 105 x 82 cm',
    style: 'Minimalist Japandi',
    primaryColor: 'Sand Beige',
    colors: ['Sand Beige', 'Charcoal Grey', 'Olive'],
    inStock: true,
    lastChecked: '2026-11-04',
    priceHistory: [
      { date: '2026-07-01', priceEGP: 32000, note: 'Base Launch Price' },
      { date: '2026-09-20', priceEGP: 29800, note: 'Optimized Manufacturing Batch' }
    ],
    notes: 'Modular pieces can be rearranged for flexible Cairo living rooms.'
  },
  {
    id: 'kmt-003',
    sku: 'KMT-TRAV-TABLE',
    name: 'Alabaster Travertine Coffee Table with Oak Plinth',
    brand: 'Kemitt',
    retailer: 'Kemitt',
    category: 'Coffee & Side Tables',
    priceEGP: 13900,
    originalPriceEGP: 14500,
    currency: 'EGP',
    url: 'https://kemitt.com/products/alabaster-coffee-table',
    materials: ['Honed Egyptian Travertine Stone', 'Natural White Oak Veneer Plinth'],
    dimensions: '110 x 60 x 38 cm',
    style: 'Modern Architectural',
    primaryColor: 'Honed Cream Travertine',
    colors: ['Cream Travertine', 'Galala Beige'],
    inStock: true,
    lastChecked: '2026-11-03',
    priceHistory: [
      { date: '2026-09-12', priceEGP: 14500, note: 'Quarry Stone Batch 1' },
      { date: '2026-10-30', priceEGP: 13900, note: 'Direct Egyptian Quarry Sourcing' }
    ],
    notes: 'Sourced from local Egyptian quarries in Beni Suef, finished in Cairo.'
  },
  {
    id: 'kmt-004',
    sku: 'KMT-NORDIC-DINING',
    name: 'Oslo Solid Oak Extendable Dining Table',
    brand: 'Kemitt',
    retailer: 'Kemitt',
    category: 'Dining Tables',
    priceEGP: 22500,
    originalPriceEGP: 24000,
    currency: 'EGP',
    url: 'https://kemitt.com/products/oslo-dining-table',
    materials: ['Solid Natural Oak', 'German Extension Hardware', 'Matte Polyurethane Protective Finish'],
    dimensions: '180-240 x 95 x 76 cm',
    style: 'Scandinavian Modern',
    primaryColor: 'Natural Oak',
    colors: ['Natural Oak', 'Smoked Walnut'],
    inStock: true,
    lastChecked: '2026-11-04',
    priceHistory: [
      { date: '2026-08-01', priceEGP: 24000, note: 'Initial Release' },
      { date: '2026-10-01', priceEGP: 22500, note: 'Dining Season Campaign' }
    ],
    notes: 'Seats 6 to 10 guests. High demand during Ramadan & family gathering seasons.'
  },
  {
    id: 'kmt-005',
    sku: 'KMT-KOTO-CHAIR',
    name: 'Koto Curved Cane & Beech Dining Chair (Set of 2)',
    brand: 'Kemitt',
    retailer: 'Kemitt',
    category: 'Dining Chairs',
    priceEGP: 7800,
    originalPriceEGP: 8400,
    currency: 'EGP',
    url: 'https://kemitt.com/products/koto-dining-chair',
    materials: ['Natural Handwoven Cane/Rattan', 'Solid Steam-Bent Beech Wood', 'Linen Padded Seat'],
    dimensions: '52 x 54 x 80 cm',
    style: 'Mid-Century Modern',
    primaryColor: 'Natural Beech & Cane',
    colors: ['Natural', 'Black Beech'],
    inStock: true,
    lastChecked: '2026-11-02',
    priceHistory: [
      { date: '2026-08-15', priceEGP: 8400, note: 'Launch Price' },
      { date: '2026-10-10', priceEGP: 7800, note: 'Volume Bundle Pricing' }
    ],
    notes: 'Sold as set of 2 chairs (3,900 EGP per chair).'
  }
];

export const DEFAULT_COMPETITOR_PRODUCTS: Product[] = [
  {
    id: 'comp-ikea-01',
    sku: 'IKEA-LANDSKRONA-3S',
    name: 'LANDSKRONA 3-seat sofa with metal legs',
    brand: 'Competitor',
    retailer: 'IKEA Egypt',
    category: 'Sofas & Sectionals',
    priceEGP: 38450,
    originalPriceEGP: 38450,
    currency: 'EGP',
    url: 'https://www.ikea.com/eg/en/p/landskrona-three-seat-sofa-gunnared-dark-grey-metal-s19270312/',
    materials: ['Polyester Gunnared Fabric', 'Plywood and particleboard frame', 'Steel Chrome Legs'],
    dimensions: '204 x 89 x 78 cm',
    style: 'Scandinavian Modern',
    primaryColor: 'Dark Grey',
    colors: ['Dark Grey', 'Light Green'],
    inStock: true,
    lastChecked: '2026-11-04',
    priceHistory: [
      { date: '2026-06-15', priceEGP: 36500, note: 'Early 2026 Price' },
      { date: '2026-09-01', priceEGP: 38450, note: 'Import Currency Tariff Update' }
    ],
    notes: 'IKEA import pricing benchmark. Flat-packed assembly required.',
    matchedKemittId: 'kmt-002',
    similarityScore: 82
  },
  {
    id: 'comp-chichomz-01',
    sku: 'CHIC-BOUCLE-ARM',
    name: 'Chic Homz Cozy Bouclé Curved Armchair',
    brand: 'Competitor',
    retailer: 'Chic Homz',
    category: 'Armchairs & Accent Chairs',
    priceEGP: 13200,
    originalPriceEGP: 14800,
    currency: 'EGP',
    url: 'https://chichomz.com/products/cozy-boucle-armchair',
    materials: ['Bouclé Fabric', 'Beechwood Frame', 'Sponge 30'],
    dimensions: '80 x 78 x 75 cm',
    style: 'Contemporary Organic',
    primaryColor: 'Off-White',
    colors: ['Off-White', 'Beige'],
    inStock: true,
    lastChecked: '2026-11-03',
    priceHistory: [
      { date: '2026-08-20', priceEGP: 14800, note: 'Recorded on Chic Homz' },
      { date: '2026-10-25', priceEGP: 13200, note: 'Flash discount campaign' }
    ],
    notes: 'Direct competitor to Kemitt Luna chair. Delivery time listed as 14-21 days.',
    matchedKemittId: 'kmt-001',
    similarityScore: 91
  },
  {
    id: 'comp-hub-01',
    sku: 'HUB-OVAL-MARBLE',
    name: 'Hub Furniture Verona Marble Top Coffee Table',
    brand: 'Competitor',
    retailer: 'Hub Furniture',
    category: 'Coffee & Side Tables',
    priceEGP: 18500,
    originalPriceEGP: 18500,
    currency: 'EGP',
    url: 'https://hubfurniture.com.eg/products/verona-coffee-table',
    materials: ['Turkish Carrara Marble', 'Oak Wood Stained Black Base'],
    dimensions: '120 x 65 x 42 cm',
    style: 'Modern Architectural',
    primaryColor: 'White Marble with Grey Veins',
    colors: ['White Carrara'],
    inStock: true,
    lastChecked: '2026-11-04',
    priceHistory: [
      { date: '2026-07-10', priceEGP: 17200, note: 'Summer collection' },
      { date: '2026-09-15', priceEGP: 18500, note: 'New season price' }
    ],
    notes: 'High margin showroom item in Hub Heliopolis & New Cairo branches.',
    matchedKemittId: 'kmt-003',
    similarityScore: 84
  },
  {
    id: 'comp-iyr-01',
    sku: 'IYR-CANE-DINING-2X',
    name: 'In Your Room Rattan Weave Dining Chairs (Pair)',
    brand: 'Competitor',
    retailer: 'In Your Room',
    category: 'Dining Chairs',
    priceEGP: 9600,
    originalPriceEGP: 10500,
    currency: 'EGP',
    url: 'https://inyourroom.com/products/rattan-dining-chair-pair',
    materials: ['Natural Cane Mesh', 'Beech Wood', 'Linen Cushion'],
    dimensions: '50 x 52 x 82 cm',
    style: 'Mid-Century Modern',
    primaryColor: 'Natural Oak',
    colors: ['Natural', 'Walnut'],
    inStock: false,
    lastChecked: '2026-11-04',
    priceHistory: [
      { date: '2026-08-01', priceEGP: 10500, note: 'Listed on website' },
      { date: '2026-10-18', priceEGP: 9600, note: 'Stock clearance before out of stock' }
    ],
    notes: 'Currently listed as Out of Stock on retailer site. Opportunity for Kemitt to capture demand.',
    matchedKemittId: 'kmt-005',
    similarityScore: 88
  },
  {
    id: 'comp-blend-01',
    sku: 'BLEND-OSLO-DINING',
    name: 'Blend Furniture Nordic Minimalist Dining Table',
    brand: 'Competitor',
    retailer: 'Blend Furniture',
    category: 'Dining Tables',
    priceEGP: 34000,
    originalPriceEGP: 34000,
    currency: 'EGP',
    url: 'https://blendfurniture.com/products/nordic-dining-table',
    materials: ['European White Oak Solid Top', 'Steel Sub-Structure'],
    dimensions: '200 x 100 x 75 cm',
    style: 'Scandinavian Modern',
    primaryColor: 'Natural European Oak',
    colors: ['Natural Oak'],
    inStock: true,
    lastChecked: '2026-11-02',
    priceHistory: [
      { date: '2026-05-10', priceEGP: 32000, note: 'Catalog base' },
      { date: '2026-08-20', priceEGP: 34000, note: 'Imported timber surcharge' }
    ],
    notes: 'Luxury tier positioning in Cairo design boutiques.',
    matchedKemittId: 'kmt-004',
    similarityScore: 79
  }
];

export const DEFAULT_TRENDS: TrendItem[] = [
  {
    id: 'trd-001',
    title: 'Curved Organic Bouclé & Low-Slung Living',
    macroMovement: 'Tactile Warm Minimalism',
    stage: 'Peak Mainstream',
    egyptianMarketFit: {
      viabilityScore: 'High',
      targetAudience: 'Couples aged 26-42 furnishing apartments in New Cairo, Zayed, and October City.',
      localProductionFeasibility: 'High feasibility: Egyptian workshops in Damietta and El-Basatin handle beech frame bending with imported bouclé fabric.',
      priceAcceptanceEGP: '10,000 to 28,000 EGP depending on single chair vs 3-seater sofa.'
    },
    keyDesignElements: [
      'Sculptural curved silhouettes with no harsh corners',
      'Nubby, tactile bouclé upholstery in cream, oatmeal, and olive',
      'Low ground clearance with concealed wooden feet or recessed plinths'
    ],
    recommendedKemittAction: 'Expand Kemitt Luna armchair line with 2 companion sectional sofas in cream and sage bouclé.',
    dateAdded: '2026-11-01',
    source: 'Instagram Cairo Interior Designers & TikTok Living Hubs',
    tags: ['Boucle', 'Curved Sofa', 'Organic Shapes', 'Cairo Modern']
  },
  {
    id: 'trd-002',
    title: 'Honed Egyptian Travertine & Galala Marble Tables',
    macroMovement: 'Biophilic Earth Stones',
    stage: 'Accelerating',
    egyptianMarketFit: {
      viabilityScore: 'High',
      targetAudience: 'Design-conscious homeowners seeking luxury aesthetic without imported marble price tag.',
      localProductionFeasibility: 'Exceptional: Egypt is a world-class producer of natural Travertine (Beni Suef) and Galala stone; zero customs duty.',
      priceAcceptanceEGP: '9,500 to 18,000 EGP for statement coffee tables.'
    },
    keyDesignElements: [
      'Matte honed finish (non-glossy, raw architectural feel)',
      'Substantial cylinder or fluted pedestal legs',
      'Warm beige, sand, and cream earthen color palettes'
    ],
    recommendedKemittAction: 'Launch direct quarry partnership for Beni Suef travertine to undercut Hub Furniture marble prices by 25%.',
    dateAdded: '2026-11-02',
    source: 'Pinterest Trends & Cairo Design Week Highlights',
    tags: ['Travertine', 'Local Sourcing', 'Coffee Table', 'Luxury Stone']
  },
  {
    id: 'trd-003',
    title: 'Fluted Wood Tambour & Reeding on Sideboards & Vanities',
    macroMovement: 'Artisan Architectural Millwork',
    stage: 'Peak Mainstream',
    egyptianMarketFit: {
      viabilityScore: 'High',
      targetAudience: 'Homeowners wanting texture and acoustic softness in modern open-plan reception rooms.',
      localProductionFeasibility: 'Moderate to High: Requires precision CNC wood milling or manual wooden slat alignment on beechwood.',
      priceAcceptanceEGP: '18,000 to 32,000 EGP for full credenzas/buffets.'
    },
    keyDesignElements: [
      'Vertical fluted wooden slats with shadow lines',
      'Integrated hidden push-to-open door mechanisms',
      'Warm walnut and natural oak oil finishes'
    ],
    recommendedKemittAction: 'Introduce a 4-door fluted oak sideboard at 21,500 EGP benchmarked against Blend Furniture at 36,000 EGP.',
    dateAdded: '2026-11-03',
    source: 'Reddit r/InteriorDesign & Local Architect Portfolios',
    tags: ['Fluted Wood', 'Sideboard', 'Tambour', 'Storage']
  }
];

export const DEFAULT_OPPORTUNITIES: OpportunityItem[] = [
  {
    id: 'opp-001',
    title: 'Compact Modular Bouclé Sectional under 32,000 EGP',
    category: 'Sofas & Sectionals',
    targetPriceBandEGP: '28,000 - 32,000 EGP',
    competitorBenchmark: 'IKEA Landskrona at 38,450 EGP (particleboard) / Blend Furniture at 48,000+ EGP',
    opportunityType: 'Whitespace Gap',
    rationale: 'Young homeowners in Cairo apartments need modular flexibility and trendy bouclé. Competitors either sell imported flat-packs or high-end luxury at prohibitive prices.',
    recommendedMaterials: 'Solid beechwood frame, high resilience 33D foam, stain-resistant local/Turkish bouclé.',
    expectedImpact: 'High',
    status: 'Identified',
    dateCreated: '2026-11-04'
  },
  {
    id: 'opp-002',
    title: 'Direct-Quarry Honed Travertine Side Tables (Pair)',
    category: 'Coffee & Side Tables',
    targetPriceBandEGP: '7,500 - 9,200 EGP for pair',
    competitorBenchmark: 'Hub Furniture marble tables at 18,500 EGP each',
    opportunityType: 'Margin Optimization',
    rationale: 'Local Egyptian travertine stone from Beni Suef costs less than 1,200 EGP in raw block form. Kemitt can achieve 55% gross margin while offering customers unmatched value.',
    recommendedMaterials: 'Honed Egyptian travertine slab top with solid wood plinth.',
    expectedImpact: 'High',
    status: 'Under Evaluation',
    dateCreated: '2026-11-04'
  },
  {
    id: 'opp-003',
    title: 'Cane & Beech Dining Chairs in Stock (Fast Delivery)',
    category: 'Dining Chairs',
    targetPriceBandEGP: '3,800 - 4,200 EGP per chair',
    competitorBenchmark: 'In Your Room (9,600 EGP/pair - currently Out of Stock) / Chic Homz (4,800 EGP each)',
    opportunityType: 'Defensive Alternative',
    rationale: 'In Your Room is experiencing stockouts on rattan dining chairs. Kemitt can capture pending Cairo dining room orders by maintaining a ready 10-day dispatch inventory.',
    recommendedMaterials: 'Steam-bent beech wood frame, durable synthetic or natural rattan mesh, linen cushion.',
    expectedImpact: 'Strategic',
    status: 'Prototype',
    dateCreated: '2026-11-03'
  }
];

export const DEFAULT_MONITORING: MonitoringItem[] = [
  {
    id: 'mon-001',
    productId: 'comp-ikea-01',
    productName: 'LANDSKRONA 3-seat sofa with metal legs',
    retailer: 'IKEA Egypt',
    url: 'https://www.ikea.com/eg/en/p/landskrona-three-seat-sofa-gunnared-dark-grey-metal-s19270312/',
    lastKnownPriceEGP: 38450,
    currentPriceEGP: 38450,
    lastCheckedDate: '2026-11-04',
    status: 'In Stock',
    changePercent: 0,
    auditNotes: ['Verified active stock in IKEA Cairo Festival City and Mall of Arabia stores.']
  },
  {
    id: 'mon-002',
    productId: 'comp-chichomz-01',
    productName: 'Chic Homz Cozy Bouclé Curved Armchair',
    retailer: 'Chic Homz',
    url: 'https://chichomz.com/products/cozy-boucle-armchair',
    lastKnownPriceEGP: 14800,
    currentPriceEGP: 13200,
    lastCheckedDate: '2026-11-03',
    status: 'Price Changed',
    changePercent: -10.8,
    auditNotes: ['Chic Homz initiated a 10.8% price cut from 14,800 to 13,200 EGP. Kemitt Luna remains competitive at 11,400 EGP.']
  },
  {
    id: 'mon-003',
    productId: 'comp-iyr-01',
    productName: 'In Your Room Rattan Weave Dining Chairs (Pair)',
    retailer: 'In Your Room',
    url: 'https://inyourroom.com/products/rattan-dining-chair-pair',
    lastKnownPriceEGP: 9600,
    currentPriceEGP: 9600,
    lastCheckedDate: '2026-11-04',
    status: 'Out of Stock',
    changePercent: 0,
    auditNotes: ['Product page displays "Sold Out — Join Waiting List". Kemitt can market Koto Dining Chair as immediate replacement.']
  }
];

export const DEFAULT_SETTINGS: AppSettings = {
  theme: 'dark',
  language: 'en',
  currency: 'EGP',
  zeroCostGuardActive: true
};

class LocalDatabase {
  private dbPromise: Promise<IDBDatabase> | null = null;

  private async open(): Promise<IDBDatabase> {
    if (this.dbPromise) return this.dbPromise;

    this.dbPromise = new Promise((resolve, reject) => {
      const request = indexedDB.open(DB_NAME, DB_VERSION);

      request.onupgradeneeded = (event) => {
        const db = (event.target as IDBOpenDBRequest).result;
        if (!db.objectStoreNames.contains('products')) {
          const store = db.createObjectStore('products', { keyPath: 'id' });
          store.createIndex('retailer', 'retailer', { unique: false });
          store.createIndex('brand', 'brand', { unique: false });
          store.createIndex('category', 'category', { unique: false });
        }
        if (!db.objectStoreNames.contains('trends')) {
          db.createObjectStore('trends', { keyPath: 'id' });
        }
        if (!db.objectStoreNames.contains('opportunities')) {
          db.createObjectStore('opportunities', { keyPath: 'id' });
        }
        if (!db.objectStoreNames.contains('monitoring')) {
          db.createObjectStore('monitoring', { keyPath: 'id' });
        }
        if (!db.objectStoreNames.contains('settings')) {
          db.createObjectStore('settings', { keyPath: 'key' });
        }
      };

      request.onsuccess = async (event) => {
        const db = (event.target as IDBOpenDBRequest).result;
        await this.ensureSeedData(db);
        resolve(db);
      };

      request.onerror = () => {
        reject(request.error);
      };
    });

    return this.dbPromise;
  }

  private async ensureSeedData(db: IDBDatabase): Promise<void> {
    const tx = db.transaction(['products', 'trends', 'opportunities', 'monitoring', 'settings'], 'readwrite');
    const productStore = tx.objectStore('products');
    const countReq = productStore.count();

    countReq.onsuccess = () => {
      if (countReq.result === 0) {
        // Seed default items
        const allProducts = [...DEFAULT_KEMITT_PRODUCTS, ...DEFAULT_COMPETITOR_PRODUCTS];
        allProducts.forEach(p => productStore.put(p));

        const trendStore = tx.objectStore('trends');
        DEFAULT_TRENDS.forEach(t => trendStore.put(t));

        const oppStore = tx.objectStore('opportunities');
        DEFAULT_OPPORTUNITIES.forEach(o => oppStore.put(o));

        const monStore = tx.objectStore('monitoring');
        DEFAULT_MONITORING.forEach(m => monStore.put(m));

        const settingsStore = tx.objectStore('settings');
        settingsStore.put({ key: 'app_settings', value: DEFAULT_SETTINGS });
      }
    };
  }

  // Generic store helper
  private async getAll<T>(storeName: string): Promise<T[]> {
    const db = await this.open();
    return new Promise((resolve, reject) => {
      const tx = db.transaction(storeName, 'readonly');
      const store = tx.objectStore(storeName);
      const req = store.getAll();
      req.onsuccess = () => resolve(req.result as T[]);
      req.onerror = () => reject(req.error);
    });
  }

  private async put<T>(storeName: string, item: T): Promise<void> {
    const db = await this.open();
    return new Promise((resolve, reject) => {
      const tx = db.transaction(storeName, 'readwrite');
      const store = tx.objectStore(storeName);
      const req = store.put(item);
      req.onsuccess = () => resolve();
      req.onerror = () => reject(req.error);
    });
  }

  private async deleteItem(storeName: string, key: string): Promise<void> {
    const db = await this.open();
    return new Promise((resolve, reject) => {
      const tx = db.transaction(storeName, 'readwrite');
      const store = tx.objectStore(storeName);
      const req = store.delete(key);
      req.onsuccess = () => resolve();
      req.onerror = () => reject(req.error);
    });
  }

  // Products
  async getProducts(): Promise<Product[]> {
    return this.getAll<Product>('products');
  }

  async saveProduct(product: Product): Promise<void> {
    return this.put<Product>('products', product);
  }

  async deleteProduct(id: string): Promise<void> {
    return this.deleteItem('products', id);
  }

  // Trends
  async getTrends(): Promise<TrendItem[]> {
    return this.getAll<TrendItem>('trends');
  }

  async saveTrend(trend: TrendItem): Promise<void> {
    return this.put<TrendItem>('trends', trend);
  }

  async deleteTrend(id: string): Promise<void> {
    return this.deleteItem('trends', id);
  }

  // Opportunities
  async getOpportunities(): Promise<OpportunityItem[]> {
    return this.getAll<OpportunityItem>('opportunities');
  }

  async saveOpportunity(opp: OpportunityItem): Promise<void> {
    return this.put<OpportunityItem>('opportunities', opp);
  }

  async deleteOpportunity(id: string): Promise<void> {
    return this.deleteItem('opportunities', id);
  }

  // Monitoring
  async getMonitoringItems(): Promise<MonitoringItem[]> {
    return this.getAll<MonitoringItem>('monitoring');
  }

  async saveMonitoringItem(item: MonitoringItem): Promise<void> {
    return this.put<MonitoringItem>('monitoring', item);
  }

  async deleteMonitoringItem(id: string): Promise<void> {
    return this.deleteItem('monitoring', id);
  }

  // Settings
  async getSettings(): Promise<AppSettings> {
    const db = await this.open();
    return new Promise((resolve) => {
      const tx = db.transaction('settings', 'readonly');
      const store = tx.objectStore('settings');
      const req = store.get('app_settings');
      req.onsuccess = () => {
        if (req.result && req.result.value) {
          resolve(req.result.value);
        } else {
          resolve(DEFAULT_SETTINGS);
        }
      };
      req.onerror = () => resolve(DEFAULT_SETTINGS);
    });
  }

  async saveSettings(settings: AppSettings): Promise<void> {
    const db = await this.open();
    return new Promise((resolve, reject) => {
      const tx = db.transaction('settings', 'readwrite');
      const store = tx.objectStore('settings');
      const req = store.put({ key: 'app_settings', value: settings });
      req.onsuccess = () => resolve();
      req.onerror = () => reject(req.error);
    });
  }

  // Backup & Restore
  async exportAllData(): Promise<string> {
    const products = await this.getProducts();
    const trends = await this.getTrends();
    const opportunities = await this.getOpportunities();
    const monitoring = await this.getMonitoringItems();
    const settings = await this.getSettings();

    const backupPayload = {
      version: 1,
      appName: 'ZeroIntel',
      exportedAt: new Date().toISOString(),
      data: {
        products,
        trends,
        opportunities,
        monitoring,
        settings
      }
    };

    return JSON.stringify(backupPayload, null, 2);
  }

  async importAllData(jsonString: string): Promise<boolean> {
    try {
      const parsed = JSON.parse(jsonString);
      if (!parsed.data) throw new Error('Invalid backup file format');

      const db = await this.open();
      const tx = db.transaction(['products', 'trends', 'opportunities', 'monitoring', 'settings'], 'readwrite');

      if (Array.isArray(parsed.data.products)) {
        const pStore = tx.objectStore('products');
        await new Promise((res) => { pStore.clear().onsuccess = res; });
        parsed.data.products.forEach((p: Product) => pStore.put(p));
      }

      if (Array.isArray(parsed.data.trends)) {
        const tStore = tx.objectStore('trends');
        await new Promise((res) => { tStore.clear().onsuccess = res; });
        parsed.data.trends.forEach((t: TrendItem) => tStore.put(t));
      }

      if (Array.isArray(parsed.data.opportunities)) {
        const oStore = tx.objectStore('opportunities');
        await new Promise((res) => { oStore.clear().onsuccess = res; });
        parsed.data.opportunities.forEach((o: OpportunityItem) => oStore.put(o));
      }

      if (Array.isArray(parsed.data.monitoring)) {
        const mStore = tx.objectStore('monitoring');
        await new Promise((res) => { mStore.clear().onsuccess = res; });
        parsed.data.monitoring.forEach((m: MonitoringItem) => mStore.put(m));
      }

      if (parsed.data.settings) {
        const sStore = tx.objectStore('settings');
        sStore.put({ key: 'app_settings', value: parsed.data.settings });
      }

      return true;
    } catch (e) {
      console.error('Failed to restore data:', e);
      return false;
    }
  }

  async resetToDefaults(): Promise<void> {
    const db = await this.open();
    const tx = db.transaction(['products', 'trends', 'opportunities', 'monitoring', 'settings'], 'readwrite');

    const pStore = tx.objectStore('products');
    pStore.clear();
    const allProducts = [...DEFAULT_KEMITT_PRODUCTS, ...DEFAULT_COMPETITOR_PRODUCTS];
    allProducts.forEach(p => pStore.put(p));

    const tStore = tx.objectStore('trends');
    tStore.clear();
    DEFAULT_TRENDS.forEach(t => tStore.put(t));

    const oStore = tx.objectStore('opportunities');
    oStore.clear();
    DEFAULT_OPPORTUNITIES.forEach(o => oStore.put(o));

    const mStore = tx.objectStore('monitoring');
    mStore.clear();
    DEFAULT_MONITORING.forEach(m => mStore.put(m));

    const sStore = tx.objectStore('settings');
    sStore.put({ key: 'app_settings', value: DEFAULT_SETTINGS });
  }

  async clearAll(): Promise<void> {
    const db = await this.open();
    const tx = db.transaction(['products', 'trends', 'opportunities', 'monitoring'], 'readwrite');
    tx.objectStore('products').clear();
    tx.objectStore('trends').clear();
    tx.objectStore('opportunities').clear();
    tx.objectStore('monitoring').clear();
  }
}

export const localDb = new LocalDatabase();
