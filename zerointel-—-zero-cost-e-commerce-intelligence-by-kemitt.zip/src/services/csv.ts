import { Product, MonitoringItem, OpportunityItem, TrendItem } from '../types';

export class CsvService {
  /**
   * Parse CSV or TSV string into 2D array of strings
   */
  parseRaw(content: string, delimiter?: string): string[][] {
    const lines = content.replace(/\r\n/g, '\n').replace(/\r/g, '\n').split('\n');
    if (lines.length === 0) return [];

    // Auto-detect delimiter if not specified
    if (!delimiter) {
      const firstLine = lines[0];
      const tabs = (firstLine.match(/\t/g) || []).length;
      const commas = (firstLine.match(/,/g) || []).length;
      const semicolons = (firstLine.match(/;/g) || []).length;
      if (tabs > commas && tabs > semicolons) delimiter = '\t';
      else if (semicolons > commas) delimiter = ';';
      else delimiter = ',';
    }

    const rows: string[][] = [];

    for (const line of lines) {
      if (!line.trim()) continue;
      const row: string[] = [];
      let insideQuotes = false;
      let currentValue = '';

      for (let i = 0; i < line.length; i++) {
        const char = line[i];
        const nextChar = line[i + 1];

        if (char === '"') {
          if (insideQuotes && nextChar === '"') {
            currentValue += '"';
            i++; // skip escaped quote
          } else {
            insideQuotes = !insideQuotes;
          }
        } else if (char === delimiter && !insideQuotes) {
          row.push(currentValue.trim());
          currentValue = '';
        } else {
          currentValue += char;
        }
      }
      row.push(currentValue.trim());
      rows.push(row);
    }

    return rows;
  }

  /**
   * Convert array of products to CSV string
   */
  productsToCsv(products: Product[]): string {
    const headers = [
      'ID',
      'SKU',
      'Name',
      'Brand',
      'Retailer',
      'Category',
      'Price EGP',
      'Original Price EGP',
      'In Stock',
      'Materials',
      'Dimensions',
      'Style',
      'Primary Color',
      'URL',
      'Last Checked'
    ];

    const rows = products.map((p) => [
      p.id,
      p.sku || '',
      `"${(p.name || '').replace(/"/g, '""')}"`,
      p.brand,
      p.retailer,
      `"${p.category}"`,
      p.priceEGP,
      p.originalPriceEGP || p.priceEGP,
      p.inStock ? 'Yes' : 'No',
      `"${(p.materials || []).join(', ').replace(/"/g, '""')}"`,
      `"${(p.dimensions || '').replace(/"/g, '""')}"`,
      `"${(p.style || '').replace(/"/g, '""')}"`,
      `"${(p.primaryColor || '').replace(/"/g, '""')}"`,
      p.url || '',
      p.lastChecked || ''
    ]);

    return [headers.join(','), ...rows.map((r) => r.join(','))].join('\n');
  }

  /**
   * Convert price audit records to CSV
   */
  pricingAuditToCsv(products: Product[]): string {
    const headers = ['Product ID', 'Product Name', 'Retailer', 'Brand', 'Category', 'Record Date', 'Price EGP', 'Note'];
    const rows: string[] = [];

    products.forEach((p) => {
      (p.priceHistory || []).forEach((hist) => {
        rows.push([
          p.id,
          `"${(p.name || '').replace(/"/g, '""')}"`,
          p.retailer,
          p.brand,
          `"${p.category}"`,
          hist.date,
          hist.priceEGP,
          `"${(hist.note || '').replace(/"/g, '""')}"`
        ].join(','));
      });
    });

    return [headers.join(','), ...rows].join('\n');
  }

  /**
   * Download a text string as a file in browser
   */
  downloadFile(content: string, filename: string, mimeType = 'text/csv;charset=utf-8;'): void {
    const blob = new Blob([content], { type: mimeType });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.setAttribute('href', url);
    link.setAttribute('download', filename);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  }

  /**
   * Generate Executive Markdown Briefing
   */
  generateMarkdownReport(
    products: Product[],
    opportunities: OpportunityItem[],
    trends: TrendItem[],
    monitoring: MonitoringItem[]
  ): string {
    const kemittProducts = products.filter((p) => p.brand === 'Kemitt');
    const competitorProducts = products.filter((p) => p.brand === 'Competitor');
    const today = new Date().toISOString().split('T')[0];

    const competitorsList = Array.from(new Set(competitorProducts.map((p) => p.retailer)));

    let md = `# ZeroIntel — Executive Furniture Market Intelligence Briefing
**Brand Focus:** Kemitt (Egypt)
**Date:** ${today}
**Architecture:** $0 Operating Cost Local Intelligence Engine

---

## 1. Executive Landscape Overview
- **Kemitt Catalog Items Tracked:** ${kemittProducts.length}
- **Competitor Products Tracked:** ${competitorProducts.length}
- **Monitored Egyptian Competitors:** ${competitorsList.join(', ') || 'None'}
- **Active Trend Signals:** ${trends.length}
- **Identified Product Opportunities:** ${opportunities.length}

---

## 2. Competitive Price Benchmarking (EGP)
| Category | Kemitt Item | Kemitt Price (EGP) | Competitor Match | Retailer | Competitor Price (EGP) | Variance |
| :--- | :--- | :--- | :--- | :--- | :--- | :--- |
`;

    kemittProducts.forEach((k) => {
      const match = competitorProducts.find((c) => c.matchedKemittId === k.id || c.category === k.category);
      if (match) {
        const diff = k.priceEGP - match.priceEGP;
        const diffPercent = ((diff / match.priceEGP) * 100).toFixed(1);
        const status = diff < 0 ? `Kemitt ${Math.abs(Number(diffPercent))}% lower` : `Kemitt +${diffPercent}%`;
        md += `| ${k.category} | ${k.name} | ${k.priceEGP.toLocaleString()} EGP | ${match.name} | ${match.retailer} | ${match.priceEGP.toLocaleString()} EGP | ${status} |\n`;
      }
    });

    md += `\n---\n\n## 3. Top Actionable Product Opportunities\n`;
    opportunities.forEach((opp, i) => {
      md += `### ${i + 1}. ${opp.title} (${opp.category})\n`;
      md += `- **Type:** ${opp.opportunityType}\n`;
      md += `- **Target Retail Band:** ${opp.targetPriceBandEGP}\n`;
      md += `- **Competitor Benchmark:** ${opp.competitorBenchmark}\n`;
      md += `- **Production Rationale:** ${opp.rationale}\n`;
      md += `- **Recommended Materials:** ${opp.recommendedMaterials}\n`;
      md += `- **Impact Rating:** ${opp.expectedImpact}\n\n`;
    });

    md += `---\n\n## 4. Key Furniture Design Trends in Egypt\n`;
    trends.forEach((t) => {
      md += `### ${t.title} [${t.stage}]\n`;
      md += `- **Macro Movement:** ${t.macroMovement}\n`;
      md += `- **Egyptian Market Viability:** ${t.egyptianMarketFit.viabilityScore}\n`;
      md += `- **Target Demographic:** ${t.egyptianMarketFit.targetAudience}\n`;
      md += `- **Local Production Feasibility:** ${t.egyptianMarketFit.localProductionFeasibility}\n`;
      md += `- **Kemitt Merchandising Directive:** ${t.recommendedKemittAction}\n\n`;
    });

    md += `---\n\n## 5. Competitor URL Monitoring Alerts\n`;
    monitoring.forEach((m) => {
      md += `- **[${m.status}] ${m.productName} (${m.retailer}):** Current Price ${m.currentPriceEGP.toLocaleString()} EGP (${m.changePercent !== 0 ? `${m.changePercent}%` : 'No Change'}). Last verified: ${m.lastCheckedDate}\n`;
    });

    md += `\n*Generated by ZeroIntel — Zero-Cost E-Commerce Intelligence for Kemitt.*`;

    return md;
  }
}

export const csvService = new CsvService();
