import { AIAnalysisResult, GeneratedQueriesResult, Product, TrendItem, OpportunityItem } from '../types';

export interface HealthStatus {
  status: string;
  hasApiKey: boolean;
  model: string;
  operatingCost: string;
  quotaTier: string;
  rpmLimit: number;
  rpdLimit: number;
  apiCallsThisSession: number;
  lastCallTimestamp: number | null;
  zeroCostPolicyEnforced: boolean;
  supportedRetailers: string[];
}

export class GeminiService {
  private lastRequestTime = 0;
  private minIntervalMs = 2000; // Free quota rate limit smoothing

  private async throttle(): Promise<void> {
    const now = Date.now();
    const elapsed = now - this.lastRequestTime;
    if (elapsed < this.minIntervalMs) {
      await new Promise((resolve) => setTimeout(resolve, this.minIntervalMs - elapsed));
    }
    this.lastRequestTime = Date.now();
  }

  async getHealth(): Promise<HealthStatus> {
    const res = await fetch('/api/gemini/health');
    if (!res.ok) {
      throw new Error(`Failed to fetch health: ${res.statusText}`);
    }
    return res.json();
  }

  async analyzeImage(
    imageBase64: string,
    mimeType = 'image/jpeg',
    userNotes = ''
  ): Promise<AIAnalysisResult> {
    await this.throttle();
    const res = await fetch('/api/gemini/analyze-image', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ imageBase64, mimeType, userNotes }),
    });

    const data = await res.json();
    if (!res.ok) {
      throw new Error(data.error || 'Failed to analyze furniture image');
    }

    return data.analysis as AIAnalysisResult;
  }

  async generateQueries(
    productName: string,
    category = '',
    materials = '',
    style = ''
  ): Promise<GeneratedQueriesResult> {
    await this.throttle();
    const res = await fetch('/api/gemini/generate-queries', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ productName, category, materials, style }),
    });

    const data = await res.json();
    if (!res.ok) {
      throw new Error(data.error || 'Failed to generate competitor queries');
    }

    return data.data as GeneratedQueriesResult;
  }

  async analyzeTrend(
    topic: string,
    contextText = '',
    imageBase64?: string,
    mimeType?: string
  ): Promise<Partial<TrendItem>> {
    await this.throttle();
    const res = await fetch('/api/gemini/analyze-trend', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ topic, contextText, imageBase64, mimeType }),
    });

    const data = await res.json();
    if (!res.ok) {
      throw new Error(data.error || 'Failed to analyze furniture trend');
    }

    return data.trend;
  }

  async synthesizeOpportunities(
    kemittProducts: Product[],
    competitorProducts: Product[],
    focusCategory = 'All'
  ): Promise<{
    executiveSummary: string;
    pricePositioningVerdict: string;
    opportunities: OpportunityItem[];
    threatsOrRisks: string[];
  }> {
    await this.throttle();
    const res = await fetch('/api/gemini/synthesize-opportunities', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ kemittProducts, competitorProducts, focusCategory }),
    });

    const data = await res.json();
    if (!res.ok) {
      throw new Error(data.error || 'Failed to synthesize opportunities');
    }

    const payload = data.data;
    const opportunitiesWithMeta = (payload.opportunities || []).map((opp: Partial<OpportunityItem>, idx: number) => ({
      id: `ai-opp-${Date.now()}-${idx}`,
      title: opp.title || 'Untitled Opportunity',
      category: (opp.category as any) || 'Sofas & Sectionals',
      targetPriceBandEGP: opp.targetPriceBandEGP || '15,000 - 25,000 EGP',
      competitorBenchmark: opp.competitorBenchmark || 'Egyptian Retailers',
      opportunityType: opp.opportunityType || 'Whitespace Gap',
      rationale: opp.rationale || '',
      recommendedMaterials: opp.recommendedMaterials || 'Beechwood, high-density foam',
      expectedImpact: opp.expectedImpact || 'High',
      status: 'Identified' as const,
      dateCreated: new Date().toISOString().split('T')[0],
    }));

    return {
      executiveSummary: payload.executiveSummary || '',
      pricePositioningVerdict: payload.pricePositioningVerdict || '',
      opportunities: opportunitiesWithMeta,
      threatsOrRisks: payload.threatsOrRisks || [],
    };
  }
}

export const geminiService = new GeminiService();
