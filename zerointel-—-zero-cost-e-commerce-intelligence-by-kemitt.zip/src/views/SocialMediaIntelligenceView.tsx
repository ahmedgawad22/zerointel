import React, { useState } from 'react';
import { translations } from '../locales/translations';
import {
  Share2,
  ExternalLink,
  Copy,
  Check,
  TrendingUp,
  Search,
  Globe,
  Sparkles,
  Layers
} from 'lucide-react';

interface SocialMediaIntelligenceViewProps {
  lang: 'en' | 'ar';
}

const CAIRO_INTERIOR_HASHTAGS = [
  '#kemitt',
  '#egyptfurniture',
  '#interiordesigncairo',
  '#cairohomes',
  '#newcairointeriors',
  '#sheikhzayedhomes',
  '#sahelhomes',
  '#modernfurnitureegypt',
  '#damiettafurniture',
  '#egyptianinteriors',
  '#homedecorcairo',
  '#cairodesign'
];

const SOCIAL_CHANNELS = [
  {
    name: 'Google Trends (Egypt)',
    platform: 'Google Trends',
    description: 'Track real-time search interest in Egypt for furniture categories, IKEA vs. local brands, and seasonal demand.',
    queryUrls: [
      { label: 'Egypt Furniture Interest', url: 'https://trends.google.com/trends/explore?geo=EG&q=furniture,أثاث' },
      { label: 'Kemitt vs IKEA Egypt', url: 'https://trends.google.com/trends/explore?geo=EG&q=ikea,kemitt' },
      { label: 'Sofa & Living Search Trends', url: 'https://trends.google.com/trends/explore?geo=EG&q=كنب,sofa' },
      { label: 'Modern Decor & Interior', url: 'https://trends.google.com/trends/explore?geo=EG&q=ديكور+مودرن' }
    ]
  },
  {
    name: 'TikTok Creative Center',
    platform: 'TikTok',
    description: 'Discover viral home styling, furniture unboxing, room transformations, and trending audio in Home & Living.',
    queryUrls: [
      { label: 'Home Improvement & Living Trends', url: 'https://ads.tiktok.com/business/creativecenter/inspiration/popular/hashtag/pc/en?period=7&industry=home_improvement' },
      { label: 'Search #furniture on TikTok', url: 'https://www.tiktok.com/tag/furniture' },
      { label: 'Search #cairointeriors on TikTok', url: 'https://www.tiktok.com/tag/cairointeriors' }
    ]
  },
  {
    name: 'Pinterest Trends',
    platform: 'Pinterest',
    description: 'High-intent visual discovery engine for living room moodboards, travertine styling, and Scandinavian furniture.',
    queryUrls: [
      { label: 'Pinterest Trends Tool', url: 'https://trends.pinterest.com/' },
      { label: 'Explore "Curved Boucle Sofa"', url: 'https://www.pinterest.com/search/pins/?q=curved%20boucle%20sofa' },
      { label: 'Explore "Travertine Coffee Table"', url: 'https://www.pinterest.com/search/pins/?q=travertine%20coffee%20table' },
      { label: 'Explore "Japandi Living Room"', url: 'https://www.pinterest.com/search/pins/?q=japandi%20living%20room' }
    ]
  },
  {
    name: 'Instagram Explore Tags',
    platform: 'Instagram',
    description: 'Inspect projects posted by Cairo architects, interior design studios, and influencer home setups.',
    queryUrls: [
      { label: '#interiordesigncairo', url: 'https://www.instagram.com/explore/tags/interiordesigncairo/' },
      { label: '#egyptfurniture', url: 'https://www.instagram.com/explore/tags/egyptfurniture/' },
      { label: '#cairohomes', url: 'https://www.instagram.com/explore/tags/cairohomes/' },
      { label: '#newcairointeriors', url: 'https://www.instagram.com/explore/tags/newcairointeriors/' }
    ]
  },
  {
    name: 'Reddit Design Communities',
    platform: 'Reddit',
    description: 'Unfiltered consumer discussions on furniture durability, space planning, comfort, and direct user critiques.',
    queryUrls: [
      { label: 'r/InteriorDesign', url: 'https://www.reddit.com/r/InteriorDesign/' },
      { label: 'r/DesignMyRoom', url: 'https://www.reddit.com/r/DesignMyRoom/' },
      { label: 'r/femalelivingspace', url: 'https://www.reddit.com/r/femalelivingspace/' },
      { label: 'r/malelivingspace', url: 'https://www.reddit.com/r/malelivingspace/' }
    ]
  }
];

export const SocialMediaIntelligenceView: React.FC<SocialMediaIntelligenceViewProps> = ({
  lang
}) => {
  const t = translations[lang];
  const [copied, setCopied] = useState(false);
  const [customKeyword, setCustomKeyword] = useState('');

  const handleCopyHashtags = () => {
    navigator.clipboard.writeText(CAIRO_INTERIOR_HASHTAGS.join(' '));
    setCopied(true);
    setTimeout(() => setCopied(false), 2500);
  };

  return (
    <div className="p-6 md:p-8 space-y-8 max-w-7xl mx-auto">
      {/* Header */}
      <div className="border-b border-slate-200 dark:border-slate-800 pb-5">
        <div className="flex items-center gap-2 text-xs font-semibold uppercase tracking-wider text-emerald-600 dark:text-emerald-400 mb-1">
          <Share2 className="w-3.5 h-3.5" />
          <span>Public Social Trends & Keyword Discovery</span>
        </div>
        <h1 className="text-2xl md:text-3xl font-bold tracking-tight text-slate-900 dark:text-slate-100">
          {t.socialIntel.title}
        </h1>
        <p className="text-sm text-slate-500 dark:text-slate-400 mt-1">
          {t.socialIntel.subtitle}
        </p>
      </div>

      {/* Cairo Hashtags Quick Copy Banner */}
      <div className="p-5 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider block mb-1">
            Cairo & Egypt Furniture Social Tag Deck
          </span>
          <div className="flex flex-wrap gap-1.5 text-xs text-slate-700 dark:text-slate-300">
            {CAIRO_INTERIOR_HASHTAGS.map((tag) => (
              <span key={tag} className="font-mono text-emerald-600 dark:text-emerald-400">
                {tag}
              </span>
            ))}
          </div>
        </div>

        <button
          onClick={handleCopyHashtags}
          className="px-4 py-2 text-xs font-semibold text-white bg-slate-900 dark:bg-slate-800 hover:bg-slate-800 dark:hover:bg-slate-700 rounded-lg shadow-sm flex items-center gap-1.5 transition-colors shrink-0"
        >
          {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
          <span>{copied ? t.socialIntel.hashtagsCopied : t.socialIntel.copyHashtags}</span>
        </button>
      </div>

      {/* Custom Keyword Multi-Platform Launcher */}
      <div className="p-5 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs space-y-3">
        <label className="block text-xs font-medium text-slate-700 dark:text-slate-300">
          Multi-Platform Deep Search (Enter any furniture topic)
        </label>
        <div className="flex flex-col sm:flex-row items-center gap-3">
          <input
            type="text"
            value={customKeyword}
            onChange={(e) => setCustomKeyword(e.target.value)}
            placeholder="e.g. Boucle sofa, Travertine table, Cane dining chairs..."
            className="w-full px-3 py-2 text-xs md:text-sm bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-lg text-slate-900 dark:text-slate-100 focus:outline-none focus:border-emerald-500"
          />
          <div className="flex items-center gap-2 w-full sm:w-auto shrink-0">
            <a
              href={`https://trends.google.com/trends/explore?geo=EG&q=${encodeURIComponent(customKeyword || 'furniture')}`}
              target="_blank"
              rel="noopener noreferrer"
              className="flex-1 sm:flex-none px-3 py-2 text-xs font-medium text-slate-700 dark:text-slate-300 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 rounded-lg transition-colors flex items-center justify-center gap-1"
            >
              <span>Trends</span>
              <ExternalLink className="w-3 h-3" />
            </a>
            <a
              href={`https://www.pinterest.com/search/pins/?q=${encodeURIComponent(customKeyword || 'interior design')}`}
              target="_blank"
              rel="noopener noreferrer"
              className="flex-1 sm:flex-none px-3 py-2 text-xs font-medium text-slate-700 dark:text-slate-300 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 rounded-lg transition-colors flex items-center justify-center gap-1"
            >
              <span>Pinterest</span>
              <ExternalLink className="w-3 h-3" />
            </a>
            <a
              href={`https://www.tiktok.com/search?q=${encodeURIComponent(customKeyword || 'furniture cairo')}`}
              target="_blank"
              rel="noopener noreferrer"
              className="flex-1 sm:flex-none px-3 py-2 text-xs font-medium text-slate-700 dark:text-slate-300 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 rounded-lg transition-colors flex items-center justify-center gap-1"
            >
              <span>TikTok</span>
              <ExternalLink className="w-3 h-3" />
            </a>
          </div>
        </div>
      </div>

      {/* Social Platforms Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {SOCIAL_CHANNELS.map((ch) => (
          <div
            key={ch.name}
            className="p-5 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs flex flex-col justify-between space-y-4"
          >
            <div>
              <div className="text-xs uppercase font-semibold text-emerald-600 dark:text-emerald-400 mb-1">
                {ch.platform}
              </div>
              <h3 className="text-base font-bold text-slate-900 dark:text-slate-100 mb-2">
                {ch.name}
              </h3>
              <p className="text-xs text-slate-500 dark:text-slate-400 mb-4 leading-relaxed">
                {ch.description}
              </p>

              {/* Launcher Links */}
              <div className="space-y-2">
                {ch.queryUrls.map((q, i) => (
                  <a
                    key={i}
                    href={q.url}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="block p-2.5 rounded-lg border border-slate-200 dark:border-slate-800 hover:bg-slate-50 dark:hover:bg-slate-800/60 transition-colors text-xs font-medium text-slate-700 dark:text-slate-200"
                  >
                    <div className="flex items-center justify-between">
                      <span className="truncate">{q.label}</span>
                      <ExternalLink className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                    </div>
                  </a>
                ))}
              </div>
            </div>

            <div className="pt-2 text-[10px] text-slate-400 text-center font-mono">
              Public Search · $0 API Cost
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
