import React, { useState } from 'react';
import { geminiService } from '../services/gemini';
import { GeneratedQueriesResult, Product, RetailerName, FurnitureCategory } from '../types';
import { translations } from '../locales/translations';
import {
  Search,
  ExternalLink,
  Sparkles,
  RefreshCw,
  Plus,
  BookmarkPlus,
  CheckCircle2,
  AlertCircle,
  Building,
  Globe
} from 'lucide-react';

interface CompetitorSearchViewProps {
  onSaveProduct: (product: Product) => void;
  kemittProducts: Product[];
  lang: 'en' | 'ar';
}

const EGYPTIAN_RETAILERS: Array<{ name: RetailerName; domain: string; searchBaseUrl: string; directBaseUrl: string }> = [
  { name: 'IKEA Egypt', domain: 'ikea.com/eg', searchBaseUrl: 'https://www.google.com/search?q=site:ikea.com/eg+', directBaseUrl: 'https://www.ikea.com/eg/en/search/?q=' },
  { name: 'Chic Homz', domain: 'chichomz.com', searchBaseUrl: 'https://www.google.com/search?q=site:chichomz.com+', directBaseUrl: 'https://chichomz.com/search?q=' },
  { name: 'Hub Furniture', domain: 'hubfurniture.com.eg', searchBaseUrl: 'https://www.google.com/search?q=site:hubfurniture.com.eg+', directBaseUrl: 'https://hubfurniture.com.eg/search?q=' },
  { name: 'In Your Room', domain: 'inyourroom.com', searchBaseUrl: 'https://www.google.com/search?q=site:inyourroom.com+', directBaseUrl: 'https://inyourroom.com/search?q=' },
  { name: 'Blend Furniture', domain: 'blendfurniture.com', searchBaseUrl: 'https://www.google.com/search?q=site:blendfurniture.com+', directBaseUrl: 'https://blendfurniture.com/search?q=' },
  { name: 'Efreshli', domain: 'efreshli.com', searchBaseUrl: 'https://www.google.com/search?q=site:efreshli.com+', directBaseUrl: 'https://efreshli.com/search?q=' },
  { name: 'Kabbani Furniture', domain: 'kabbanifurniture.com', searchBaseUrl: 'https://www.google.com/search?q=site:kabbanifurniture.com+', directBaseUrl: 'https://kabbanifurniture.com/search?q=' },
  { name: 'Amazon Egypt', domain: 'amazon.eg', searchBaseUrl: 'https://www.amazon.eg/s?k=', directBaseUrl: 'https://www.amazon.eg/s?k=' }
];

export const CompetitorSearchView: React.FC<CompetitorSearchViewProps> = ({
  onSaveProduct,
  kemittProducts,
  lang
}) => {
  const t = translations[lang];

  const [searchTerm, setSearchTerm] = useState('Curved bouclé armchair');
  const [selectedCategory, setSelectedCategory] = useState<FurnitureCategory>('Armchairs & Accent Chairs');
  const [generating, setGenerating] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [generatedResult, setGeneratedResult] = useState<GeneratedQueriesResult | null>(null);

  // Quick save found competitor product state
  const [foundName, setFoundName] = useState('');
  const [foundRetailer, setFoundRetailer] = useState<RetailerName>('IKEA Egypt');
  const [foundPrice, setFoundPrice] = useState('');
  const [foundUrl, setFoundUrl] = useState('');
  const [foundMaterials, setFoundMaterials] = useState('');
  const [matchedKemittId, setMatchedKemittId] = useState('');
  const [saveSuccess, setSaveSuccess] = useState(false);

  const handleGenerateQueries = async () => {
    if (!searchTerm.trim()) return;

    setGenerating(true);
    setErrorMsg(null);
    try {
      const res = await geminiService.generateQueries(searchTerm, selectedCategory);
      setGeneratedResult(res);
    } catch (err: unknown) {
      const error = err as Error;
      setErrorMsg(error.message || 'Failed to generate search queries.');
    } finally {
      setGenerating(false);
    }
  };

  const handleQuickSave = (e: React.FormEvent) => {
    e.preventDefault();
    if (!foundName || !foundPrice) return;

    const parsedPrice = parseFloat(foundPrice);
    const newProd: Product = {
      id: `comp-${Date.now()}`,
      sku: `COMP-${Date.now().toString().slice(-6)}`,
      name: foundName.trim(),
      brand: 'Competitor',
      retailer: foundRetailer,
      category: selectedCategory,
      priceEGP: parsedPrice,
      originalPriceEGP: parsedPrice,
      currency: 'EGP',
      url: foundUrl.trim() || undefined,
      materials: foundMaterials.split(',').map((m) => m.trim()).filter(Boolean),
      inStock: true,
      lastChecked: new Date().toISOString().split('T')[0],
      priceHistory: [
        {
          date: new Date().toISOString().split('T')[0],
          priceEGP: parsedPrice,
          note: 'Logged via Competitor Search Station'
        }
      ],
      matchedKemittId: matchedKemittId || undefined,
      similarityScore: 85
    };

    onSaveProduct(newProd);
    setSaveSuccess(true);
    setFoundName('');
    setFoundPrice('');
    setFoundUrl('');
    setFoundMaterials('');
    setTimeout(() => setSaveSuccess(false), 3000);
  };

  return (
    <div className="p-6 md:p-8 space-y-8 max-w-7xl mx-auto">
      {/* Header */}
      <div className="border-b border-slate-200 dark:border-slate-800 pb-5">
        <div className="flex items-center gap-2 text-xs font-semibold uppercase tracking-wider text-emerald-600 dark:text-emerald-400 mb-1">
          <Globe className="w-3.5 h-3.5" />
          <span>Zero-Scraping Public Discovery</span>
        </div>
        <h1 className="text-2xl md:text-3xl font-bold tracking-tight text-slate-900 dark:text-slate-100">
          {t.competitorSearch.title}
        </h1>
        <p className="text-sm text-slate-500 dark:text-slate-400 mt-1">
          {t.competitorSearch.subtitle}
        </p>
      </div>

      {/* Query Formulation Bar */}
      <div className="p-5 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs space-y-4">
        <div className="grid grid-cols-1 md:grid-cols-12 gap-3">
          <div className="md:col-span-7">
            <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
              Furniture Item or Design Topic
            </label>
            <div className="relative">
              <input
                type="text"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                placeholder={t.competitorSearch.inputPlaceholder}
                className="w-full pl-9 pr-3 py-2 text-xs md:text-sm bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-lg focus:outline-none focus:border-emerald-500 text-slate-900 dark:text-slate-100"
              />
              <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5 rtl:right-3 rtl:left-auto" />
            </div>
          </div>

          <div className="md:col-span-3">
            <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
              Category
            </label>
            <select
              value={selectedCategory}
              onChange={(e) => setSelectedCategory(e.target.value as FurnitureCategory)}
              className="w-full px-3 py-2 text-xs md:text-sm bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-lg focus:outline-none focus:border-emerald-500 text-slate-900 dark:text-slate-100"
            >
              <option value="Sofas & Sectionals">Sofas & Sectionals</option>
              <option value="Armchairs & Accent Chairs">Armchairs & Accent Chairs</option>
              <option value="Coffee & Side Tables">Coffee & Side Tables</option>
              <option value="Dining Tables">Dining Tables</option>
              <option value="Dining Chairs">Dining Chairs</option>
              <option value="Beds & Headboards">Beds & Headboards</option>
              <option value="Storage & Sideboards">Storage & Sideboards</option>
            </select>
          </div>

          <div className="md:col-span-2 flex items-end">
            <button
              onClick={handleGenerateQueries}
              disabled={generating || !searchTerm.trim()}
              className="w-full py-2 px-3 text-xs font-semibold text-white bg-emerald-600 hover:bg-emerald-500 disabled:opacity-50 rounded-lg shadow-sm flex items-center justify-center gap-1.5 transition-colors"
            >
              {generating ? (
                <>
                  <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                  <span>Formulating...</span>
                </>
              ) : (
                <>
                  <Sparkles className="w-3.5 h-3.5" />
                  <span>Generate Queries</span>
                </>
              )}
            </button>
          </div>
        </div>

        {errorMsg && (
          <div className="p-3 rounded-lg bg-rose-50 dark:bg-rose-950/30 border border-rose-200 dark:border-rose-900 text-xs text-rose-700 dark:text-rose-300 flex items-center gap-2">
            <AlertCircle className="w-4 h-4 shrink-0" />
            <span>{errorMsg}</span>
          </div>
        )}
      </div>

      {/* Main Grid: Retailer Launchers + Quick Save Found Competitor Item */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        {/* Left Column: Retailer Launchers */}
        <div className="lg:col-span-7 space-y-4">
          <div className="p-5 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs space-y-4">
            <div className="flex items-center justify-between">
              <h2 className="text-sm font-bold text-slate-900 dark:text-slate-100 flex items-center gap-2">
                <Building className="w-4 h-4 text-emerald-500" />
                <span>{t.competitorSearch.retailerLaunchers}</span>
              </h2>
              <span className="text-[11px] text-slate-400">
                Direct public searches (No paid proxies)
              </span>
            </div>

            {/* Aggregated Google Shopping Egypt Direct Search */}
            <div className="p-4 rounded-lg bg-emerald-50/60 dark:bg-emerald-950/20 border border-emerald-200 dark:border-emerald-800/60 flex items-center justify-between">
              <div>
                <span className="text-xs font-bold text-emerald-900 dark:text-emerald-300 block">
                  Google Shopping Egypt (Aggregated Prices in EGP)
                </span>
                <span className="text-[11px] text-emerald-800/80 dark:text-emerald-400/80">
                  Search Egyptian furniture stores in one aggregated comparison view
                </span>
              </div>
              <a
                href={`https://www.google.com/search?tbm=shop&gl=eg&hl=en&q=${encodeURIComponent(`${searchTerm} ${selectedCategory} Egypt`)}`}
                target="_blank"
                rel="noopener noreferrer"
                className="px-3.5 py-1.5 text-xs font-semibold text-white bg-emerald-600 hover:bg-emerald-500 rounded-lg shadow-sm flex items-center gap-1.5 transition-colors shrink-0"
              >
                <span>Open Shopping</span>
                <ExternalLink className="w-3.5 h-3.5" />
              </a>
            </div>

            {/* Individual Retailer Cards */}
            <div className="space-y-2.5">
              {EGYPTIAN_RETAILERS.map((ret) => {
                const targetSearchQuery = `${searchTerm} ${selectedCategory}`;
                const siteGoogleUrl = `${ret.searchBaseUrl}${encodeURIComponent(targetSearchQuery)}`;
                const directUrl = `${ret.directBaseUrl}${encodeURIComponent(targetSearchQuery)}`;

                return (
                  <div
                    key={ret.name}
                    className="p-3.5 rounded-lg border border-slate-200 dark:border-slate-800 hover:bg-slate-50 dark:hover:bg-slate-800/40 flex items-center justify-between transition-colors text-xs"
                  >
                    <div>
                      <div className="font-semibold text-slate-800 dark:text-slate-200">
                        {ret.name}
                      </div>
                      <div className="text-[11px] text-slate-400 font-mono">
                        {ret.domain}
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      <a
                        href={siteGoogleUrl}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="px-2.5 py-1 text-slate-700 dark:text-slate-300 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 rounded-md transition-colors flex items-center gap-1"
                        title="Search using Google site: filter"
                      >
                        <span>Google Site Search</span>
                        <ExternalLink className="w-3 h-3 text-slate-400" />
                      </a>
                      <a
                        href={directUrl}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="px-2.5 py-1 font-medium text-emerald-700 dark:text-emerald-300 bg-emerald-50 dark:bg-emerald-950/40 hover:bg-emerald-100 dark:hover:bg-emerald-900/60 rounded-md transition-colors flex items-center gap-1"
                        title="Search directly on retailer website"
                      >
                        <span>Direct Store</span>
                        <ExternalLink className="w-3 h-3 text-emerald-500" />
                      </a>
                    </div>
                  </div>
                );
              })}
            </div>

            {/* Generated Arabic Queries (if available from Gemini) */}
            {generatedResult && generatedResult.arabicQueries && (
              <div className="p-4 rounded-lg bg-slate-50 dark:bg-slate-800/40 border border-slate-200 dark:border-slate-800 space-y-2">
                <span className="text-xs font-semibold text-slate-700 dark:text-slate-300 block">
                  كلمات بحث مخصصة للسوق المصري (Arabic Furniture Queries)
                </span>
                <div className="flex flex-wrap gap-2">
                  {generatedResult.arabicQueries.map((q, i) => (
                    <a
                      key={i}
                      href={`https://www.google.com/search?q=${encodeURIComponent(`${q} مصر`)}`}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="px-3 py-1.5 text-xs rounded-md bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 text-slate-800 dark:text-slate-200 hover:border-emerald-500 flex items-center gap-1.5 transition-colors"
                    >
                      <Search className="w-3 h-3 text-emerald-500" />
                      <span>{q}</span>
                      <ExternalLink className="w-3 h-3 text-slate-400" />
                    </a>
                  ))}
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Right Column: Quick Save Discovered Competitor Item */}
        <div className="lg:col-span-5 space-y-4">
          <div className="p-5 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs space-y-4">
            <div>
              <h2 className="text-sm font-bold text-slate-900 dark:text-slate-100 flex items-center gap-2">
                <BookmarkPlus className="w-4 h-4 text-emerald-500" />
                <span>{t.competitorSearch.quickSaveTitle}</span>
              </h2>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                Found a competitor item in your search? Save its price and URL to track it in IndexedDB.
              </p>
            </div>

            <form onSubmit={handleQuickSave} className="space-y-3">
              <div>
                <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                  Product Name *
                </label>
                <input
                  type="text"
                  required
                  value={foundName}
                  onChange={(e) => setFoundName(e.target.value)}
                  placeholder="e.g. Landskrona 3-seat sofa"
                  className="w-full px-3 py-2 text-xs bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-lg focus:outline-none focus:border-emerald-500 text-slate-900 dark:text-slate-100"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                    Retailer
                  </label>
                  <select
                    value={foundRetailer}
                    onChange={(e) => setFoundRetailer(e.target.value as RetailerName)}
                    className="w-full px-3 py-2 text-xs bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-lg focus:outline-none focus:border-emerald-500 text-slate-900 dark:text-slate-100"
                  >
                    {EGYPTIAN_RETAILERS.map((r) => (
                      <option key={r.name} value={r.name}>{r.name}</option>
                    ))}
                    <option value="Other">Other Retailer</option>
                  </select>
                </div>
                <div>
                  <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                    Price in EGP *
                  </label>
                  <input
                    type="number"
                    required
                    min="0"
                    step="50"
                    value={foundPrice}
                    onChange={(e) => setFoundPrice(e.target.value)}
                    placeholder="e.g. 18500"
                    className="w-full px-3 py-2 text-xs font-mono tabular-nums bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-lg focus:outline-none focus:border-emerald-500 text-slate-900 dark:text-slate-100"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                  Product URL (for future verification)
                </label>
                <input
                  type="url"
                  value={foundUrl}
                  onChange={(e) => setFoundUrl(e.target.value)}
                  placeholder="https://..."
                  className="w-full px-3 py-2 text-xs bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-lg focus:outline-none focus:border-emerald-500 text-slate-900 dark:text-slate-100"
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                  Materials / Key Specs
                </label>
                <input
                  type="text"
                  value={foundMaterials}
                  onChange={(e) => setFoundMaterials(e.target.value)}
                  placeholder="e.g. Bouclé fabric, Beechwood, 80x80cm"
                  className="w-full px-3 py-2 text-xs bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-lg focus:outline-none focus:border-emerald-500 text-slate-900 dark:text-slate-100"
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                  Compare with Kemitt Item (Optional)
                </label>
                <select
                  value={matchedKemittId}
                  onChange={(e) => setMatchedKemittId(e.target.value)}
                  className="w-full px-3 py-2 text-xs bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-lg text-slate-900 dark:text-slate-100"
                >
                  <option value="">-- No Direct Benchmark --</option>
                  {kemittProducts.map((k) => (
                    <option key={k.id} value={k.id}>
                      {k.name} ({k.priceEGP.toLocaleString()} EGP)
                    </option>
                  ))}
                </select>
              </div>

              <div className="pt-2">
                <button
                  type="submit"
                  className="w-full py-2.5 px-4 text-xs font-semibold text-white bg-emerald-600 hover:bg-emerald-500 rounded-lg shadow-sm flex items-center justify-center gap-1.5 transition-colors"
                >
                  <Plus className="w-4 h-4" />
                  <span>Save Discovered Competitor Item</span>
                </button>
              </div>

              {saveSuccess && (
                <div className="p-2.5 rounded-lg bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-800 text-xs text-emerald-700 dark:text-emerald-300 flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4" />
                  <span>Item recorded successfully into IndexedDB!</span>
                </div>
              )}
            </form>
          </div>
        </div>
      </div>
    </div>
  );
};
