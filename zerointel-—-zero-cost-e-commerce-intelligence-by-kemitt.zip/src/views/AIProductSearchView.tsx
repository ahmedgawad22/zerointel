import React, { useState } from 'react';
import { geminiService } from '../services/gemini';
import { AIAnalysisResult, Product, FurnitureCategory } from '../types';
import { translations } from '../locales/translations';
import {
  Sparkles,
  Upload,
  Image as ImageIcon,
  CheckCircle2,
  AlertCircle,
  ExternalLink,
  Plus,
  RefreshCw,
  Search,
  ArrowRight,
  ShieldCheck,
  Tag
} from 'lucide-react';

interface AIProductSearchViewProps {
  onSaveProduct: (product: Product) => void;
  lang: 'en' | 'ar';
}

// Built-in sample test items to allow instant testing without needing an external file upload
const SAMPLE_PRESETS = [
  {
    name: 'Curved Bouclé Lounge Armchair',
    category: 'Armchairs & Accent Chairs',
    style: 'Contemporary Organic',
    notes: 'Sample test preset for Egyptian apartment reception seating',
    dataUri: 'data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" width="400" height="400" viewBox="0 0 400 400"><rect width="100%" height="100%" fill="%23f1ede6"/><path d="M120 280 C120 180 280 180 280 280 Z" fill="%23e8e1d5" stroke="%23c2b8a3" stroke-width="6"/><ellipse cx="200" cy="280" rx="90" ry="30" fill="%23dfd6c5"/><rect x="140" y="300" width="16" height="45" rx="4" fill="%238a6d4d"/><rect x="244" y="300" width="16" height="45" rx="4" fill="%238a6d4d"/><text x="200" y="140" font-family="sans-serif" font-size="16" font-weight="bold" fill="%23554e44" text-anchor="middle">Boucle Chair Preset</text></svg>'
  },
  {
    name: 'Honed Travertine Slab Coffee Table',
    category: 'Coffee & Side Tables',
    style: 'Modern Architectural',
    notes: 'Egyptian travertine stone with dual cylinder pedestal plinths',
    dataUri: 'data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" width="400" height="400" viewBox="0 0 400 400"><rect width="100%" height="100%" fill="%23eae7e1"/><ellipse cx="200" cy="200" rx="140" ry="50" fill="%23d6cfbe" stroke="%23b8ad98" stroke-width="5"/><rect x="130" y="210" width="40" height="70" rx="6" fill="%23c4b9a3"/><rect x="230" y="210" width="40" height="70" rx="6" fill="%23c4b9a3"/><text x="200" y="110" font-family="sans-serif" font-size="16" font-weight="bold" fill="%234d473d" text-anchor="middle">Travertine Table Preset</text></svg>'
  },
  {
    name: 'Japandi Low-Profile Modular Sofa',
    category: 'Sofas & Sectionals',
    style: 'Japandi / Minimalist',
    notes: 'Linen textured fabric with low solid beechwood base',
    dataUri: 'data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" width="400" height="400" viewBox="0 0 400 400"><rect width="100%" height="100%" fill="%23f4f3ef"/><rect x="80" y="190" width="240" height="70" rx="10" fill="%23dedad0" stroke="%23b5b0a3" stroke-width="5"/><rect x="70" y="260" width="260" height="20" rx="4" fill="%238a6742"/><rect x="90" y="280" width="14" height="25" fill="%238a6742"/><rect x="296" y="280" width="14" height="25" fill="%238a6742"/><text x="200" y="140" font-family="sans-serif" font-size="16" font-weight="bold" fill="%234d473d" text-anchor="middle">Modular Sofa Preset</text></svg>'
  }
];

export const AIProductSearchView: React.FC<AIProductSearchViewProps> = ({
  onSaveProduct,
  lang
}) => {
  const t = translations[lang];

  const [activeTab, setActiveTab] = useState<'upload' | 'manual'>('upload');
  const [imagePreview, setImagePreview] = useState<string | null>(null);
  const [imageMime, setImageMime] = useState<string>('image/jpeg');
  const [userNotes, setUserNotes] = useState<string>('');
  const [analyzing, setAnalyzing] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [analysisResult, setAnalysisResult] = useState<AIAnalysisResult | null>(null);
  const [savedSuccess, setSavedSuccess] = useState(false);

  // Manual URL / text search mode
  const [manualTitle, setManualTitle] = useState('');
  const [manualCategory, setManualCategory] = useState('Sofas & Sectionals');
  const [manualMaterials, setManualMaterials] = useState('');

  const handleImageFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (!file.type.startsWith('image/')) {
      setErrorMsg('Please select a valid image file (JPEG, PNG, WebP).');
      return;
    }

    setImageMime(file.type);
    const reader = new FileReader();
    reader.onload = () => {
      setImagePreview(reader.result as string);
      setAnalysisResult(null);
      setErrorMsg(null);
      setSavedSuccess(false);
    };
    reader.readAsDataURL(file);
  };

  const handleSelectPreset = (preset: typeof SAMPLE_PRESETS[0]) => {
    setImagePreview(preset.dataUri);
    setImageMime('image/svg+xml');
    setUserNotes(preset.notes);
    setAnalysisResult(null);
    setErrorMsg(null);
    setSavedSuccess(false);
  };

  const handleRunAnalysis = async () => {
    if (!imagePreview) {
      setErrorMsg('Please upload an image or choose a preset first.');
      return;
    }

    setAnalyzing(true);
    setErrorMsg(null);
    setSavedSuccess(false);

    try {
      const result = await geminiService.analyzeImage(imagePreview, imageMime, userNotes);
      setAnalysisResult(result);
    } catch (err: unknown) {
      const error = err as Error;
      setErrorMsg(error.message || 'Failed to analyze furniture image. Verify Gemini connection in Settings.');
    } finally {
      setAnalyzing(false);
    }
  };

  const handleSaveToCatalog = (brand: 'Kemitt' | 'Competitor') => {
    if (!analysisResult) return;

    const priceBand = analysisResult.recommendedKemittPriceBandEGP;
    const estPrice = priceBand ? Math.round((priceBand.min + priceBand.max) / 2) : 12000;

    const newProd: Product = {
      id: `${brand === 'Kemitt' ? 'kmt' : 'comp'}-${Date.now()}`,
      sku: `AI-SKU-${Date.now().toString().slice(-6)}`,
      name: analysisResult.productName || 'AI Discovered Furniture Item',
      brand,
      retailer: brand === 'Kemitt' ? 'Kemitt' : 'Chic Homz',
      category: (analysisResult.category as FurnitureCategory) || 'Armchairs & Accent Chairs',
      priceEGP: estPrice,
      originalPriceEGP: estPrice,
      currency: 'EGP',
      imageUrl: imagePreview && !imagePreview.startsWith('data:image/svg') ? imagePreview : undefined,
      materials: analysisResult.materials || [],
      dimensions: analysisResult.estimatedDimensions,
      style: analysisResult.designStyle,
      primaryColor: analysisResult.primaryColor,
      inStock: true,
      lastChecked: new Date().toISOString().split('T')[0],
      priceHistory: [
        {
          date: new Date().toISOString().split('T')[0],
          priceEGP: estPrice,
          note: `Extracted via Gemini Vision Intelligence`
        }
      ],
      notes: `${analysisResult.egyptianMarketSuitability || ''} | Price Rationale: ${priceBand?.rationale || ''}`,
      egyptianMarketFit: analysisResult.egyptianMarketSuitability
    };

    onSaveProduct(newProd);
    setSavedSuccess(true);
  };

  return (
    <div className="p-6 md:p-8 space-y-8 max-w-6xl mx-auto">
      {/* Title Header */}
      <div className="border-b border-slate-200 dark:border-slate-800 pb-5 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 text-xs font-semibold uppercase tracking-wider text-emerald-600 dark:text-emerald-400 mb-1">
            <Sparkles className="w-3.5 h-3.5" />
            <span>Multimodal Vision Intelligence</span>
          </div>
          <h1 className="text-2xl md:text-3xl font-bold tracking-tight text-slate-900 dark:text-slate-100">
            {t.aiSearch.title}
          </h1>
          <p className="text-sm text-slate-500 dark:text-slate-400 mt-1">
            {t.aiSearch.subtitle}
          </p>
        </div>

        <div className="flex items-center gap-1.5 p-1 bg-slate-100 dark:bg-slate-800 rounded-lg shrink-0">
          <button
            onClick={() => setActiveTab('upload')}
            className={`px-3 py-1.5 text-xs font-semibold rounded-md transition-colors ${
              activeTab === 'upload'
                ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-slate-100 shadow-xs'
                : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
            }`}
          >
            {t.aiSearch.uploadTab}
          </button>
          <button
            onClick={() => setActiveTab('manual')}
            className={`px-3 py-1.5 text-xs font-semibold rounded-md transition-colors ${
              activeTab === 'manual'
                ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-slate-100 shadow-xs'
                : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
            }`}
          >
            {t.aiSearch.urlTab}
          </button>
        </div>
      </div>

      {/* Main Workspace */}
      {activeTab === 'upload' ? (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          {/* Left Column: Upload / Presets */}
          <div className="lg:col-span-5 space-y-4">
            <div className="p-5 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs space-y-4">
              <h2 className="text-sm font-bold text-slate-900 dark:text-slate-100">
                1. Upload Furniture Photo
              </h2>

              {/* Upload Dropzone */}
              <label className="border-2 border-dashed border-slate-300 dark:border-slate-700 hover:border-emerald-500 dark:hover:border-emerald-500 rounded-xl p-6 flex flex-col items-center justify-center text-center cursor-pointer transition-colors bg-slate-50/50 dark:bg-slate-800/30">
                <input
                  type="file"
                  accept="image/jpeg,image/png,image/webp"
                  onChange={handleImageFileChange}
                  className="hidden"
                />
                <Upload className="w-8 h-8 text-slate-400 mb-2" />
                <span className="text-xs font-medium text-slate-700 dark:text-slate-300">
                  {t.aiSearch.dropPrompt}
                </span>
                <span className="text-[11px] text-slate-400 mt-1">
                  Supports JPEG, PNG, WebP up to 10MB
                </span>
              </label>

              {/* Or Quick Test Presets */}
              <div>
                <span className="text-xs font-semibold text-slate-500 dark:text-slate-400 block mb-2">
                  Or test with authentic sample presets:
                </span>
                <div className="space-y-1.5">
                  {SAMPLE_PRESETS.map((preset) => (
                    <button
                      key={preset.name}
                      type="button"
                      onClick={() => handleSelectPreset(preset)}
                      className="w-full text-left rtl:text-right px-3 py-2 text-xs rounded-lg border border-slate-200 dark:border-slate-800 hover:bg-slate-50 dark:hover:bg-slate-800 flex items-center justify-between transition-colors"
                    >
                      <span className="font-medium text-slate-800 dark:text-slate-200 truncate">{preset.name}</span>
                      <span className="text-[10px] text-slate-400 shrink-0">{preset.category}</span>
                    </button>
                  ))}
                </div>
              </div>

              {/* User Context Input */}
              <div>
                <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                  Optional Context or Notes
                </label>
                <textarea
                  rows={2}
                  value={userNotes}
                  onChange={(e) => setUserNotes(e.target.value)}
                  placeholder="e.g. Sourced from Italian design catalog; testing production in Damietta..."
                  className="w-full px-3 py-2 text-xs bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-lg focus:outline-none focus:border-emerald-500 text-slate-900 dark:text-slate-100"
                />
              </div>

              {/* Trigger Button */}
              <button
                onClick={handleRunAnalysis}
                disabled={!imagePreview || analyzing}
                className="w-full py-2.5 px-4 text-xs font-semibold text-white bg-emerald-600 hover:bg-emerald-500 disabled:opacity-50 disabled:cursor-not-allowed rounded-lg shadow-sm flex items-center justify-center gap-2 transition-colors"
              >
                {analyzing ? (
                  <>
                    <RefreshCw className="w-4 h-4 animate-spin" />
                    <span>Analyzing with Gemini 3.8 Flash...</span>
                  </>
                ) : (
                  <>
                    <Sparkles className="w-4 h-4" />
                    <span>Run AI Vision Analysis</span>
                  </>
                )}
              </button>

              {errorMsg && (
                <div className="p-3 rounded-lg bg-rose-50 dark:bg-rose-950/30 border border-rose-200 dark:border-rose-900 text-xs text-rose-700 dark:text-rose-300 flex items-start gap-2">
                  <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" />
                  <span>{errorMsg}</span>
                </div>
              )}
            </div>

            {/* Image Preview Box */}
            {imagePreview && (
              <div className="p-4 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs">
                <div className="text-xs font-semibold text-slate-500 dark:text-slate-400 mb-2">
                  Input Image Preview
                </div>
                <div className="relative aspect-4/3 rounded-lg overflow-hidden border border-slate-200 dark:border-slate-800 bg-slate-100 dark:bg-slate-800 flex items-center justify-center">
                  <img
                    src={imagePreview}
                    alt="Preview"
                    className="max-h-full max-w-full object-contain"
                  />
                </div>
              </div>
            )}
          </div>

          {/* Right Column: AI Extraction & Market Intel */}
          <div className="lg:col-span-7 space-y-4">
            {analysisResult ? (
              <div className="p-6 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs space-y-6 animate-in fade-in duration-200">
                {/* Header & Detected Title */}
                <div>
                  <div className="flex items-center gap-2 text-xs font-semibold text-emerald-600 dark:text-emerald-400 mb-1">
                    <CheckCircle2 className="w-4 h-4" />
                    <span>Gemini 3.8 Flash Analysis Complete ($0 Free Quota)</span>
                  </div>
                  <h3 className="text-xl font-bold text-slate-900 dark:text-slate-100">
                    {analysisResult.productName}
                  </h3>
                  <div className="mt-1 flex flex-wrap items-center gap-2 text-xs text-slate-500">
                    <span className="font-medium text-slate-700 dark:text-slate-300">{analysisResult.category}</span>
                    <span aria-hidden="true">·</span>
                    <span>{analysisResult.designStyle}</span>
                    <span aria-hidden="true">·</span>
                    <span>{analysisResult.primaryColor}</span>
                  </div>
                </div>

                {/* Attributes Grid */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-xs">
                  <div className="p-3.5 rounded-lg border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-850">
                    <span className="text-slate-400 block mb-1">{t.aiSearch.materialsDetected}</span>
                    <div className="font-medium text-slate-800 dark:text-slate-200">
                      {analysisResult.materials?.join(', ') || 'N/A'}
                    </div>
                  </div>

                  <div className="p-3.5 rounded-lg border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-850">
                    <span className="text-slate-400 block mb-1">{t.aiSearch.shapeSilhouette}</span>
                    <div className="font-medium text-slate-800 dark:text-slate-200">
                      {analysisResult.shape || 'N/A'}
                    </div>
                  </div>

                  <div className="p-3.5 rounded-lg border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-850">
                    <span className="text-slate-400 block mb-1">{t.aiSearch.dimensionsEstimate}</span>
                    <div className="font-mono font-medium text-slate-800 dark:text-slate-200">
                      {analysisResult.estimatedDimensions || 'N/A'}
                    </div>
                  </div>

                  <div className="p-3.5 rounded-lg border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-850">
                    <span className="text-slate-400 block mb-1">Visual Signature</span>
                    <ul className="list-disc list-inside text-slate-700 dark:text-slate-300 space-y-0.5">
                      {analysisResult.visualCharacteristics?.slice(0, 2).map((vc, i) => (
                        <li key={i} className="truncate">{vc}</li>
                      ))}
                    </ul>
                  </div>
                </div>

                {/* Egyptian Market Suitability Analysis */}
                <div className="p-4 rounded-lg bg-emerald-50/70 dark:bg-emerald-950/20 border border-emerald-200 dark:border-emerald-800/60">
                  <div className="text-xs font-semibold text-emerald-900 dark:text-emerald-300 mb-1">
                    {t.aiSearch.egyptianMarketFit}
                  </div>
                  <p className="text-xs text-emerald-950 dark:text-emerald-200 leading-relaxed">
                    {analysisResult.egyptianMarketSuitability}
                  </p>
                </div>

                {/* Recommended Price Band */}
                {analysisResult.recommendedKemittPriceBandEGP && (
                  <div className="p-4 rounded-lg bg-slate-50 dark:bg-slate-800/40 border border-slate-200 dark:border-slate-800 flex flex-col md:flex-row md:items-center justify-between gap-4">
                    <div>
                      <div className="text-xs text-slate-500 mb-0.5">{t.aiSearch.recommendedKemittPrice}</div>
                      <div className="text-xl font-bold font-mono tabular-nums text-slate-900 dark:text-slate-100">
                        {analysisResult.recommendedKemittPriceBandEGP.min.toLocaleString()} - {analysisResult.recommendedKemittPriceBandEGP.max.toLocaleString()} EGP
                      </div>
                      <p className="text-[11px] text-slate-500 dark:text-slate-400 mt-1">
                        {analysisResult.recommendedKemittPriceBandEGP.rationale}
                      </p>
                    </div>
                  </div>
                )}

                {/* Public Competitor Search Queries Generated */}
                {analysisResult.searchQueries && (
                  <div className="space-y-2">
                    <div className="text-xs font-semibold text-slate-600 dark:text-slate-400 uppercase tracking-wider">
                      {t.aiSearch.suggestedQueries}
                    </div>
                    <div className="flex flex-wrap gap-2">
                      {analysisResult.searchQueries.english?.map((q, i) => (
                        <a
                          key={`en-${i}`}
                          href={`https://www.google.com/search?q=${encodeURIComponent(q)}`}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="px-2.5 py-1 text-xs rounded-md bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 flex items-center gap-1 transition-colors"
                        >
                          <Search className="w-3 h-3 text-slate-400" />
                          <span>{q}</span>
                          <ExternalLink className="w-3 h-3 text-slate-400" />
                        </a>
                      ))}
                      {analysisResult.searchQueries.arabic?.map((q, i) => (
                        <a
                          key={`ar-${i}`}
                          href={`https://www.google.com/search?q=${encodeURIComponent(q)}`}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="px-2.5 py-1 text-xs rounded-md bg-emerald-50 dark:bg-emerald-950/40 hover:bg-emerald-100 dark:hover:bg-emerald-900/50 text-emerald-800 dark:text-emerald-300 flex items-center gap-1 transition-colors"
                        >
                          <Search className="w-3 h-3 text-emerald-500" />
                          <span>{q}</span>
                          <ExternalLink className="w-3 h-3 text-emerald-500" />
                        </a>
                      ))}
                    </div>
                  </div>
                )}

                {/* Save Actions */}
                <div className="pt-4 border-t border-slate-200 dark:border-slate-800 flex flex-wrap items-center justify-between gap-3">
                  {savedSuccess ? (
                    <div className="text-xs text-emerald-600 dark:text-emerald-400 flex items-center gap-1.5 font-medium">
                      <CheckCircle2 className="w-4 h-4" />
                      <span>Item saved to local IndexedDB catalog!</span>
                    </div>
                  ) : (
                    <span className="text-xs text-slate-400">
                      Save item to persist in local database
                    </span>
                  )}

                  <div className="flex items-center gap-2">
                    <button
                      onClick={() => handleSaveToCatalog('Competitor')}
                      className="px-3 py-2 text-xs font-medium text-slate-700 dark:text-slate-300 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 rounded-lg transition-colors"
                    >
                      Save as Competitor SKU
                    </button>
                    <button
                      onClick={() => handleSaveToCatalog('Kemitt')}
                      className="px-4 py-2 text-xs font-semibold text-white bg-emerald-600 hover:bg-emerald-500 rounded-lg shadow-sm transition-colors flex items-center gap-1.5"
                    >
                      <Plus className="w-3.5 h-3.5" />
                      <span>Save as Kemitt Catalog SKU</span>
                    </button>
                  </div>
                </div>
              </div>
            ) : (
              <div className="h-96 rounded-xl border border-dashed border-slate-200 dark:border-slate-800 flex flex-col items-center justify-center text-center p-8 text-slate-400">
                <ImageIcon className="w-10 h-10 mb-3 text-slate-300 dark:text-slate-700" />
                <h3 className="text-sm font-semibold text-slate-600 dark:text-slate-400 mb-1">
                  Vision Analysis Ready
                </h3>
                <p className="text-xs max-w-sm">
                  Upload an image or pick a preset on the left and click <strong>Run AI Vision Analysis</strong> to inspect design style, materials, and Egyptian market price bands.
                </p>
              </div>
            )}
          </div>
        </div>
      ) : (
        /* Manual URL / Text Search Tab */
        <div className="p-6 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs max-w-2xl mx-auto space-y-4">
          <h2 className="text-sm font-bold text-slate-900 dark:text-slate-100">
            Search Product by Name or Reference
          </h2>
          <p className="text-xs text-slate-500 dark:text-slate-400">
            Enter furniture keywords to generate targeted Egyptian retailer queries without paying for scraping tools.
          </p>

          <div className="space-y-3">
            <div>
              <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                Furniture Title / Model
              </label>
              <input
                type="text"
                value={manualTitle}
                onChange={(e) => setManualTitle(e.target.value)}
                placeholder="e.g. Travertine pedestal coffee table, Bouclé sofa"
                className="w-full px-3 py-2 text-xs md:text-sm bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-lg focus:outline-none focus:border-emerald-500 text-slate-900 dark:text-slate-100"
              />
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                  Category
                </label>
                <select
                  value={manualCategory}
                  onChange={(e) => setManualCategory(e.target.value)}
                  className="w-full px-3 py-2 text-xs bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-lg focus:outline-none focus:border-emerald-500 text-slate-900 dark:text-slate-100"
                >
                  <option value="Sofas & Sectionals">Sofas & Sectionals</option>
                  <option value="Armchairs & Accent Chairs">Armchairs & Accent Chairs</option>
                  <option value="Coffee & Side Tables">Coffee & Side Tables</option>
                  <option value="Dining Tables">Dining Tables</option>
                  <option value="Dining Chairs">Dining Chairs</option>
                  <option value="Beds & Headboards">Beds & Headboards</option>
                  <option value="Storage & Sideboards">Storage & Sideboards</option>
                </select>
              </div>
              <div>
                <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                  Key Materials
                </label>
                <input
                  type="text"
                  value={manualMaterials}
                  onChange={(e) => setManualMaterials(e.target.value)}
                  placeholder="e.g. Beechwood, Bouclé"
                  className="w-full px-3 py-2 text-xs bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-lg focus:outline-none focus:border-emerald-500 text-slate-900 dark:text-slate-100"
                />
              </div>
            </div>

            <div className="pt-2 flex justify-end">
              <a
                href={`https://www.google.com/search?tbm=shop&gl=eg&hl=en&q=${encodeURIComponent(`${manualTitle} ${manualCategory} Egypt`)}`}
                target="_blank"
                rel="noopener noreferrer"
                className="px-4 py-2 text-xs font-semibold text-white bg-emerald-600 hover:bg-emerald-500 rounded-lg shadow-sm flex items-center gap-1.5 transition-colors"
              >
                <Search className="w-3.5 h-3.5" />
                <span>Search Google Shopping Egypt</span>
                <ExternalLink className="w-3.5 h-3.5" />
              </a>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
