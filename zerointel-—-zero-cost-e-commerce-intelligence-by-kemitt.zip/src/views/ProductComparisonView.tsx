import React, { useState } from 'react';
import { Product } from '../types';
import { translations } from '../locales/translations';
import {
  GitCompare,
  ArrowRight,
  CheckCircle2,
  AlertTriangle,
  Layers,
  DollarSign,
  Sparkles,
  ExternalLink,
  Percent
} from 'lucide-react';

interface ProductComparisonViewProps {
  products: Product[];
  lang: 'en' | 'ar';
  onSelectProduct: (product: Product) => void;
}

export const ProductComparisonView: React.FC<ProductComparisonViewProps> = ({
  products,
  lang,
  onSelectProduct
}) => {
  const t = translations[lang];

  const kemittProducts = products.filter((p) => p.brand === 'Kemitt');
  const competitorProducts = products.filter((p) => p.brand === 'Competitor');

  const [selectedKemittId, setSelectedKemittId] = useState<string>(
    kemittProducts[0]?.id || ''
  );
  const [selectedCompetitorId, setSelectedCompetitorId] = useState<string>(
    competitorProducts[0]?.id || ''
  );

  const selectedKemitt = kemittProducts.find((p) => p.id === selectedKemittId);
  const selectedCompetitor = competitorProducts.find((p) => p.id === selectedCompetitorId);

  // Computations
  const priceDiff = selectedKemitt && selectedCompetitor
    ? selectedKemitt.priceEGP - selectedCompetitor.priceEGP
    : 0;

  const priceDiffPercent = selectedCompetitor && selectedCompetitor.priceEGP > 0
    ? ((priceDiff / selectedCompetitor.priceEGP) * 100).toFixed(1)
    : '0';

  const isKemittCheaper = priceDiff < 0;

  // Compute similarity score if not predefined
  const computeSimilarity = (): number => {
    if (!selectedKemitt || !selectedCompetitor) return 0;
    if (selectedCompetitor.similarityScore) return selectedCompetitor.similarityScore;

    let score = 50; // base
    if (selectedKemitt.category === selectedCompetitor.category) score += 20;
    if (selectedKemitt.style?.toLowerCase() === selectedCompetitor.style?.toLowerCase()) score += 15;

    // Check material overlap
    const kMats = (selectedKemitt.materials || []).map((m) => m.toLowerCase());
    const cMats = (selectedCompetitor.materials || []).map((m) => m.toLowerCase());
    const common = kMats.filter((m) => cMats.some((cm) => cm.includes(m) || m.includes(cm)));
    if (common.length > 0) score += 15;

    return Math.min(score, 98);
  };

  const similarityScore = computeSimilarity();

  return (
    <div className="p-6 md:p-8 space-y-8 max-w-7xl mx-auto">
      {/* Header */}
      <div className="border-b border-slate-200 dark:border-slate-800 pb-5">
        <div className="flex items-center gap-2 text-xs font-semibold uppercase tracking-wider text-emerald-600 dark:text-emerald-400 mb-1">
          <GitCompare className="w-3.5 h-3.5" />
          <span>Head-to-Head Retail Benchmark</span>
        </div>
        <h1 className="text-2xl md:text-3xl font-bold tracking-tight text-slate-900 dark:text-slate-100">
          {t.comparison.title}
        </h1>
        <p className="text-sm text-slate-500 dark:text-slate-400 mt-1">
          {t.comparison.subtitle}
        </p>
      </div>

      {/* Selectors Bar */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {/* Kemitt Item Picker */}
        <div className="p-4 rounded-xl bg-white dark:bg-slate-900 border border-emerald-500/30 shadow-xs">
          <label className="block text-xs font-semibold text-emerald-600 dark:text-emerald-400 mb-1.5 uppercase tracking-wider">
            {t.comparison.selectKemitt}
          </label>
          <select
            value={selectedKemittId}
            onChange={(e) => setSelectedKemittId(e.target.value)}
            className="w-full px-3 py-2 text-xs md:text-sm bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-lg text-slate-900 dark:text-slate-100 focus:outline-none focus:border-emerald-500"
          >
            {kemittProducts.map((p) => (
              <option key={p.id} value={p.id}>
                {p.name} — {p.priceEGP.toLocaleString()} EGP ({p.category})
              </option>
            ))}
          </select>
        </div>

        {/* Competitor Item Picker */}
        <div className="p-4 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs">
          <label className="block text-xs font-semibold text-slate-500 dark:text-slate-400 mb-1.5 uppercase tracking-wider">
            {t.comparison.selectCompetitor}
          </label>
          <select
            value={selectedCompetitorId}
            onChange={(e) => setSelectedCompetitorId(e.target.value)}
            className="w-full px-3 py-2 text-xs md:text-sm bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-lg text-slate-900 dark:text-slate-100 focus:outline-none focus:border-emerald-500"
          >
            {competitorProducts.map((p) => (
              <option key={p.id} value={p.id}>
                [{p.retailer}] {p.name} — {p.priceEGP.toLocaleString()} EGP
              </option>
            ))}
          </select>
        </div>
      </div>

      {selectedKemitt && selectedCompetitor ? (
        <div className="space-y-6">
          {/* Verdict Banner */}
          <div className="p-5 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-4">
            <div>
              <div className="text-xs font-semibold text-slate-500 uppercase tracking-wider mb-1">
                Value Positioning Summary
              </div>
              <div className="text-lg font-bold text-slate-900 dark:text-slate-100 flex items-center gap-2">
                {isKemittCheaper ? (
                  <span className="text-emerald-600 dark:text-emerald-400">
                    Kemitt is {Math.abs(Number(priceDiffPercent))}% more affordable ({Math.abs(priceDiff).toLocaleString()} EGP difference)
                  </span>
                ) : (
                  <span className="text-amber-600 dark:text-amber-400">
                    Kemitt is +{priceDiffPercent}% premium ({priceDiff.toLocaleString()} EGP difference)
                  </span>
                )}
              </div>
              <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
                Comparing {selectedKemitt.name} vs. {selectedCompetitor.retailer}'s {selectedCompetitor.name}.
              </p>
            </div>

            <div className="flex items-center gap-4 shrink-0">
              <div className="text-right">
                <div className="text-[11px] text-slate-400">{t.comparison.similarityScore}</div>
                <div className="text-2xl font-bold font-mono text-slate-800 dark:text-slate-200">
                  {similarityScore}%
                </div>
              </div>
            </div>
          </div>

          {/* Side-by-Side Comparison Matrix */}
          <div className="rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 overflow-hidden shadow-xs">
            <div className="grid grid-cols-12 border-b border-slate-200 dark:border-slate-800 text-xs font-semibold">
              <div className="col-span-3 p-4 bg-slate-50 dark:bg-slate-850 text-slate-500">
                Specification
              </div>
              <div className="col-span-4 md:col-span-4 p-4 bg-emerald-50/50 dark:bg-emerald-950/20 text-emerald-900 dark:text-emerald-300 border-l border-r border-slate-200 dark:border-slate-800">
                Kemitt (Our Product)
              </div>
              <div className="col-span-5 md:col-span-5 p-4 bg-slate-50 dark:bg-slate-850 text-slate-800 dark:text-slate-200">
                {selectedCompetitor.retailer} (Competitor)
              </div>
            </div>

            <div className="divide-y divide-slate-100 dark:divide-slate-800 text-xs">
              {/* Product Name */}
              <div className="grid grid-cols-12 items-center">
                <div className="col-span-3 p-4 font-medium text-slate-500">Product Name</div>
                <div className="col-span-4 p-4 font-bold text-slate-900 dark:text-slate-100 border-l border-r border-slate-200 dark:border-slate-800">
                  {selectedKemitt.name}
                </div>
                <div className="col-span-5 p-4 font-medium text-slate-800 dark:text-slate-200">
                  {selectedCompetitor.name}
                </div>
              </div>

              {/* Retail Price in EGP */}
              <div className="grid grid-cols-12 items-center bg-slate-50/40 dark:bg-slate-800/20">
                <div className="col-span-3 p-4 font-medium text-slate-500">Retail Price (EGP)</div>
                <div className="col-span-4 p-4 font-mono font-bold text-emerald-600 dark:text-emerald-400 text-base tabular-nums border-l border-r border-slate-200 dark:border-slate-800">
                  {selectedKemitt.priceEGP.toLocaleString()} EGP
                </div>
                <div className="col-span-5 p-4 font-mono font-semibold text-slate-800 dark:text-slate-200 text-base tabular-nums">
                  {selectedCompetitor.priceEGP.toLocaleString()} EGP
                </div>
              </div>

              {/* Category */}
              <div className="grid grid-cols-12 items-center">
                <div className="col-span-3 p-4 font-medium text-slate-500">Category</div>
                <div className="col-span-4 p-4 text-slate-800 dark:text-slate-200 border-l border-r border-slate-200 dark:border-slate-800">
                  {selectedKemitt.category}
                </div>
                <div className="col-span-5 p-4 text-slate-700 dark:text-slate-300">
                  {selectedCompetitor.category}
                </div>
              </div>

              {/* Materials */}
              <div className="grid grid-cols-12 items-center">
                <div className="col-span-3 p-4 font-medium text-slate-500">Primary Materials</div>
                <div className="col-span-4 p-4 text-slate-800 dark:text-slate-200 border-l border-r border-slate-200 dark:border-slate-800">
                  <div className="space-y-1">
                    {selectedKemitt.materials?.map((m, i) => (
                      <div key={i} className="flex items-center gap-1.5">
                        <CheckCircle2 className="w-3.5 h-3.5 text-emerald-500 shrink-0" />
                        <span>{m}</span>
                      </div>
                    ))}
                  </div>
                </div>
                <div className="col-span-5 p-4 text-slate-700 dark:text-slate-300">
                  <div className="space-y-1">
                    {selectedCompetitor.materials?.map((m, i) => (
                      <div key={i} className="flex items-center gap-1.5">
                        <span className="w-1.5 h-1.5 rounded-full bg-slate-400 shrink-0" />
                        <span>{m}</span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>

              {/* Dimensions */}
              <div className="grid grid-cols-12 items-center bg-slate-50/40 dark:bg-slate-800/20">
                <div className="col-span-3 p-4 font-medium text-slate-500">Dimensions</div>
                <div className="col-span-4 p-4 font-mono text-slate-800 dark:text-slate-200 border-l border-r border-slate-200 dark:border-slate-800">
                  {selectedKemitt.dimensions || 'Standard'}
                </div>
                <div className="col-span-5 p-4 font-mono text-slate-700 dark:text-slate-300">
                  {selectedCompetitor.dimensions || 'Standard'}
                </div>
              </div>

              {/* Design Style */}
              <div className="grid grid-cols-12 items-center">
                <div className="col-span-3 p-4 font-medium text-slate-500">Design Aesthetic</div>
                <div className="col-span-4 p-4 text-slate-800 dark:text-slate-200 border-l border-r border-slate-200 dark:border-slate-800">
                  {selectedKemitt.style || 'Contemporary'}
                </div>
                <div className="col-span-5 p-4 text-slate-700 dark:text-slate-300">
                  {selectedCompetitor.style || 'Contemporary'}
                </div>
              </div>

              {/* Stock Status */}
              <div className="grid grid-cols-12 items-center">
                <div className="col-span-3 p-4 font-medium text-slate-500">Stock Availability</div>
                <div className="col-span-4 p-4 border-l border-r border-slate-200 dark:border-slate-800">
                  <span className={selectedKemitt.inStock ? 'text-emerald-600 dark:text-emerald-400 font-semibold' : 'text-rose-600'}>
                    {selectedKemitt.inStock ? 'In Stock (Direct Egyptian Delivery)' : 'Made to Order'}
                  </span>
                </div>
                <div className="col-span-5 p-4">
                  <span className={selectedCompetitor.inStock ? 'text-emerald-600 dark:text-emerald-400 font-semibold' : 'text-rose-600 font-semibold'}>
                    {selectedCompetitor.inStock ? 'In Stock' : 'Out of Stock (Competitor Stockout)'}
                  </span>
                </div>
              </div>

              {/* Public URL Action */}
              <div className="grid grid-cols-12 items-center bg-slate-50/40 dark:bg-slate-800/20">
                <div className="col-span-3 p-4 font-medium text-slate-500">Retailer Reference</div>
                <div className="col-span-4 p-4 border-l border-r border-slate-200 dark:border-slate-800">
                  <a
                    href={selectedKemitt.url || 'https://kemitt.com'}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-emerald-600 dark:text-emerald-400 hover:underline flex items-center gap-1"
                  >
                    <span>View Kemitt Catalog</span>
                    <ExternalLink className="w-3.5 h-3.5" />
                  </a>
                </div>
                <div className="col-span-5 p-4">
                  {selectedCompetitor.url ? (
                    <a
                      href={selectedCompetitor.url}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-slate-600 dark:text-slate-300 hover:text-emerald-500 hover:underline flex items-center gap-1"
                    >
                      <span>Open on {selectedCompetitor.retailer}</span>
                      <ExternalLink className="w-3.5 h-3.5" />
                    </a>
                  ) : (
                    <span className="text-slate-400">No URL recorded</span>
                  )}
                </div>
              </div>
            </div>
          </div>
        </div>
      ) : (
        <div className="p-12 text-center text-slate-400 rounded-xl border border-dashed border-slate-200 dark:border-slate-800">
          Please add or select products to compare.
        </div>
      )}
    </div>
  );
};
