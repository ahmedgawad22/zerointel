import React, { useState } from 'react';
import { Product, RetailerName, FurnitureCategory } from '../types';
import { csvService } from '../services/csv';
import { translations } from '../locales/translations';
import {
  FileSpreadsheet,
  Upload,
  Download,
  CheckCircle2,
  AlertCircle,
  Table,
  ArrowRight,
  Database,
  FileText
} from 'lucide-react';

interface SpreadsheetHubViewProps {
  products: Product[];
  onImportProducts: (imported: Product[]) => void;
  lang: 'en' | 'ar';
}

const SAMPLE_CSV_CONTENT = `Product Name,Retailer,Brand,Category,Price EGP,Materials,Dimensions,URL
Modern Boucle Curved Armchair,Kemitt,Kemitt,Armchairs & Accent Chairs,11400,Ivory Boucle / Beechwood,82x80x74 cm,https://kemitt.com/products/luna-boucle-chair
Landskrona 3-Seat Sofa,IKEA Egypt,Competitor,Sofas & Sectionals,38450,Gunnared Fabric / Metal,204x89x78 cm,https://ikea.com/eg
Verona Marble Top Coffee Table,Hub Furniture,Competitor,Coffee & Side Tables,18500,Carrara Marble / Oak,120x65x42 cm,https://hubfurniture.com.eg
Rattan Weave Dining Chairs (Pair),In Your Room,Competitor,Dining Chairs,9600,Cane Mesh / Beech Wood,50x52x82 cm,https://inyourroom.com
Oslo Solid Oak Extendable Table,Kemitt,Kemitt,Dining Tables,22500,Solid White Oak,180-240x95x76 cm,https://kemitt.com`;

export const SpreadsheetHubView: React.FC<SpreadsheetHubViewProps> = ({
  products,
  onImportProducts,
  lang
}) => {
  const t = translations[lang];

  const [rawRows, setRawRows] = useState<string[][]>([]);
  const [headers, setHeaders] = useState<string[]>([]);
  const [fileName, setFileName] = useState<string>('');
  const [columnMapping, setColumnMapping] = useState<{
    nameCol: number;
    retailerCol: number;
    brandCol: number;
    categoryCol: number;
    priceCol: number;
    materialsCol: number;
    dimensionsCol: number;
    urlCol: number;
  }>({
    nameCol: 0,
    retailerCol: 1,
    brandCol: 2,
    categoryCol: 3,
    priceCol: 4,
    materialsCol: 5,
    dimensionsCol: 6,
    urlCol: 7
  });

  const [importSuccess, setImportSuccess] = useState<number | null>(null);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  const handleFileUpload = (content: string, name: string) => {
    try {
      const parsed = csvService.parseRaw(content);
      if (parsed.length < 2) {
        setErrorMsg('The uploaded spreadsheet must have a header row and at least one data row.');
        return;
      }
      setFileName(name);
      setHeaders(parsed[0]);
      setRawRows(parsed.slice(1));
      setErrorMsg(null);
      setImportSuccess(null);

      // Auto-detect header indices
      const hLower = parsed[0].map((h) => h.toLowerCase());
      const findIdx = (keywords: string[]) => hLower.findIndex((h) => keywords.some((k) => h.includes(k)));

      setColumnMapping({
        nameCol: Math.max(0, findIdx(['name', 'title', 'product', 'item'])),
        retailerCol: Math.max(0, findIdx(['retailer', 'store', 'brand', 'competitor'])),
        brandCol: Math.max(0, findIdx(['brand', 'owner', 'type'])),
        categoryCol: Math.max(0, findIdx(['category', 'type', 'section'])),
        priceCol: Math.max(0, findIdx(['price', 'egp', 'cost', 'amount'])),
        materialsCol: Math.max(0, findIdx(['material', 'fabric', 'wood', 'finish'])),
        dimensionsCol: Math.max(0, findIdx(['dimension', 'size', 'wxh', 'measure'])),
        urlCol: Math.max(0, findIdx(['url', 'link', 'website', 'href']))
      });
    } catch (err: unknown) {
      const error = err as Error;
      setErrorMsg('Failed to parse file: ' + error.message);
    }
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = () => {
      handleFileUpload(reader.result as string, file.name);
    };
    reader.readAsText(file);
  };

  const handleLoadSample = () => {
    handleFileUpload(SAMPLE_CSV_CONTENT, 'kemitt_egypt_furniture_sample.csv');
  };

  const handleCommitImport = () => {
    if (rawRows.length === 0) return;

    const importedProducts: Product[] = [];
    const today = new Date().toISOString().split('T')[0];

    rawRows.forEach((row, i) => {
      const name = row[columnMapping.nameCol]?.trim();
      const rawPrice = row[columnMapping.priceCol]?.replace(/[^0-9.]/g, '');
      const priceEGP = parseFloat(rawPrice || '0');

      if (!name || isNaN(priceEGP) || priceEGP <= 0) return;

      const retailerVal = (row[columnMapping.retailerCol]?.trim() || 'Competitor') as RetailerName;
      const brandVal = (row[columnMapping.brandCol]?.toLowerCase().includes('kemitt') || retailerVal === 'Kemitt')
        ? 'Kemitt'
        : 'Competitor';

      const catVal = (row[columnMapping.categoryCol]?.trim() || 'Sofas & Sectionals') as FurnitureCategory;
      const materials = (row[columnMapping.materialsCol] || '').split(/[,/]/).map((m) => m.trim()).filter(Boolean);
      const dimensions = row[columnMapping.dimensionsCol]?.trim();
      const url = row[columnMapping.urlCol]?.trim();

      importedProducts.push({
        id: `csv-${Date.now()}-${i}`,
        sku: `CSV-${Date.now().toString().slice(-4)}-${i + 1}`,
        name,
        brand: brandVal,
        retailer: brandVal === 'Kemitt' ? 'Kemitt' : retailerVal,
        category: catVal,
        priceEGP,
        originalPriceEGP: priceEGP,
        currency: 'EGP',
        materials,
        dimensions: dimensions || undefined,
        url: url || undefined,
        inStock: true,
        lastChecked: today,
        priceHistory: [{ date: today, priceEGP, note: `Imported from ${fileName || 'CSV'}` }]
      });
    });

    if (importedProducts.length === 0) {
      setErrorMsg('No valid rows could be imported. Please verify column mappings.');
      return;
    }

    onImportProducts(importedProducts);
    setImportSuccess(importedProducts.length);
    setRawRows([]);
    setHeaders([]);
  };

  const handleExportCatalog = () => {
    const csvStr = csvService.productsToCsv(products);
    csvService.downloadFile(csvStr, `kemitt_products_catalog_${new Date().toISOString().split('T')[0]}.csv`);
  };

  const handleExportPricing = () => {
    const csvStr = csvService.pricingAuditToCsv(products);
    csvService.downloadFile(csvStr, `kemitt_pricing_audit_${new Date().toISOString().split('T')[0]}.csv`);
  };

  return (
    <div className="p-6 md:p-8 space-y-8 max-w-7xl mx-auto">
      {/* Header */}
      <div className="border-b border-slate-200 dark:border-slate-800 pb-5 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 text-xs font-semibold uppercase tracking-wider text-emerald-600 dark:text-emerald-400 mb-1">
            <FileSpreadsheet className="w-3.5 h-3.5" />
            <span>Browser-Native Data Pipeline</span>
          </div>
          <h1 className="text-2xl md:text-3xl font-bold tracking-tight text-slate-900 dark:text-slate-100">
            {t.spreadsheetHub.title}
          </h1>
          <p className="text-sm text-slate-500 dark:text-slate-400 mt-1">
            {t.spreadsheetHub.subtitle}
          </p>
        </div>

        {/* Export Buttons */}
        <div className="flex items-center gap-2 shrink-0">
          <button
            onClick={handleExportCatalog}
            className="flex items-center gap-1.5 px-3 py-2 text-xs font-medium text-slate-700 dark:text-slate-300 bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-700 hover:bg-slate-50 dark:hover:bg-slate-750 rounded-lg transition-colors"
          >
            <Download className="w-3.5 h-3.5" />
            <span>{t.spreadsheetHub.exportCatalogCsv}</span>
          </button>
          <button
            onClick={handleExportPricing}
            className="flex items-center gap-1.5 px-3 py-2 text-xs font-medium text-slate-700 dark:text-slate-300 bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-700 hover:bg-slate-50 dark:hover:bg-slate-750 rounded-lg transition-colors"
          >
            <Download className="w-3.5 h-3.5" />
            <span>{t.spreadsheetHub.exportPricingCsv}</span>
          </button>
        </div>
      </div>

      {/* Upload & Sample Loading Area */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="md:col-span-2 p-6 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs space-y-4">
          <h2 className="text-sm font-bold text-slate-900 dark:text-slate-100">
            {t.spreadsheetHub.uploadCsv}
          </h2>

          <label className="border-2 border-dashed border-slate-300 dark:border-slate-700 hover:border-emerald-500 rounded-xl p-6 flex flex-col items-center justify-center text-center cursor-pointer transition-colors bg-slate-50/50 dark:bg-slate-800/30">
            <input
              type="file"
              accept=".csv,.tsv,.txt"
              onChange={handleFileChange}
              className="hidden"
            />
            <Upload className="w-8 h-8 text-slate-400 mb-2" />
            <span className="text-xs font-semibold text-slate-700 dark:text-slate-300">
              Click to browse or drop CSV/TSV file
            </span>
            <span className="text-[11px] text-slate-400 mt-1">
              Supports comma, tab, or semicolon separated files
            </span>
          </label>
        </div>

        <div className="p-6 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs flex flex-col justify-between space-y-4">
          <div>
            <h3 className="text-sm font-bold text-slate-900 dark:text-slate-100 mb-1">
              Test Sample Dataset
            </h3>
            <p className="text-xs text-slate-500 dark:text-slate-400 leading-relaxed">
              No CSV on hand? Load an authentic Egyptian furniture price benchmark spreadsheet with 5 real items to test mapping immediately.
            </p>
          </div>

          <button
            onClick={handleLoadSample}
            className="w-full py-2 px-3 text-xs font-semibold text-emerald-700 dark:text-emerald-300 bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-800/60 hover:bg-emerald-100 rounded-lg transition-colors flex items-center justify-center gap-1.5"
          >
            <FileText className="w-3.5 h-3.5" />
            <span>Load Egyptian Market Sample CSV</span>
          </button>
        </div>
      </div>

      {errorMsg && (
        <div className="p-3.5 rounded-lg bg-rose-50 dark:bg-rose-950/30 border border-rose-200 dark:border-rose-900 text-xs text-rose-700 dark:text-rose-300 flex items-center gap-2">
          <AlertCircle className="w-4 h-4 shrink-0" />
          <span>{errorMsg}</span>
        </div>
      )}

      {importSuccess !== null && (
        <div className="p-4 rounded-xl bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-800 text-xs text-emerald-800 dark:text-emerald-300 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <CheckCircle2 className="w-5 h-5 text-emerald-500" />
            <span>Successfully imported <strong>{importSuccess}</strong> products into local IndexedDB storage!</span>
          </div>
        </div>
      )}

      {/* Column Mapping & Preview Section */}
      {rawRows.length > 0 && (
        <div className="p-6 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs space-y-6">
          <div>
            <h3 className="text-sm font-bold text-slate-900 dark:text-slate-100">
              {t.spreadsheetHub.mapColumns} ({fileName})
            </h3>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
              Match your spreadsheet headers with Kemitt intelligence attributes
            </p>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <div>
              <label className="block text-xs font-medium text-slate-600 dark:text-slate-400 mb-1">
                Product Name *
              </label>
              <select
                value={columnMapping.nameCol}
                onChange={(e) => setColumnMapping({ ...columnMapping, nameCol: parseInt(e.target.value) })}
                className="w-full px-2.5 py-1.5 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-lg text-slate-900 dark:text-slate-100"
              >
                {headers.map((h, i) => (
                  <option key={i} value={i}>{h || `Col ${i + 1}`}</option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-600 dark:text-slate-400 mb-1">
                Retailer / Store
              </label>
              <select
                value={columnMapping.retailerCol}
                onChange={(e) => setColumnMapping({ ...columnMapping, retailerCol: parseInt(e.target.value) })}
                className="w-full px-2.5 py-1.5 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-lg text-slate-900 dark:text-slate-100"
              >
                {headers.map((h, i) => (
                  <option key={i} value={i}>{h || `Col ${i + 1}`}</option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-600 dark:text-slate-400 mb-1">
                Price (EGP) *
              </label>
              <select
                value={columnMapping.priceCol}
                onChange={(e) => setColumnMapping({ ...columnMapping, priceCol: parseInt(e.target.value) })}
                className="w-full px-2.5 py-1.5 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-lg text-slate-900 dark:text-slate-100"
              >
                {headers.map((h, i) => (
                  <option key={i} value={i}>{h || `Col ${i + 1}`}</option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-600 dark:text-slate-400 mb-1">
                Category
              </label>
              <select
                value={columnMapping.categoryCol}
                onChange={(e) => setColumnMapping({ ...columnMapping, categoryCol: parseInt(e.target.value) })}
                className="w-full px-2.5 py-1.5 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-lg text-slate-900 dark:text-slate-100"
              >
                {headers.map((h, i) => (
                  <option key={i} value={i}>{h || `Col ${i + 1}`}</option>
                ))}
              </select>
            </div>
          </div>

          {/* Table Preview */}
          <div className="space-y-2">
            <span className="text-xs font-semibold text-slate-700 dark:text-slate-300 block">
              {t.spreadsheetHub.previewRows} ({rawRows.length} rows loaded)
            </span>
            <div className="overflow-x-auto border border-slate-200 dark:border-slate-800 rounded-lg">
              <table className="w-full text-xs text-left rtl:text-right">
                <thead className="bg-slate-50 dark:bg-slate-850 text-slate-500 font-semibold border-b border-slate-200 dark:border-slate-800">
                  <tr>
                    <th className="p-2.5">Mapped Name</th>
                    <th className="p-2.5">Mapped Retailer</th>
                    <th className="p-2.5">Mapped Price</th>
                    <th className="p-2.5">Mapped Category</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 dark:divide-slate-800 font-mono">
                  {rawRows.slice(0, 5).map((row, i) => (
                    <tr key={i} className="hover:bg-slate-50 dark:hover:bg-slate-800/40">
                      <td className="p-2.5 font-sans font-medium text-slate-900 dark:text-slate-100">
                        {row[columnMapping.nameCol] || '—'}
                      </td>
                      <td className="p-2.5 font-sans text-slate-600 dark:text-slate-400">
                        {row[columnMapping.retailerCol] || '—'}
                      </td>
                      <td className="p-2.5 font-bold tabular-nums text-slate-900 dark:text-slate-100">
                        {row[columnMapping.priceCol] || '—'} EGP
                      </td>
                      <td className="p-2.5 font-sans text-slate-600 dark:text-slate-400">
                        {row[columnMapping.categoryCol] || '—'}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          {/* Commit Button */}
          <div className="flex items-center justify-end gap-3 pt-2">
            <button
              onClick={() => { setRawRows([]); setHeaders([]); }}
              className="px-4 py-2 text-xs font-medium text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-lg"
            >
              Clear
            </button>
            <button
              onClick={handleCommitImport}
              className="px-5 py-2 text-xs font-semibold text-white bg-emerald-600 hover:bg-emerald-500 rounded-lg shadow-sm flex items-center gap-1.5 transition-colors"
            >
              <Database className="w-3.5 h-3.5" />
              <span>{t.spreadsheetHub.importToDatabase} ({rawRows.length} Rows)</span>
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
