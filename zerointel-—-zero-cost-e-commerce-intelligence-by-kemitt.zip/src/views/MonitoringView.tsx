import React, { useState } from 'react';
import { MonitoringItem, Product } from '../types';
import { translations } from '../locales/translations';
import {
  Eye,
  ExternalLink,
  CheckCircle2,
  AlertTriangle,
  RefreshCw,
  Plus,
  Clock,
  History,
  TrendingDown,
  TrendingUp,
  XCircle
} from 'lucide-react';

interface MonitoringViewProps {
  monitoringItems: MonitoringItem[];
  products: Product[];
  onUpdateMonitoringItem: (item: MonitoringItem) => void;
  lang: 'en' | 'ar';
}

export const MonitoringView: React.FC<MonitoringViewProps> = ({
  monitoringItems,
  products,
  onUpdateMonitoringItem,
  lang
}) => {
  const t = translations[lang];

  const [activeFilter, setActiveFilter] = useState<'All' | 'Price Changed' | 'Out of Stock' | 'In Stock'>('All');
  const [editingId, setEditingId] = useState<string | null>(null);
  const [checkPrice, setCheckPrice] = useState<string>('');
  const [checkStatus, setCheckStatus] = useState<MonitoringItem['status']>('In Stock');
  const [checkNote, setCheckNote] = useState<string>('');

  const filteredItems = activeFilter === 'All'
    ? monitoringItems
    : monitoringItems.filter((m) => m.status === activeFilter);

  const handleStartCheck = (item: MonitoringItem) => {
    setEditingId(item.id);
    setCheckPrice(String(item.currentPriceEGP));
    setCheckStatus(item.status);
    setCheckNote('');
  };

  const handleSaveCheck = (item: MonitoringItem) => {
    const parsedPrice = parseFloat(checkPrice);
    if (isNaN(parsedPrice) || parsedPrice <= 0) return;

    const priceDelta = parsedPrice - item.lastKnownPriceEGP;
    const changePercent = item.lastKnownPriceEGP > 0
      ? parseFloat(((priceDelta / item.lastKnownPriceEGP) * 100).toFixed(1))
      : 0;

    let computedStatus: MonitoringItem['status'] = checkStatus;
    if (checkStatus !== 'Out of Stock' && checkStatus !== 'Discontinued') {
      if (Math.abs(changePercent) > 0.1) {
        computedStatus = 'Price Changed';
      } else {
        computedStatus = 'In Stock';
      }
    }

    const today = new Date().toISOString().split('T')[0];
    const newAuditNote = `${today}: Verified at ${parsedPrice.toLocaleString()} EGP (${computedStatus}). ${checkNote ? `Note: ${checkNote}` : ''}`;

    const updated: MonitoringItem = {
      ...item,
      currentPriceEGP: parsedPrice,
      lastCheckedDate: today,
      status: computedStatus,
      changePercent,
      auditNotes: [newAuditNote, ...(item.auditNotes || [])]
    };

    onUpdateMonitoringItem(updated);
    setEditingId(null);
  };

  return (
    <div className="p-6 md:p-8 space-y-8 max-w-7xl mx-auto">
      {/* Header */}
      <div className="border-b border-slate-200 dark:border-slate-800 pb-5">
        <div className="flex items-center gap-2 text-xs font-semibold uppercase tracking-wider text-emerald-600 dark:text-emerald-400 mb-1">
          <Eye className="w-3.5 h-3.5" />
          <span>Manual Retailer URL Verification Station</span>
        </div>
        <h1 className="text-2xl md:text-3xl font-bold tracking-tight text-slate-900 dark:text-slate-100">
          {t.monitoring.title}
        </h1>
        <p className="text-sm text-slate-500 dark:text-slate-400 mt-1">
          {t.monitoring.subtitle}
        </p>
      </div>

      {/* Philosophy Banner: Strict Zero-Cost & Anti-Fabrication */}
      <div className="p-4 rounded-xl bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-800 flex items-start gap-3">
        <Clock className="w-4 h-4 text-emerald-500 shrink-0 mt-0.5" />
        <div className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed">
          <strong>Authentic Zero-Cost Verification:</strong> Paid scraping proxies and headless browsers cost $50-$300/mo and get frequently blocked by Egyptian retail firewalls. ZeroIntel enables your merchandising team to open direct URLs with one click, confirm stock and prices accurately, and maintain an audit trail without phantom data.
        </div>
      </div>

      {/* Filter Tabs (Interactive buttons) */}
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-1.5 p-1 bg-slate-100 dark:bg-slate-800 rounded-lg">
          {(['All', 'Price Changed', 'Out of Stock', 'In Stock'] as const).map((filter) => (
            <button
              key={filter}
              onClick={() => setActiveFilter(filter)}
              className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors ${
                activeFilter === filter
                  ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-slate-100 shadow-xs'
                  : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
              }`}
            >
              {filter}
            </button>
          ))}
        </div>

        <span className="text-xs text-slate-400 font-mono">
          {filteredItems.length} competitor URLs in audit station
        </span>
      </div>

      {/* Monitoring List */}
      <div className="space-y-4">
        {filteredItems.map((item) => {
          const isEditing = editingId === item.id;

          return (
            <div
              key={item.id}
              className="p-5 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs space-y-4 hover:border-slate-300 dark:hover:border-slate-700 transition-colors"
            >
              {/* Row Header */}
              <div className="flex flex-col md:flex-row md:items-center justify-between gap-3">
                <div>
                  <div className="flex items-center gap-2 mb-1 text-xs">
                    <span className="font-semibold text-slate-800 dark:text-slate-200">
                      {item.retailer}
                    </span>
                    <span aria-hidden="true" className="text-slate-400">·</span>
                    <span className="text-slate-400 font-mono">Verified: {item.lastCheckedDate}</span>
                  </div>
                  <h3 className="text-base font-bold text-slate-900 dark:text-slate-100">
                    {item.productName}
                  </h3>
                </div>

                <div className="flex items-center gap-3">
                  <span className={`px-2.5 py-1 rounded-md text-xs font-semibold ${
                    item.status === 'Price Changed'
                      ? 'bg-amber-100 text-amber-800 dark:bg-amber-950 dark:text-amber-300'
                      : item.status === 'Out of Stock'
                      ? 'bg-rose-100 text-rose-800 dark:bg-rose-950 dark:text-rose-300'
                      : 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300'
                  }`}>
                    {item.status}
                  </span>

                  <a
                    href={item.url}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="px-3 py-1.5 text-xs font-medium text-emerald-700 dark:text-emerald-300 bg-emerald-50 dark:bg-emerald-950/40 hover:bg-emerald-100 dark:hover:bg-emerald-900/60 rounded-lg transition-colors flex items-center gap-1.5 shrink-0"
                  >
                    <span>{t.monitoring.verifyUrl}</span>
                    <ExternalLink className="w-3.5 h-3.5" />
                  </a>
                </div>
              </div>

              {/* Price & Delta Strip */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-3 p-3 rounded-lg bg-slate-50 dark:bg-slate-850 text-xs">
                <div>
                  <span className="text-slate-400 block mb-0.5">Current Recorded Price</span>
                  <span className="font-mono font-bold text-base text-slate-900 dark:text-slate-100 tabular-nums">
                    {item.currentPriceEGP.toLocaleString()} EGP
                  </span>
                </div>
                <div>
                  <span className="text-slate-400 block mb-0.5">Baseline Recorded Price</span>
                  <span className="font-mono text-slate-600 dark:text-slate-400 tabular-nums">
                    {item.lastKnownPriceEGP.toLocaleString()} EGP
                  </span>
                </div>
                <div>
                  <span className="text-slate-400 block mb-0.5">Variance Percentage</span>
                  <span className={`font-mono font-semibold ${item.changePercent < 0 ? 'text-emerald-600 dark:text-emerald-400' : item.changePercent > 0 ? 'text-amber-600 dark:text-amber-400' : 'text-slate-500'}`}>
                    {item.changePercent !== 0 ? `${item.changePercent > 0 ? `+${item.changePercent}` : item.changePercent}%` : 'Stable (0%)'}
                  </span>
                </div>
              </div>

              {/* Inline Audit Form */}
              {isEditing ? (
                <div className="p-4 rounded-lg bg-emerald-50/50 dark:bg-emerald-950/20 border border-emerald-200 dark:border-emerald-800/60 space-y-3">
                  <div className="text-xs font-semibold text-emerald-900 dark:text-emerald-300">
                    Log Direct URL Verification
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                    <div>
                      <label className="block text-[11px] text-slate-600 dark:text-slate-400 mb-1">
                        New Observed Price (EGP)
                      </label>
                      <input
                        type="number"
                        value={checkPrice}
                        onChange={(e) => setCheckPrice(e.target.value)}
                        className="w-full px-2.5 py-1.5 text-xs font-mono bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-md text-slate-900 dark:text-slate-100"
                      />
                    </div>

                    <div>
                      <label className="block text-[11px] text-slate-600 dark:text-slate-400 mb-1">
                        Stock Status
                      </label>
                      <select
                        value={checkStatus}
                        onChange={(e) => setCheckStatus(e.target.value as MonitoringItem['status'])}
                        className="w-full px-2.5 py-1.5 text-xs bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-md text-slate-900 dark:text-slate-100"
                      >
                        <option value="In Stock">In Stock</option>
                        <option value="Out of Stock">Out of Stock</option>
                        <option value="Price Changed">Price Changed</option>
                        <option value="Discontinued">Discontinued</option>
                      </select>
                    </div>

                    <div>
                      <label className="block text-[11px] text-slate-600 dark:text-slate-400 mb-1">
                        Audit Note
                      </label>
                      <input
                        type="text"
                        value={checkNote}
                        onChange={(e) => setCheckNote(e.target.value)}
                        placeholder="e.g. Flash sale ending in 2 days"
                        className="w-full px-2.5 py-1.5 text-xs bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-md text-slate-900 dark:text-slate-100"
                      />
                    </div>
                  </div>

                  <div className="flex items-center justify-end gap-2 pt-1">
                    <button
                      onClick={() => setEditingId(null)}
                      className="px-3 py-1.5 text-xs text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-md"
                    >
                      Cancel
                    </button>
                    <button
                      onClick={() => handleSaveCheck(item)}
                      className="px-4 py-1.5 text-xs font-semibold text-white bg-emerald-600 hover:bg-emerald-500 rounded-md shadow-sm"
                    >
                      Save Verification
                    </button>
                  </div>
                </div>
              ) : (
                <div className="flex items-center justify-between text-xs pt-1">
                  <div className="text-slate-500 truncate max-w-lg">
                    {item.auditNotes && item.auditNotes.length > 0
                      ? item.auditNotes[0]
                      : 'No verification notes recorded yet.'}
                  </div>
                  <button
                    onClick={() => handleStartCheck(item)}
                    className="px-3 py-1 text-xs font-medium text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-md transition-colors"
                  >
                    + Log Verification
                  </button>
                </div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
};
