import React, { useState } from 'react';
import { AppSettings } from '../types';
import { localDb } from '../services/db';
import { geminiService, HealthStatus } from '../services/gemini';
import { translations } from '../locales/translations';
import {
  Settings,
  Moon,
  Sun,
  Languages,
  Database,
  Download,
  Upload,
  RefreshCw,
  CheckCircle2,
  AlertCircle,
  ShieldCheck,
  Trash2,
  Cpu
} from 'lucide-react';

interface SettingsViewProps {
  settings: AppSettings;
  onUpdateSettings: (settings: AppSettings) => void;
  onReloadData: () => void;
  lang: 'en' | 'ar';
}

export const SettingsView: React.FC<SettingsViewProps> = ({
  settings,
  onUpdateSettings,
  onReloadData,
  lang
}) => {
  const t = translations[lang];

  const [testingGemini, setTestingGemini] = useState(false);
  const [healthInfo, setHealthInfo] = useState<HealthStatus | null>(null);
  const [healthError, setHealthError] = useState<string | null>(null);
  const [backupMsg, setBackupMsg] = useState<string | null>(null);

  const handleTestGemini = async () => {
    setTestingGemini(true);
    setHealthError(null);
    setHealthInfo(null);
    try {
      const res = await geminiService.getHealth();
      setHealthInfo(res);
    } catch (err: unknown) {
      const error = err as Error;
      setHealthError(error.message || 'Failed to connect to server endpoint');
    } finally {
      setTestingGemini(false);
    }
  };

  const handleDownloadBackup = async () => {
    try {
      const jsonStr = await localDb.exportAllData();
      const blob = new Blob([jsonStr], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.download = `zerointel_kemitt_backup_${new Date().toISOString().split('T')[0]}.json`;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      URL.revokeObjectURL(url);
      setBackupMsg('Backup exported successfully as JSON file.');
      setTimeout(() => setBackupMsg(null), 3000);
    } catch (e) {
      setBackupMsg('Failed to export backup.');
    }
  };

  const handleRestoreBackup = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = async () => {
      try {
        const success = await localDb.importAllData(reader.result as string);
        if (success) {
          setBackupMsg('Database restored successfully from backup!');
          onReloadData();
        } else {
          setBackupMsg('Invalid backup file format.');
        }
      } catch (err) {
        setBackupMsg('Failed to parse JSON backup.');
      }
      setTimeout(() => setBackupMsg(null), 4000);
    };
    reader.readAsText(file);
  };

  const handleResetDefaults = async () => {
    if (window.confirm('Reset all local data and reload default Egyptian furniture catalog?')) {
      await localDb.resetToDefaults();
      onReloadData();
      setBackupMsg('Database reset to realistic Egyptian market benchmark items.');
      setTimeout(() => setBackupMsg(null), 3000);
    }
  };

  const handleClearAll = async () => {
    if (window.confirm('Are you sure you want to completely erase all products, trends, and opportunities from IndexedDB?')) {
      await localDb.clearAll();
      onReloadData();
      setBackupMsg('Local database erased.');
      setTimeout(() => setBackupMsg(null), 3000);
    }
  };

  return (
    <div className="p-6 md:p-8 space-y-8 max-w-5xl mx-auto">
      {/* Header */}
      <div className="border-b border-slate-200 dark:border-slate-800 pb-5">
        <div className="flex items-center gap-2 text-xs font-semibold uppercase tracking-wider text-emerald-600 dark:text-emerald-400 mb-1">
          <Settings className="w-3.5 h-3.5" />
          <span>Local Engine & System Preferences</span>
        </div>
        <h1 className="text-2xl md:text-3xl font-bold tracking-tight text-slate-900 dark:text-slate-100">
          {t.settings.title}
        </h1>
        <p className="text-sm text-slate-500 dark:text-slate-400 mt-1">
          {t.settings.subtitle}
        </p>
      </div>

      {backupMsg && (
        <div className="p-3.5 rounded-xl bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-800 text-xs text-emerald-800 dark:text-emerald-300 flex items-center gap-2">
          <CheckCircle2 className="w-4 h-4 text-emerald-500 shrink-0" />
          <span>{backupMsg}</span>
        </div>
      )}

      {/* Preferences Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Appearance & Language */}
        <div className="p-6 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs space-y-5">
          <h2 className="text-sm font-bold text-slate-900 dark:text-slate-100 flex items-center gap-2">
            <span>Interface Preferences</span>
          </h2>

          {/* Theme Selector */}
          <div>
            <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-2">
              {t.settings.theme}
            </label>
            <div className="grid grid-cols-2 gap-2 p-1 bg-slate-100 dark:bg-slate-800 rounded-lg">
              <button
                type="button"
                onClick={() => onUpdateSettings({ ...settings, theme: 'dark' })}
                className={`py-2 px-3 text-xs font-semibold rounded-md flex items-center justify-center gap-2 transition-colors ${
                  settings.theme === 'dark'
                    ? 'bg-slate-900 text-white shadow-xs'
                    : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
                }`}
              >
                <Moon className="w-3.5 h-3.5" />
                <span>{t.settings.darkMode}</span>
              </button>
              <button
                type="button"
                onClick={() => onUpdateSettings({ ...settings, theme: 'light' })}
                className={`py-2 px-3 text-xs font-semibold rounded-md flex items-center justify-center gap-2 transition-colors ${
                  settings.theme === 'light'
                    ? 'bg-white text-slate-900 shadow-xs'
                    : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
                }`}
              >
                <Sun className="w-3.5 h-3.5" />
                <span>{t.settings.lightMode}</span>
              </button>
            </div>
          </div>

          {/* Language Selector */}
          <div>
            <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-2">
              {t.settings.language}
            </label>
            <div className="grid grid-cols-2 gap-2 p-1 bg-slate-100 dark:bg-slate-800 rounded-lg">
              <button
                type="button"
                onClick={() => onUpdateSettings({ ...settings, language: 'en' })}
                className={`py-2 px-3 text-xs font-semibold rounded-md transition-colors ${
                  settings.language === 'en'
                    ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-slate-100 shadow-xs'
                    : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
                }`}
              >
                English (LTR)
              </button>
              <button
                type="button"
                onClick={() => onUpdateSettings({ ...settings, language: 'ar' })}
                className={`py-2 px-3 text-xs font-semibold rounded-md transition-colors ${
                  settings.language === 'ar'
                    ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-slate-100 shadow-xs'
                    : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
                }`}
              >
                العربية (RTL)
              </button>
            </div>
          </div>
        </div>

        {/* Gemini Free Quota Health Test */}
        <div className="p-6 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs space-y-4 flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between mb-2">
              <h2 className="text-sm font-bold text-slate-900 dark:text-slate-100 flex items-center gap-2">
                <Cpu className="w-4 h-4 text-emerald-500" />
                <span>Gemini API Health</span>
              </h2>
              <span className="text-[10px] text-emerald-600 dark:text-emerald-400 font-mono font-semibold">
                $0.00 Free Quota
              </span>
            </div>
            <p className="text-xs text-slate-500 dark:text-slate-400 leading-relaxed mb-3">
              Verify server-side connectivity to Google AI Studio's Gemini 3.8 Flash endpoint.
            </p>

            {healthInfo && (
              <div className="p-3 rounded-lg bg-emerald-50 dark:bg-emerald-950/30 border border-emerald-200 dark:border-emerald-800 text-xs space-y-1">
                <div className="font-semibold text-emerald-900 dark:text-emerald-300 flex items-center gap-1.5">
                  <CheckCircle2 className="w-4 h-4 text-emerald-500" />
                  <span>{t.settings.connectionSuccess}</span>
                </div>
                <div className="text-[11px] text-emerald-800 dark:text-emerald-300">
                  Model: {healthInfo.model} · Quota: {healthInfo.quotaTier} ({healthInfo.rpmLimit} RPM / {healthInfo.rpdLimit} RPD)
                </div>
                <div className="text-[11px] text-emerald-700/80 dark:text-emerald-400/80 font-mono">
                  Session Calls: {healthInfo.apiCallsThisSession} · Operating Cost: {healthInfo.operatingCost}
                </div>
              </div>
            )}

            {healthError && (
              <div className="p-3 rounded-lg bg-rose-50 dark:bg-rose-950/30 border border-rose-200 dark:border-rose-900 text-xs text-rose-700 dark:text-rose-300 flex items-center gap-2">
                <AlertCircle className="w-4 h-4 shrink-0" />
                <span>{healthError}</span>
              </div>
            )}
          </div>

          <button
            onClick={handleTestGemini}
            disabled={testingGemini}
            className="w-full py-2 px-3 text-xs font-semibold text-slate-700 dark:text-slate-200 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 rounded-lg transition-colors flex items-center justify-center gap-2"
          >
            {testingGemini ? (
              <>
                <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                <span>Testing Connection...</span>
              </>
            ) : (
              <>
                <ShieldCheck className="w-3.5 h-3.5 text-emerald-500" />
                <span>{t.settings.testGemini}</span>
              </>
            )}
          </button>
        </div>
      </div>

      {/* Local Data Backup & Persistence */}
      <div className="p-6 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs space-y-4">
        <div>
          <h2 className="text-sm font-bold text-slate-900 dark:text-slate-100 flex items-center gap-2">
            <Database className="w-4 h-4 text-blue-500" />
            <span>{t.settings.backupRestore}</span>
          </h2>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
            ZeroIntel saves everything inside your browser's IndexedDB. Export a complete JSON backup to transfer your intelligence data across computers or maintain offline archives.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-3 pt-2">
          <button
            onClick={handleDownloadBackup}
            className="px-4 py-2 text-xs font-semibold text-white bg-slate-900 dark:bg-slate-800 hover:bg-slate-800 dark:hover:bg-slate-700 rounded-lg shadow-sm flex items-center gap-1.5 transition-colors"
          >
            <Download className="w-3.5 h-3.5" />
            <span>{t.settings.downloadBackup}</span>
          </button>

          <label className="px-4 py-2 text-xs font-semibold text-slate-700 dark:text-slate-300 bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-700 hover:bg-slate-50 dark:hover:bg-slate-750 rounded-lg shadow-xs flex items-center gap-1.5 cursor-pointer transition-colors">
            <Upload className="w-3.5 h-3.5 text-slate-500" />
            <span>{t.settings.restoreBackup}</span>
            <input
              type="file"
              accept=".json"
              onChange={handleRestoreBackup}
              className="hidden"
            />
          </label>

          <button
            onClick={handleResetDefaults}
            className="px-4 py-2 text-xs font-medium text-emerald-700 dark:text-emerald-300 bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-800/60 hover:bg-emerald-100 rounded-lg transition-colors flex items-center gap-1.5"
          >
            <RefreshCw className="w-3.5 h-3.5" />
            <span>{t.settings.seedDefaults}</span>
          </button>
        </div>
      </div>

      {/* Danger Zone */}
      <div className="p-5 rounded-xl border border-rose-200 dark:border-rose-900/60 bg-rose-50/30 dark:bg-rose-950/10 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <span className="text-xs font-bold text-rose-800 dark:text-rose-300 block mb-0.5">
            Database Reset
          </span>
          <p className="text-xs text-rose-700/80 dark:text-rose-400">
            Permanently clear all products, trends, opportunities, and price history from this browser.
          </p>
        </div>
        <button
          onClick={handleClearAll}
          className="px-3.5 py-1.5 text-xs font-semibold text-rose-700 dark:text-rose-300 border border-rose-300 dark:border-rose-800 hover:bg-rose-100 dark:hover:bg-rose-900/40 rounded-lg transition-colors shrink-0"
        >
          {t.settings.dangerZone}
        </button>
      </div>
    </div>
  );
};
