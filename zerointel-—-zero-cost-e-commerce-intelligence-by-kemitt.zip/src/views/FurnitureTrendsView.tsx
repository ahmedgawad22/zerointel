import React, { useState } from 'react';
import { TrendItem } from '../types';
import { geminiService } from '../services/gemini';
import { translations } from '../locales/translations';
import {
  TrendingUp,
  Sparkles,
  RefreshCw,
  Plus,
  CheckCircle2,
  AlertCircle,
  Tag,
  Calendar,
  ExternalLink,
  ChevronRight,
  Compass
} from 'lucide-react';

interface FurnitureTrendsViewProps {
  trends: TrendItem[];
  onSaveTrend: (trend: TrendItem) => void;
  lang: 'en' | 'ar';
}

export const FurnitureTrendsView: React.FC<FurnitureTrendsViewProps> = ({
  trends,
  onSaveTrend,
  lang
}) => {
  const t = translations[lang];

  const [trendInput, setTrendInput] = useState('');
  const [contextInput, setContextInput] = useState('');
  const [analyzing, setAnalyzing] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [extractedTrend, setExtractedTrend] = useState<Partial<TrendItem> | null>(null);
  const [selectedTag, setSelectedTag] = useState<string>('All');

  const allTags = ['All', ...Array.from(new Set(trends.flatMap((t) => t.tags || [])))];

  const filteredTrends = selectedTag === 'All'
    ? trends
    : trends.filter((t) => t.tags?.includes(selectedTag));

  const handleAnalyzeTrend = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!trendInput.trim()) return;

    setAnalyzing(true);
    setErrorMsg(null);
    try {
      const result = await geminiService.analyzeTrend(trendInput, contextInput);
      setExtractedTrend(result);
    } catch (err: unknown) {
      const error = err as Error;
      setErrorMsg(error.message || 'Failed to analyze furniture trend.');
    } finally {
      setAnalyzing(false);
    }
  };

  const handleSaveToRepository = () => {
    if (!extractedTrend) return;

    const newTrend: TrendItem = {
      id: `trd-${Date.now()}`,
      title: extractedTrend.title || trendInput,
      macroMovement: extractedTrend.macroMovement || 'Modern Living',
      stage: (extractedTrend.stage as any) || 'Accelerating',
      egyptianMarketFit: extractedTrend.egyptianMarketFit || {
        viabilityScore: 'High',
        targetAudience: 'Modern Egyptian homeowners',
        localProductionFeasibility: 'Egyptian workshop compatible',
        priceAcceptanceEGP: '12,000 - 25,000 EGP'
      },
      keyDesignElements: extractedTrend.keyDesignElements || ['Organic silhouette', 'Natural texture'],
      recommendedKemittAction: extractedTrend.recommendedKemittAction || 'Develop sample prototype',
      dateAdded: new Date().toISOString().split('T')[0],
      source: 'Gemini Trend Synthesizer ($0 Free Quota)',
      tags: ['Trend', 'Design Intelligence']
    };

    onSaveTrend(newTrend);
    setExtractedTrend(null);
    setTrendInput('');
    setContextInput('');
  };

  return (
    <div className="p-6 md:p-8 space-y-8 max-w-7xl mx-auto">
      {/* Header */}
      <div className="border-b border-slate-200 dark:border-slate-800 pb-5">
        <div className="flex items-center gap-2 text-xs font-semibold uppercase tracking-wider text-emerald-600 dark:text-emerald-400 mb-1">
          <Compass className="w-3.5 h-3.5" />
          <span>Macro Aesthetics & Local Adoption</span>
        </div>
        <h1 className="text-2xl md:text-3xl font-bold tracking-tight text-slate-900 dark:text-slate-100">
          {t.trends.title}
        </h1>
        <p className="text-sm text-slate-500 dark:text-slate-400 mt-1">
          {t.trends.subtitle}
        </p>
      </div>

      {/* Input / Analyzer Box */}
      <div className="p-6 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs space-y-4">
        <div className="flex items-center justify-between">
          <h2 className="text-sm font-bold text-slate-900 dark:text-slate-100 flex items-center gap-2">
            <Sparkles className="w-4 h-4 text-emerald-500" />
            <span>{t.trends.newTrendInput}</span>
          </h2>
          <span className="text-[11px] text-slate-400">Gemini 3.8 Flash Free Quota</span>
        </div>

        <form onSubmit={handleAnalyzeTrend} className="space-y-3">
          <div>
            <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
              Trend Signal / Motif / Keyword *
            </label>
            <input
              type="text"
              required
              value={trendInput}
              onChange={(e) => setTrendInput(e.target.value)}
              placeholder={t.trends.inputPlaceholder}
              className="w-full px-3 py-2 text-xs md:text-sm bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-lg focus:outline-none focus:border-emerald-500 text-slate-900 dark:text-slate-100"
            />
          </div>

          <div>
            <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
              Social Media Caption, Observation, or Source URL
            </label>
            <textarea
              rows={2}
              value={contextInput}
              onChange={(e) => setContextInput(e.target.value)}
              placeholder="e.g. Heavy presence on Pinterest Cairo design boards; seen in new New Cairo residential developments..."
              className="w-full px-3 py-2 text-xs md:text-sm bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-lg focus:outline-none focus:border-emerald-500 text-slate-900 dark:text-slate-100"
            />
          </div>

          <div className="flex items-center justify-end">
            <button
              type="submit"
              disabled={analyzing || !trendInput.trim()}
              className="px-4 py-2 text-xs font-semibold text-white bg-emerald-600 hover:bg-emerald-500 disabled:opacity-50 rounded-lg shadow-sm flex items-center gap-1.5 transition-colors"
            >
              {analyzing ? (
                <>
                  <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                  <span>Synthesizing Trend Intelligence...</span>
                </>
              ) : (
                <>
                  <Sparkles className="w-3.5 h-3.5" />
                  <span>{t.trends.analyzeTrend}</span>
                </>
              )}
            </button>
          </div>
        </form>

        {errorMsg && (
          <div className="p-3 rounded-lg bg-rose-50 dark:bg-rose-950/30 border border-rose-200 dark:border-rose-900 text-xs text-rose-700 dark:text-rose-300 flex items-center gap-2">
            <AlertCircle className="w-4 h-4 shrink-0" />
            <span>{errorMsg}</span>
          </div>
        )}

        {/* Synthesized Result Preview */}
        {extractedTrend && (
          <div className="mt-4 p-5 rounded-xl bg-slate-50 dark:bg-slate-850 border border-emerald-500/30 space-y-4 animate-in fade-in duration-200">
            <div className="flex items-start justify-between gap-4">
              <div>
                <div className="text-xs font-semibold text-emerald-600 dark:text-emerald-400 mb-0.5">
                  Synthesized Trend Intelligence
                </div>
                <h3 className="text-lg font-bold text-slate-900 dark:text-slate-100">
                  {extractedTrend.title}
                </h3>
                <div className="text-xs text-slate-500 mt-0.5">
                  Macro Movement: {extractedTrend.macroMovement} · Stage: {extractedTrend.stage}
                </div>
              </div>
              <button
                onClick={handleSaveToRepository}
                className="px-3.5 py-1.5 text-xs font-semibold text-white bg-emerald-600 hover:bg-emerald-500 rounded-lg shadow-sm flex items-center gap-1.5 transition-colors shrink-0"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>Save to Repository</span>
              </button>
            </div>

            {extractedTrend.egyptianMarketFit && (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-xs">
                <div className="p-3 rounded-lg bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800">
                  <span className="text-slate-400 block mb-1">Egyptian Target Demographic</span>
                  <span className="font-medium text-slate-800 dark:text-slate-200">
                    {extractedTrend.egyptianMarketFit.targetAudience}
                  </span>
                </div>
                <div className="p-3 rounded-lg bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800">
                  <span className="text-slate-400 block mb-1">Local Production Feasibility</span>
                  <span className="font-medium text-slate-800 dark:text-slate-200">
                    {extractedTrend.egyptianMarketFit.localProductionFeasibility}
                  </span>
                </div>
              </div>
            )}

            {extractedTrend.recommendedKemittAction && (
              <div className="p-3.5 rounded-lg bg-emerald-50/70 dark:bg-emerald-950/20 border border-emerald-200 dark:border-emerald-800/60 text-xs">
                <span className="font-semibold text-emerald-900 dark:text-emerald-300 block mb-1">
                  Recommended Kemitt Action Directive:
                </span>
                <p className="text-emerald-950 dark:text-emerald-200">
                  {extractedTrend.recommendedKemittAction}
                </p>
              </div>
            )}
          </div>
        )}
      </div>

      {/* Tracked Trends Repository */}
      <div className="space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <h2 className="text-base font-bold text-slate-900 dark:text-slate-100">
            {t.trends.activeTrends} ({filteredTrends.length})
          </h2>

          {/* Tag Filter Pills (Interactive button filter tabs) */}
          <div className="flex flex-wrap items-center gap-1.5">
            {allTags.map((tag) => (
              <button
                key={tag}
                onClick={() => setSelectedTag(tag)}
                className={`px-2.5 py-1 text-xs rounded-md font-medium transition-colors ${
                  selectedTag === tag
                    ? 'bg-slate-900 dark:bg-slate-100 text-white dark:text-slate-900'
                    : 'bg-white dark:bg-slate-800 text-slate-600 dark:text-slate-300 border border-slate-200 dark:border-slate-700 hover:bg-slate-50'
                }`}
              >
                {tag}
              </button>
            ))}
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredTrends.map((trend) => (
            <div
              key={trend.id}
              className="p-5 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs flex flex-col justify-between space-y-4 hover:border-slate-300 dark:hover:border-slate-700 transition-colors"
            >
              <div>
                <div className="flex items-center justify-between text-xs text-slate-400 mb-1.5">
                  <span className="uppercase font-semibold tracking-wider text-[10px] text-emerald-600 dark:text-emerald-400">
                    {trend.stage}
                  </span>
                  <span className="font-mono">{trend.dateAdded}</span>
                </div>

                <h3 className="text-base font-bold text-slate-900 dark:text-slate-100 mb-1">
                  {trend.title}
                </h3>

                <p className="text-xs text-slate-500 dark:text-slate-400 mb-3">
                  Movement: {trend.macroMovement}
                </p>

                {/* Key Design Elements */}
                <div className="space-y-1 mb-4">
                  {trend.keyDesignElements?.map((el, i) => (
                    <div key={i} className="text-xs text-slate-700 dark:text-slate-300 flex items-start gap-1.5">
                      <span className="text-emerald-500 font-bold shrink-0">·</span>
                      <span>{el}</span>
                    </div>
                  ))}
                </div>

                {/* Local Viability & Audience */}
                <div className="p-3 rounded-lg bg-slate-50 dark:bg-slate-850 border border-slate-200 dark:border-slate-800 text-xs space-y-1">
                  <div className="flex items-center justify-between font-medium">
                    <span className="text-slate-500">Market Viability:</span>
                    <span className="text-emerald-600 dark:text-emerald-400 font-semibold">
                      {trend.egyptianMarketFit?.viabilityScore || 'High'}
                    </span>
                  </div>
                  <div className="text-[11px] text-slate-600 dark:text-slate-400">
                    {trend.egyptianMarketFit?.targetAudience}
                  </div>
                </div>
              </div>

              {/* Action Directive */}
              <div className="pt-3 border-t border-slate-100 dark:border-slate-800">
                <span className="text-[11px] font-semibold text-slate-500 uppercase tracking-wider block mb-1">
                  Kemitt Merchandising Action
                </span>
                <p className="text-xs font-medium text-slate-800 dark:text-slate-200">
                  {trend.recommendedKemittAction}
                </p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
