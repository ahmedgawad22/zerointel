import React, { useState } from 'react';
import { Product, OpportunityItem, TrendItem, MonitoringItem } from '../types';
import { csvService } from '../services/csv';
import { translations } from '../locales/translations';
import {
  FileText,
  Download,
  Copy,
  Check,
  FileSpreadsheet,
  Database,
  Sparkles,
  ArrowRight
} from 'lucide-react';

interface ReportsViewProps {
  products: Product[];
  opportunities: OpportunityItem[];
  trends: TrendItem[];
  monitoring: MonitoringItem[];
  lang: 'en' | 'ar';
}

export const ReportsView: React.FC<ReportsViewProps> = ({
  products,
  opportunities,
  trends,
  monitoring,
  lang
}) => {
  const t = translations[lang];

  const [copiedMd, setCopiedMd] = useState(false);
  const today = new Date().toISOString().split('T')[0];

  const markdownContent = csvService.generateMarkdownReport(
    products,
    opportunities,
    trends,
    monitoring
  );

  const handleCopyMarkdown = () => {
    navigator.clipboard.writeText(markdownContent);
    setCopiedMd(true);
    setTimeout(() => setCopiedMd(false), 2500);
  };

  const handleDownloadMarkdown = () => {
    csvService.downloadFile(
      markdownContent,
      `kemitt_intelligence_report_${today}.md`,
      'text/markdown;charset=utf-8;'
    );
  };

  const handleDownloadCatalogCsv = () => {
    const csv = csvService.productsToCsv(products);
    csvService.downloadFile(csv, `kemitt_catalog_matrix_${today}.csv`);
  };

  const handleDownloadPricingCsv = () => {
    const csv = csvService.pricingAuditToCsv(products);
    csvService.downloadFile(csv, `kemitt_pricing_audit_${today}.csv`);
  };

  return (
    <div className="p-6 md:p-8 space-y-8 max-w-7xl mx-auto">
      {/* Header */}
      <div className="border-b border-slate-200 dark:border-slate-800 pb-5">
        <div className="flex items-center gap-2 text-xs font-semibold uppercase tracking-wider text-emerald-600 dark:text-emerald-400 mb-1">
          <FileText className="w-3.5 h-3.5" />
          <span>Executive Briefings & Data Exports</span>
        </div>
        <h1 className="text-2xl md:text-3xl font-bold tracking-tight text-slate-900 dark:text-slate-100">
          {t.reports.title}
        </h1>
        <p className="text-sm text-slate-500 dark:text-slate-400 mt-1">
          {t.reports.subtitle}
        </p>
      </div>

      {/* Quick Export Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {/* Markdown Brief */}
        <div className="p-5 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs flex flex-col justify-between space-y-4">
          <div>
            <div className="w-8 h-8 rounded-lg bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 flex items-center justify-center mb-3">
              <FileText className="w-4 h-4" />
            </div>
            <h3 className="text-sm font-bold text-slate-900 dark:text-slate-100 mb-1">
              Executive Markdown Brief
            </h3>
            <p className="text-xs text-slate-500 dark:text-slate-400 leading-relaxed">
              Complete formatted intelligence memo formatted for executive leadership and Slack/Notion sharing.
            </p>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={handleCopyMarkdown}
              className="flex-1 py-1.5 px-3 text-xs font-medium text-slate-700 dark:text-slate-300 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 rounded-lg transition-colors flex items-center justify-center gap-1.5"
            >
              {copiedMd ? <Check className="w-3.5 h-3.5 text-emerald-500" /> : <Copy className="w-3.5 h-3.5" />}
              <span>{copiedMd ? t.reports.copied : t.reports.copyMarkdown}</span>
            </button>
            <button
              onClick={handleDownloadMarkdown}
              className="py-1.5 px-3 text-xs font-semibold text-white bg-emerald-600 hover:bg-emerald-500 rounded-lg shadow-sm transition-colors"
            >
              <Download className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>

        {/* Catalog Matrix CSV */}
        <div className="p-5 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs flex flex-col justify-between space-y-4">
          <div>
            <div className="w-8 h-8 rounded-lg bg-blue-500/10 text-blue-600 dark:text-blue-400 flex items-center justify-center mb-3">
              <FileSpreadsheet className="w-4 h-4" />
            </div>
            <h3 className="text-sm font-bold text-slate-900 dark:text-slate-100 mb-1">
              Products Matrix CSV
            </h3>
            <p className="text-xs text-slate-500 dark:text-slate-400 leading-relaxed">
              Full product catalog dataset with materials, dimensions, prices, and stock status.
            </p>
          </div>
          <button
            onClick={handleDownloadCatalogCsv}
            className="w-full py-2 px-3 text-xs font-semibold text-white bg-slate-900 dark:bg-slate-800 hover:bg-slate-800 dark:hover:bg-slate-700 rounded-lg shadow-sm flex items-center justify-center gap-1.5 transition-colors"
          >
            <Download className="w-3.5 h-3.5" />
            <span>{t.reports.exportCsv}</span>
          </button>
        </div>

        {/* Historical Price Audit CSV */}
        <div className="p-5 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs flex flex-col justify-between space-y-4">
          <div>
            <div className="w-8 h-8 rounded-lg bg-purple-500/10 text-purple-600 dark:text-purple-400 flex items-center justify-center mb-3">
              <Database className="w-4 h-4" />
            </div>
            <h3 className="text-sm font-bold text-slate-900 dark:text-slate-100 mb-1">
              Historical Price Audit CSV
            </h3>
            <p className="text-xs text-slate-500 dark:text-slate-400 leading-relaxed">
              Granular time-series price logs with verification dates and audit notes.
            </p>
          </div>
          <button
            onClick={handleDownloadPricingCsv}
            className="w-full py-2 px-3 text-xs font-semibold text-white bg-slate-900 dark:bg-slate-800 hover:bg-slate-800 dark:hover:bg-slate-700 rounded-lg shadow-sm flex items-center justify-center gap-1.5 transition-colors"
          >
            <Download className="w-3.5 h-3.5" />
            <span>Download Audit Logs</span>
          </button>
        </div>
      </div>

      {/* Live Markdown Preview Container */}
      <div className="p-6 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs space-y-4">
        <div className="flex items-center justify-between">
          <h2 className="text-sm font-bold text-slate-900 dark:text-slate-100 flex items-center gap-2">
            <FileText className="w-4 h-4 text-emerald-500" />
            <span>Live Generated Executive Briefing Preview</span>
          </h2>
          <span className="text-xs text-slate-400 font-mono">
            Generated on {today}
          </span>
        </div>

        <div className="p-5 rounded-lg bg-slate-50 dark:bg-slate-850 border border-slate-200 dark:border-slate-800 max-h-96 overflow-y-auto">
          <pre className="text-xs font-mono text-slate-800 dark:text-slate-200 whitespace-pre-wrap leading-relaxed">
            {markdownContent}
          </pre>
        </div>
      </div>
    </div>
  );
};
