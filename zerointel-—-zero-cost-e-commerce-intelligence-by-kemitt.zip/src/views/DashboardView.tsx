import React from 'react';
import { Product, OpportunityItem, TrendItem, MonitoringItem } from '../types';
import { translations } from '../locales/translations';
import { ViewType } from '../components/Sidebar';
import {
  TrendingUp,
  Package,
  Layers,
  AlertTriangle,
  Lightbulb,
  ArrowUpRight,
  ArrowDownRight,
  Search,
  Sparkles,
  GitCompare,
  DollarSign,
  ExternalLink,
  ShieldCheck,
  CheckCircle2,
  Clock
} from 'lucide-react';

interface DashboardViewProps {
  products: Product[];
  opportunities: OpportunityItem[];
  trends: TrendItem[];
  monitoring: MonitoringItem[];
  onNavigate: (view: ViewType) => void;
  onSelectProduct: (product: Product) => void;
  lang: 'en' | 'ar';
}

export const DashboardView: React.FC<DashboardViewProps> = ({
  products,
  opportunities,
  trends,
  monitoring,
  onNavigate,
  onSelectProduct,
  lang
}) => {
  const t = translations[lang];

  const kemittProducts = products.filter((p) => p.brand === 'Kemitt');
  const competitorProducts = products.filter((p) => p.brand === 'Competitor');

  // Compute average prices and differential
  const avgKemittPrice = kemittProducts.length > 0
    ? Math.round(kemittProducts.reduce((sum, p) => sum + p.priceEGP, 0) / kemittProducts.length)
    : 0;

  const avgCompetitorPrice = competitorProducts.length > 0
    ? Math.round(competitorProducts.reduce((sum, p) => sum + p.priceEGP, 0) / competitorProducts.length)
    : 0;

  const priceDiffPercent = avgCompetitorPrice > 0
    ? (((avgKemittPrice - avgCompetitorPrice) / avgCompetitorPrice) * 100).toFixed(1)
    : '0';

  const isKemittMoreAffordable = Number(priceDiffPercent) < 0;

  // Retailer distribution
  const retailers = Array.from(new Set(competitorProducts.map((p) => p.retailer)));

  // Categories distribution
  const categories = Array.from(new Set(products.map((p) => p.category)));

  // Alerts
  const priceAlerts = monitoring.filter((m) => m.status === 'Price Changed' || m.status === 'Out of Stock');

  return (
    <div className="p-6 md:p-8 space-y-8 max-w-7xl mx-auto">
      {/* Top Banner / Welcome */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-slate-200 dark:border-slate-800 pb-6">
        <div>
          <div className="flex items-center gap-2 text-xs font-semibold uppercase tracking-wider text-emerald-600 dark:text-emerald-400 mb-1">
            <span>Kemitt Intelligence Core</span>
            <span aria-hidden="true">·</span>
            <span>Zero-Cost Local Architecture</span>
          </div>
          <h1 className="text-2xl md:text-3xl font-bold tracking-tight text-slate-900 dark:text-slate-100">
            {t.dashboard.title}
          </h1>
          <p className="text-sm text-slate-500 dark:text-slate-400 mt-1">
            {t.dashboard.subtitle}
          </p>
        </div>

        {/* Quick Launch Buttons */}
        <div className="flex flex-wrap items-center gap-2">
          <button
            onClick={() => onNavigate('aiProductSearch')}
            className="flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold text-white bg-emerald-600 hover:bg-emerald-500 rounded-lg shadow-sm transition-colors"
          >
            <Sparkles className="w-3.5 h-3.5" />
            <span>AI Product Search</span>
          </button>
          <button
            onClick={() => onNavigate('competitorSearch')}
            className="flex items-center gap-1.5 px-3.5 py-2 text-xs font-medium text-slate-700 dark:text-slate-200 bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-lg hover:bg-slate-50 dark:hover:bg-slate-750 transition-colors"
          >
            <Search className="w-3.5 h-3.5" />
            <span>Competitor Search</span>
          </button>
          <button
            onClick={() => onNavigate('productComparison')}
            className="flex items-center gap-1.5 px-3.5 py-2 text-xs font-medium text-slate-700 dark:text-slate-200 bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-lg hover:bg-slate-50 dark:hover:bg-slate-750 transition-colors"
          >
            <GitCompare className="w-3.5 h-3.5" />
            <span>Compare</span>
          </button>
        </div>
      </div>

      {/* KPI Metrics Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Kemitt Catalog */}
        <div className="p-5 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs">
          <div className="flex items-center justify-between text-xs text-slate-500 dark:text-slate-400 mb-2">
            <span>{t.dashboard.kpiTrackedKemitt}</span>
            <Package className="w-4 h-4 text-emerald-500" />
          </div>
          <div className="text-2xl font-bold font-mono tabular-nums text-slate-900 dark:text-slate-100">
            {kemittProducts.length} <span className="text-xs font-sans font-normal text-slate-400">items</span>
          </div>
          <div className="mt-2 text-xs text-slate-500 flex items-center gap-1">
            <span>Avg:</span>
            <span className="font-mono font-medium text-slate-700 dark:text-slate-300">
              {avgKemittPrice.toLocaleString()} EGP
            </span>
          </div>
        </div>

        {/* Competitor Catalog */}
        <div className="p-5 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs">
          <div className="flex items-center justify-between text-xs text-slate-500 dark:text-slate-400 mb-2">
            <span>{t.dashboard.kpiTrackedCompetitors}</span>
            <Layers className="w-4 h-4 text-blue-500" />
          </div>
          <div className="text-2xl font-bold font-mono tabular-nums text-slate-900 dark:text-slate-100">
            {competitorProducts.length} <span className="text-xs font-sans font-normal text-slate-400">across {retailers.length} retailers</span>
          </div>
          <div className="mt-2 text-xs text-slate-500 flex items-center gap-1">
            <span>Avg:</span>
            <span className="font-mono font-medium text-slate-700 dark:text-slate-300">
              {avgCompetitorPrice.toLocaleString()} EGP
            </span>
          </div>
        </div>

        {/* Kemitt Price Differential */}
        <div className="p-5 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs">
          <div className="flex items-center justify-between text-xs text-slate-500 dark:text-slate-400 mb-2">
            <span>{t.dashboard.kpiPriceDifferential}</span>
            {isKemittMoreAffordable ? (
              <ArrowDownRight className="w-4 h-4 text-emerald-500" />
            ) : (
              <ArrowUpRight className="w-4 h-4 text-amber-500" />
            )}
          </div>
          <div className={`text-2xl font-bold font-mono tabular-nums ${isKemittMoreAffordable ? 'text-emerald-600 dark:text-emerald-400' : 'text-amber-600 dark:text-amber-400'}`}>
            {priceDiffPercent}%
          </div>
          <div className="mt-2 text-xs text-slate-500">
            {isKemittMoreAffordable ? 'Kemitt more affordable than competitors' : 'Kemitt at premium tier'}
          </div>
        </div>

        {/* Opportunities Identified */}
        <div className="p-5 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs">
          <div className="flex items-center justify-between text-xs text-slate-500 dark:text-slate-400 mb-2">
            <span>{t.dashboard.kpiOpportunities}</span>
            <Lightbulb className="w-4 h-4 text-purple-500" />
          </div>
          <div className="text-2xl font-bold font-mono tabular-nums text-slate-900 dark:text-slate-100">
            {opportunities.length} <span className="text-xs font-sans font-normal text-slate-400">whitespace gaps</span>
          </div>
          <button
            onClick={() => onNavigate('opportunities')}
            className="mt-2 text-xs text-emerald-600 dark:text-emerald-400 hover:underline flex items-center gap-1"
          >
            <span>View Actionable Board</span>
            <ArrowUpRight className="w-3 h-3" />
          </button>
        </div>
      </div>

      {/* Main Grid: Competitive Landscape & Price Alerts */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Monitored Competitors */}
        <div className="lg:col-span-2 p-5 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h2 className="text-sm font-bold text-slate-900 dark:text-slate-100">
                {t.dashboard.competitiveLandscape}
              </h2>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                Egyptian furniture retailers mapped in local intelligence
              </p>
            </div>
            <button
              onClick={() => onNavigate('competitorSearch')}
              className="text-xs text-emerald-600 dark:text-emerald-400 hover:underline"
            >
              Add Competitors
            </button>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-xs text-left rtl:text-right">
              <thead>
                <tr className="border-b border-slate-200 dark:border-slate-800 text-slate-400 font-medium">
                  <th className="pb-2.5">Retailer</th>
                  <th className="pb-2.5">Tracked SKUs</th>
                  <th className="pb-2.5">Price Range (EGP)</th>
                  <th className="pb-2.5">Stock Status</th>
                  <th className="pb-2.5 text-right rtl:text-left">Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-800/80">
                {retailers.map((ret) => {
                  const items = competitorProducts.filter((p) => p.retailer === ret);
                  const prices = items.map((p) => p.priceEGP);
                  const minPrice = Math.min(...prices);
                  const maxPrice = Math.max(...prices);
                  const inStockCount = items.filter((p) => p.inStock).length;

                  return (
                    <tr key={ret} className="hover:bg-slate-50 dark:hover:bg-slate-800/40 transition-colors">
                      <td className="py-3 font-semibold text-slate-800 dark:text-slate-200">
                        {ret}
                      </td>
                      <td className="py-3 font-mono tabular-nums text-slate-600 dark:text-slate-400">
                        {items.length} items
                      </td>
                      <td className="py-3 font-mono tabular-nums text-slate-700 dark:text-slate-300">
                        {minPrice.toLocaleString()} - {maxPrice.toLocaleString()} EGP
                      </td>
                      <td className="py-3">
                        <span className="text-slate-600 dark:text-slate-400">
                          {inStockCount}/{items.length} in stock
                        </span>
                      </td>
                      <td className="py-3 text-right rtl:text-left">
                        <button
                          onClick={() => onNavigate('priceIntelligence')}
                          className="text-emerald-600 dark:text-emerald-400 hover:underline font-medium"
                        >
                          Price Index
                        </button>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>

        {/* Live Monitoring & Alerts */}
        <div className="p-5 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs flex flex-col">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h2 className="text-sm font-bold text-slate-900 dark:text-slate-100 flex items-center gap-1.5">
                <AlertTriangle className="w-4 h-4 text-amber-500" />
                <span>Price & Stock Events</span>
              </h2>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                Logged competitor movements
              </p>
            </div>
            <button
              onClick={() => onNavigate('monitoring')}
              className="text-xs text-emerald-600 dark:text-emerald-400 hover:underline"
            >
              Verify URLs
            </button>
          </div>

          <div className="space-y-3 flex-1 overflow-y-auto">
            {monitoring.slice(0, 4).map((item) => (
              <div
                key={item.id}
                className="p-3 rounded-lg border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-850 text-xs"
              >
                <div className="flex items-center justify-between mb-1">
                  <span className="font-semibold text-slate-800 dark:text-slate-200 truncate max-w-[170px]">
                    {item.productName}
                  </span>
                  <span className={`px-2 py-0.5 rounded text-[10px] font-semibold ${
                    item.status === 'Price Changed'
                      ? 'bg-amber-100 text-amber-800 dark:bg-amber-950 dark:text-amber-300'
                      : item.status === 'Out of Stock'
                      ? 'bg-rose-100 text-rose-800 dark:bg-rose-950 dark:text-rose-300'
                      : 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300'
                  }`}>
                    {item.status}
                  </span>
                </div>
                <div className="flex items-center justify-between text-slate-500 dark:text-slate-400">
                  <span>{item.retailer}</span>
                  <span className="font-mono tabular-nums font-semibold text-slate-700 dark:text-slate-300">
                    {item.currentPriceEGP.toLocaleString()} EGP
                  </span>
                </div>
                {item.changePercent !== 0 && (
                  <div className="mt-1 text-[11px] font-mono text-amber-600 dark:text-amber-400">
                    Variance: {item.changePercent > 0 ? `+${item.changePercent}%` : `${item.changePercent}%`}
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Category Benchmark Summary */}
      <div className="p-5 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs">
        <h2 className="text-sm font-bold text-slate-900 dark:text-slate-100 mb-1">
          {t.dashboard.pricePositioningSummary}
        </h2>
        <p className="text-xs text-slate-500 dark:text-slate-400 mb-4">
          Price spread across Egyptian furniture categories (Kemitt vs. Market Match)
        </p>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {categories.slice(0, 6).map((cat) => {
            const catKemitt = kemittProducts.filter((p) => p.category === cat);
            const catComp = competitorProducts.filter((p) => p.category === cat);
            const kPrice = catKemitt.length ? catKemitt[0].priceEGP : 0;
            const cPrice = catComp.length ? catComp[0].priceEGP : 0;
            const diff = cPrice > 0 ? (((kPrice - cPrice) / cPrice) * 100).toFixed(0) : '0';

            return (
              <div key={cat} className="p-4 rounded-lg border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/30">
                <div className="text-xs font-semibold text-slate-800 dark:text-slate-200 mb-2 truncate">
                  {cat}
                </div>
                <div className="flex items-center justify-between text-xs mb-1">
                  <span className="text-slate-500">Kemitt:</span>
                  <span className="font-mono tabular-nums font-semibold text-emerald-600 dark:text-emerald-400">
                    {kPrice ? `${kPrice.toLocaleString()} EGP` : 'None'}
                  </span>
                </div>
                <div className="flex items-center justify-between text-xs mb-2">
                  <span className="text-slate-500">Competitors:</span>
                  <span className="font-mono tabular-nums text-slate-700 dark:text-slate-300">
                    {cPrice ? `${cPrice.toLocaleString()} EGP` : 'None'}
                  </span>
                </div>
                {cPrice > 0 && kPrice > 0 && (
                  <div className="pt-2 border-t border-slate-200 dark:border-slate-700/60 flex items-center justify-between text-[11px]">
                    <span className="text-slate-400">Spread:</span>
                    <span className={`font-mono font-semibold ${Number(diff) < 0 ? 'text-emerald-600 dark:text-emerald-400' : 'text-amber-600 dark:text-amber-400'}`}>
                      {Number(diff) < 0 ? `Kemitt ${Math.abs(Number(diff))}% Lower` : `Kemitt +${diff}% Premium`}
                    </span>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
