import React, { useState } from 'react';
import { Product, PriceRecord } from '../types';
import { translations } from '../locales/translations';
import {
  DollarSign,
  TrendingUp,
  TrendingDown,
  Calendar,
  Filter,
  Plus,
  ArrowUpDown,
  CheckCircle2,
  AlertCircle,
  ExternalLink
} from 'lucide-react';

interface PriceIntelligenceViewProps {
  products: Product[];
  onUpdateProduct: (product: Product) => void;
  lang: 'en' | 'ar';
}

export const PriceIntelligenceView: React.FC<PriceIntelligenceViewProps> = ({
  products,
  onUpdateProduct,
  lang
}) => {
  const t = translations[lang];

  const [selectedCategory, setSelectedCategory] = useState<string>('All');
  const [selectedRetailer, setSelectedRetailer] = useState<string>('All');
  const [selectedProductId, setSelectedProductId] = useState<string | null>(null);

  // New price log state
  const [newLogPrice, setNewLogPrice] = useState<string>('');
  const [newLogDate, setNewLogDate] = useState<string>(new Date().toISOString().split('T')[0]);
  const [newLogNote, setNewLogNote] = useState<string>('Periodic competitor price check');
  const [showLogModal, setShowLogModal] = useState(false);

  const categories = ['All', ...Array.from(new Set(products.map((p) => p.category)))];
  const retailers = ['All', ...Array.from(new Set(products.map((p) => p.retailer)))];

  const filteredProducts = products.filter((p) => {
    if (selectedCategory !== 'All' && p.category !== selectedCategory) return false;
    if (selectedRetailer !== 'All' && p.retailer !== selectedRetailer) return false;
    return true;
  });

  const kemittItems = filteredProducts.filter((p) => p.brand === 'Kemitt');
  const competitorItems = filteredProducts.filter((p) => p.brand === 'Competitor');

  const avgKemitt = kemittItems.length
    ? Math.round(kemittItems.reduce((s, p) => s + p.priceEGP, 0) / kemittItems.length)
    : 0;

  const avgCompetitor = competitorItems.length
    ? Math.round(competitorItems.reduce((s, p) => s + p.priceEGP, 0) / competitorItems.length)
    : 0;

  const priceIndex = avgCompetitor > 0
    ? Math.round((avgKemitt / avgCompetitor) * 100)
    : 100;

  const handleOpenLogModal = (productId: string) => {
    const prod = products.find((p) => p.id === productId);
    if (!prod) return;
    setSelectedProductId(productId);
    setNewLogPrice(String(prod.priceEGP));
    setNewLogDate(new Date().toISOString().split('T')[0]);
    setShowLogModal(true);
  };

  const handleSavePriceLog = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedProductId || !newLogPrice) return;

    const prod = products.find((p) => p.id === selectedProductId);
    if (!prod) return;

    const parsedPrice = parseFloat(newLogPrice);
    const updatedHistory = [...(prod.priceHistory || [])];
    updatedHistory.push({
      date: newLogDate,
      priceEGP: parsedPrice,
      note: newLogNote
    });

    const updatedProduct: Product = {
      ...prod,
      priceEGP: parsedPrice,
      lastChecked: newLogDate,
      priceHistory: updatedHistory
    };

    onUpdateProduct(updatedProduct);
    setShowLogModal(false);
  };

  return (
    <div className="p-6 md:p-8 space-y-8 max-w-7xl mx-auto">
      {/* Header */}
      <div className="border-b border-slate-200 dark:border-slate-800 pb-5">
        <div className="flex items-center gap-2 text-xs font-semibold uppercase tracking-wider text-emerald-600 dark:text-emerald-400 mb-1">
          <DollarSign className="w-3.5 h-3.5" />
          <span>Market Pricing Dynamics</span>
        </div>
        <h1 className="text-2xl md:text-3xl font-bold tracking-tight text-slate-900 dark:text-slate-100">
          {t.priceIntel.title}
        </h1>
        <p className="text-sm text-slate-500 dark:text-slate-400 mt-1">
          {t.priceIntel.subtitle}
        </p>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        {/* Kemitt Price Index */}
        <div className="p-5 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs">
          <div className="text-xs text-slate-500 dark:text-slate-400 mb-1">
            Kemitt Price Index vs. Competitors
          </div>
          <div className="flex items-baseline gap-2">
            <span className="text-3xl font-bold font-mono tabular-nums text-slate-900 dark:text-slate-100">
              {priceIndex}%
            </span>
            <span className="text-xs text-slate-400">
              (100% = Parity)
            </span>
          </div>
          <p className="text-xs text-slate-500 mt-2">
            {priceIndex < 100
              ? `Kemitt averages ${100 - priceIndex}% below competitor catalog prices`
              : `Kemitt averages ${priceIndex - 100}% above competitor benchmarks`}
          </p>
        </div>

        {/* Kemitt Average */}
        <div className="p-5 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs">
          <div className="text-xs text-slate-500 dark:text-slate-400 mb-1">
            Kemitt Catalog Average
          </div>
          <div className="text-3xl font-bold font-mono tabular-nums text-emerald-600 dark:text-emerald-400">
            {avgKemitt.toLocaleString()} <span className="text-xs font-sans font-medium text-slate-400">EGP</span>
          </div>
          <p className="text-xs text-slate-500 mt-2">
            Across {kemittItems.length} active Kemitt catalog models
          </p>
        </div>

        {/* Competitor Average */}
        <div className="p-5 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs">
          <div className="text-xs text-slate-500 dark:text-slate-400 mb-1">
            Egyptian Competitors Average
          </div>
          <div className="text-3xl font-bold font-mono tabular-nums text-slate-900 dark:text-slate-100">
            {avgCompetitor.toLocaleString()} <span className="text-xs font-sans font-medium text-slate-400">EGP</span>
          </div>
          <p className="text-xs text-slate-500 mt-2">
            Across {competitorItems.length} competitor reference products
          </p>
        </div>
      </div>

      {/* Filter Toolbar */}
      <div className="p-4 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs flex flex-wrap items-center justify-between gap-3">
        <div className="flex flex-wrap items-center gap-3">
          <div className="flex items-center gap-2 text-xs text-slate-500">
            <Filter className="w-3.5 h-3.5" />
            <span>Filters:</span>
          </div>

          <select
            value={selectedCategory}
            onChange={(e) => setSelectedCategory(e.target.value)}
            className="px-3 py-1.5 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-lg text-slate-900 dark:text-slate-100 focus:outline-none"
          >
            {categories.map((c) => (
              <option key={c} value={c}>{c === 'All' ? t.common.allCategories : c}</option>
            ))}
          </select>

          <select
            value={selectedRetailer}
            onChange={(e) => setSelectedRetailer(e.target.value)}
            className="px-3 py-1.5 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-lg text-slate-900 dark:text-slate-100 focus:outline-none"
          >
            {retailers.map((r) => (
              <option key={r} value={r}>{r === 'All' ? t.common.allRetailers : r}</option>
            ))}
          </select>
        </div>

        <div className="text-xs text-slate-500 font-mono">
          Showing {filteredProducts.length} items
        </div>
      </div>

      {/* Pricing Matrix Table */}
      <div className="p-5 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs">
        <div className="overflow-x-auto">
          <table className="w-full text-xs text-left rtl:text-right">
            <thead>
              <tr className="border-b border-slate-200 dark:border-slate-800 text-slate-400 font-medium">
                <th className="pb-3">Product Name</th>
                <th className="pb-3">Retailer</th>
                <th className="pb-3">Category</th>
                <th className="pb-3 font-mono">Price (EGP)</th>
                <th className="pb-3">Price History Points</th>
                <th className="pb-3">Last Verified</th>
                <th className="pb-3 text-right rtl:text-left">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
              {filteredProducts.map((p) => {
                const historyCount = p.priceHistory ? p.priceHistory.length : 1;
                const isKemitt = p.brand === 'Kemitt';

                return (
                  <tr key={p.id} className="hover:bg-slate-50 dark:hover:bg-slate-800/40 transition-colors">
                    <td className="py-3 font-semibold text-slate-900 dark:text-slate-100">
                      <div className="flex items-center gap-2">
                        <span>{p.name}</span>
                        {isKemitt && (
                          <span className="text-[10px] uppercase font-bold text-emerald-600 dark:text-emerald-400 bg-emerald-50 dark:bg-emerald-950/40 px-1.5 py-0.5 rounded">
                            Kemitt
                          </span>
                        )}
                      </div>
                    </td>
                    <td className="py-3 text-slate-600 dark:text-slate-400">
                      {p.retailer}
                    </td>
                    <td className="py-3 text-slate-600 dark:text-slate-400">
                      {p.category}
                    </td>
                    <td className="py-3 font-mono font-bold tabular-nums text-slate-900 dark:text-slate-100">
                      {p.priceEGP.toLocaleString()} EGP
                    </td>
                    <td className="py-3 font-mono text-slate-500">
                      {historyCount} log{historyCount > 1 ? 's' : ''}
                    </td>
                    <td className="py-3 font-mono text-slate-400">
                      {p.lastChecked}
                    </td>
                    <td className="py-3 text-right rtl:text-left">
                      <button
                        onClick={() => handleOpenLogModal(p.id)}
                        className="px-2.5 py-1 text-xs font-medium text-emerald-700 dark:text-emerald-400 bg-emerald-50 dark:bg-emerald-950/40 hover:bg-emerald-100 dark:hover:bg-emerald-900/50 rounded-md transition-colors"
                      >
                        + Log Price
                      </button>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* Log Price Modal */}
      {showLogModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs">
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl shadow-2xl max-w-md w-full p-6 animate-in fade-in zoom-in-95 duration-150 space-y-4">
            <h3 className="text-sm font-bold text-slate-900 dark:text-slate-100">
              {t.priceIntel.logNewPrice}
            </h3>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              Record a price observation with date and audit notes.
            </p>

            <form onSubmit={handleSavePriceLog} className="space-y-3">
              <div>
                <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                  Observed Price (EGP) *
                </label>
                <input
                  type="number"
                  required
                  min="0"
                  step="50"
                  value={newLogPrice}
                  onChange={(e) => setNewLogPrice(e.target.value)}
                  className="w-full px-3 py-2 text-xs font-mono tabular-nums bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-lg text-slate-900 dark:text-slate-100"
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                  Verification Date
                </label>
                <input
                  type="date"
                  required
                  value={newLogDate}
                  onChange={(e) => setNewLogDate(e.target.value)}
                  className="w-full px-3 py-2 text-xs bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-lg text-slate-900 dark:text-slate-100"
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                  Audit Notes / Reason for Change
                </label>
                <input
                  type="text"
                  value={newLogNote}
                  onChange={(e) => setNewLogNote(e.target.value)}
                  placeholder="e.g. Black Friday discount, inflation adjustment"
                  className="w-full px-3 py-2 text-xs bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-lg text-slate-900 dark:text-slate-100"
                />
              </div>

              <div className="pt-2 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setShowLogModal(false)}
                  className="px-3 py-1.5 text-xs text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-md"
                >
                  {t.common.cancel}
                </button>
                <button
                  type="submit"
                  className="px-4 py-1.5 text-xs font-semibold text-white bg-emerald-600 hover:bg-emerald-500 rounded-md shadow-sm"
                >
                  Save Price Record
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
