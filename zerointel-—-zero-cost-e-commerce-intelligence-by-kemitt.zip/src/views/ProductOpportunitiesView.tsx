import React, { useState } from 'react';
import { OpportunityItem, Product } from '../types';
import { geminiService } from '../services/gemini';
import { translations } from '../locales/translations';
import {
  Lightbulb,
  Sparkles,
  RefreshCw,
  Plus,
  CheckCircle2,
  AlertCircle,
  Tag,
  ArrowRight,
  TrendingUp,
  DollarSign,
  ChevronDown
} from 'lucide-react';

interface ProductOpportunitiesViewProps {
  opportunities: OpportunityItem[];
  products: Product[];
  onSaveOpportunity: (opp: OpportunityItem) => void;
  lang: 'en' | 'ar';
}

export const ProductOpportunitiesView: React.FC<ProductOpportunitiesViewProps> = ({
  opportunities,
  products,
  onSaveOpportunity,
  lang
}) => {
  const t = translations[lang];

  const [synthesizing, setSynthesizing] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [execSummary, setExecSummary] = useState<string | null>(null);
  const [verdict, setVerdict] = useState<string | null>(null);
  const [filterType, setFilterType] = useState<string>('All');

  const kemittProducts = products.filter((p) => p.brand === 'Kemitt');
  const competitorProducts = products.filter((p) => p.brand === 'Competitor');

  const handleSynthesize = async () => {
    setSynthesizing(true);
    setErrorMsg(null);

    try {
      const res = await geminiService.synthesizeOpportunities(kemittProducts, competitorProducts);
      setExecSummary(res.executiveSummary);
      setVerdict(res.pricePositioningVerdict);

      // Save each synthesized opportunity to repository
      res.opportunities.forEach((opp) => {
        onSaveOpportunity(opp);
      });
    } catch (err: unknown) {
      const error = err as Error;
      setErrorMsg(error.message || 'Failed to synthesize opportunities.');
    } finally {
      setSynthesizing(false);
    }
  };

  const handleUpdateStatus = (opp: OpportunityItem, newStatus: OpportunityItem['status']) => {
    onSaveOpportunity({
      ...opp,
      status: newStatus
    });
  };

  const filteredOpportunities = filterType === 'All'
    ? opportunities
    : opportunities.filter((o) => o.opportunityType === filterType);

  return (
    <div className="p-6 md:p-8 space-y-8 max-w-7xl mx-auto">
      {/* Header */}
      <div className="border-b border-slate-200 dark:border-slate-800 pb-5 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 text-xs font-semibold uppercase tracking-wider text-emerald-600 dark:text-emerald-400 mb-1">
            <Lightbulb className="w-3.5 h-3.5" />
            <span>Merchandising & Whitespace Analysis</span>
          </div>
          <h1 className="text-2xl md:text-3xl font-bold tracking-tight text-slate-900 dark:text-slate-100">
            {t.opportunities.title}
          </h1>
          <p className="text-sm text-slate-500 dark:text-slate-400 mt-1">
            {t.opportunities.subtitle}
          </p>
        </div>

        <button
          onClick={handleSynthesize}
          disabled={synthesizing}
          className="px-4 py-2.5 text-xs font-semibold text-white bg-emerald-600 hover:bg-emerald-500 disabled:opacity-50 rounded-lg shadow-sm flex items-center gap-2 transition-colors shrink-0"
        >
          {synthesizing ? (
            <>
              <RefreshCw className="w-3.5 h-3.5 animate-spin" />
              <span>Analyzing with Gemini 3.8 Flash...</span>
            </>
          ) : (
            <>
              <Sparkles className="w-3.5 h-3.5" />
              <span>{t.opportunities.synthesizeBtn}</span>
            </>
          )}
        </button>
      </div>

      {errorMsg && (
        <div className="p-3.5 rounded-lg bg-rose-50 dark:bg-rose-950/30 border border-rose-200 dark:border-rose-900 text-xs text-rose-700 dark:text-rose-300 flex items-center gap-2">
          <AlertCircle className="w-4 h-4 shrink-0" />
          <span>{errorMsg}</span>
        </div>
      )}

      {/* Executive Summary if Generated */}
      {execSummary && (
        <div className="p-5 rounded-xl bg-emerald-50/70 dark:bg-emerald-950/30 border border-emerald-200 dark:border-emerald-800/60 space-y-2 animate-in fade-in duration-200">
          <div className="text-xs font-bold text-emerald-900 dark:text-emerald-300 uppercase tracking-wider">
            Chief Merchandising Strategy Verdict
          </div>
          <p className="text-sm text-emerald-950 dark:text-emerald-100 leading-relaxed">
            {execSummary}
          </p>
          {verdict && (
            <div className="text-xs text-emerald-800 dark:text-emerald-300 font-medium pt-1">
              Positioning Analysis: {verdict}
            </div>
          )}
        </div>
      )}

      {/* Filter Tabs (Interactive button filter controls) */}
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div className="flex flex-wrap items-center gap-1.5 p-1 bg-slate-100 dark:bg-slate-800 rounded-lg">
          {['All', 'Whitespace Gap', 'Margin Optimization', 'Trend Capitalization', 'Defensive Alternative'].map((type) => (
            <button
              key={type}
              onClick={() => setFilterType(type)}
              className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors ${
                filterType === type
                  ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-slate-100 shadow-xs'
                  : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
              }`}
            >
              {type}
            </button>
          ))}
        </div>

        <span className="text-xs text-slate-400 font-mono">
          {filteredOpportunities.length} opportunities mapped
        </span>
      </div>

      {/* Opportunities Board */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredOpportunities.map((opp) => (
          <div
            key={opp.id}
            className="p-5 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs flex flex-col justify-between space-y-4 hover:border-slate-300 dark:hover:border-slate-700 transition-colors"
          >
            <div>
              {/* Type and Impact */}
              <div className="flex items-center justify-between text-xs mb-2">
                <span className="font-semibold text-emerald-600 dark:text-emerald-400 text-[11px] uppercase tracking-wider">
                  {opp.opportunityType}
                </span>
                <span className="text-[10px] font-mono text-slate-400">
                  Impact: {opp.expectedImpact}
                </span>
              </div>

              {/* Title & Category */}
              <h3 className="text-base font-bold text-slate-900 dark:text-slate-100 mb-1">
                {opp.title}
              </h3>
              <div className="text-xs text-slate-500 mb-3">
                Category: {opp.category}
              </div>

              {/* Price Band & Benchmark */}
              <div className="p-3 rounded-lg bg-slate-50 dark:bg-slate-850 border border-slate-200 dark:border-slate-800 text-xs space-y-1.5 mb-3">
                <div className="flex items-center justify-between">
                  <span className="text-slate-500">Target Retail:</span>
                  <span className="font-mono font-bold text-slate-900 dark:text-slate-100 tabular-nums">
                    {opp.targetPriceBandEGP}
                  </span>
                </div>
                <div className="text-[11px] text-slate-600 dark:text-slate-400">
                  <span className="text-slate-400">Benchmark: </span>
                  {opp.competitorBenchmark}
                </div>
              </div>

              {/* Rationale */}
              <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed mb-3">
                {opp.rationale}
              </p>

              {/* Recommended Materials */}
              <div className="text-xs text-slate-500">
                <span className="font-semibold text-slate-700 dark:text-slate-300 block mb-0.5">
                  Production Materials:
                </span>
                <span className="text-[11px]">{opp.recommendedMaterials}</span>
              </div>
            </div>

            {/* Status Stepper */}
            <div className="pt-3 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between">
              <span className="text-[11px] text-slate-400">Status:</span>
              <select
                value={opp.status}
                onChange={(e) => handleUpdateStatus(opp, e.target.value as OpportunityItem['status'])}
                className="text-xs px-2 py-1 rounded bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-800 dark:text-slate-200 focus:outline-none"
              >
                <option value="Identified">Identified</option>
                <option value="Under Evaluation">Under Evaluation</option>
                <option value="Prototype">Prototype</option>
                <option value="Archived">Archived</option>
              </select>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
